/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // EduBaania Tiffany/Teal Theme 2026
        tiffany: {
          50: '#E6F9F8',
          100: '#CCF3F1',
          200: '#99E7E4',
          300: '#66DBD5',
          400: '#33CFC8',
          500: '#0ABAB5',  // Primary brand color
          600: '#089591',
          700: '#06706D',
          800: '#044B49',
          900: '#003634',
        },
        // Clean backgrounds
        surface: {
          bg: '#FAFAFA',
          card: '#FFFFFF',
          elevated: '#F5F5F5',
          hover: '#F0F0F0',
        },
        // Accent colors - keeping useful ones, adding teal-complementary
        accent: {
          teal: '#0ABAB5',
          purple: '#8B5CF6',
          pink: '#F472B6',
          orange: '#FB923C',
          coral: '#FF6B6B',
          mint: '#34D399',
          blue: '#60A5FA',
          cyan: '#22D3EE',
        },
        // Tier colors - gamification
        tier: {
          bronze: '#CD7F32',
          'bronze-bg': '#FEF3E2',
          silver: '#94A3B8',
          'silver-bg': '#F1F5F9',
          gold: '#F59E0B',
          'gold-bg': '#FEF3C7',
          diamond: '#8B5CF6',
          'diamond-bg': '#EDE9FE',
          legendary: '#EC4899',
          'legendary-bg': '#FCE7F3',
        },
        // Text colors
        text: {
          primary: '#1A1A1A',
          secondary: '#525252',
          muted: '#A3A3A3',
          accent: '#0ABAB5',
        },
      },
      fontFamily: {
        display: ['Nunito', 'Rounded Mplus 1c', 'system-ui', 'sans-serif'],
        body: ['Inter', 'Noto Sans TC', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        'xl': '16px',
        '2xl': '24px',
        '3xl': '32px',
      },
      boxShadow: {
        // Clean modern shadows
        'soft': '0 2px 8px rgba(0, 0, 0, 0.04), 0 4px 16px rgba(0, 0, 0, 0.04)',
        'soft-md': '0 4px 12px rgba(0, 0, 0, 0.06), 0 8px 24px rgba(0, 0, 0, 0.06)',
        'soft-lg': '0 8px 24px rgba(0, 0, 0, 0.08), 0 16px 48px rgba(0, 0, 0, 0.08)',
        'soft-hover': '0 8px 32px rgba(0, 0, 0, 0.1)',
        // Tiffany teal shadows
        'teal': '0 4px 16px rgba(10, 186, 181, 0.25)',
        'teal-lg': '0 8px 32px rgba(10, 186, 181, 0.3)',
        // Other colored shadows
        'purple': '0 4px 16px rgba(139, 92, 246, 0.25)',
        'orange': '0 4px 16px rgba(251, 146, 60, 0.25)',
        'pink': '0 4px 16px rgba(244, 114, 182, 0.25)',
        'gold': '0 4px 16px rgba(245, 158, 11, 0.3)',
        // Card shadow
        'card': '0 1px 3px rgba(0, 0, 0, 0.06), 0 4px 12px rgba(0, 0, 0, 0.04)',
        'card-hover': '0 4px 16px rgba(0, 0, 0, 0.08), 0 8px 32px rgba(0, 0, 0, 0.06)',
      },
      backgroundImage: {
        // Tiffany gradients
        'teal-gradient': 'linear-gradient(135deg, #0ABAB5 0%, #22D3EE 100%)',
        'teal-subtle': 'linear-gradient(135deg, #E6F9F8 0%, #CCF3F1 100%)',
        // Clean gradients
        'surface-gradient': 'linear-gradient(180deg, #FFFFFF 0%, #FAFAFA 100%)',
        'card-gradient': 'linear-gradient(180deg, #FFFFFF 0%, #F8F8F8 100%)',
        // Accent gradients
        'purple-gradient': 'linear-gradient(135deg, #8B5CF6 0%, #A78BFA 100%)',
        'orange-gradient': 'linear-gradient(135deg, #FB923C 0%, #FDBA74 100%)',
        'pink-gradient': 'linear-gradient(135deg, #F472B6 0%, #F9A8D4 100%)',
        'gold-gradient': 'linear-gradient(135deg, #F59E0B 0%, #FCD34D 100%)',
        // Mesh gradient background
        'mesh-gradient': 'radial-gradient(at 40% 20%, rgba(10, 186, 181, 0.08) 0px, transparent 50%), radial-gradient(at 80% 80%, rgba(139, 92, 246, 0.06) 0px, transparent 50%), radial-gradient(at 0% 100%, rgba(96, 165, 250, 0.06) 0px, transparent 50%)',
      },
      animation: {
        'fade-in-up': 'fade-in-up 0.5s ease-out forwards',
        'scale-in': 'scale-in 0.3s ease-out forwards',
        'bounce-in': 'bounce-in 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards',
        'float': 'float 4s ease-in-out infinite',
        'shimmer': 'shimmer 2s ease-in-out infinite',
        'pulse-soft': 'pulse-soft 2s ease-in-out infinite',
        'spin': 'spin 1s linear infinite',
        'wiggle': 'wiggle 0.5s ease-in-out',
        'pop': 'pop 0.3s ease-out',
        'slide-up': 'slide-up 0.4s ease-out forwards',
        'slide-down': 'slide-down 0.4s ease-out forwards',
      },
      keyframes: {
        'fade-in-up': {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'scale-in': {
          from: { opacity: '0', transform: 'scale(0.9)' },
          to: { opacity: '1', transform: 'scale(1)' },
        },
        'bounce-in': {
          '0%': { opacity: '0', transform: 'scale(0.3)' },
          '50%': { transform: 'scale(1.05)' },
          '70%': { transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        'shimmer': {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
        'pulse-soft': {
          '0%, 100%': { transform: 'scale(1)', opacity: '1' },
          '50%': { transform: 'scale(1.02)', opacity: '0.9' },
        },
        'spin': {
          from: { transform: 'rotate(0deg)' },
          to: { transform: 'rotate(360deg)' },
        },
        'wiggle': {
          '0%, 100%': { transform: 'rotate(0deg)' },
          '25%': { transform: 'rotate(-5deg)' },
          '75%': { transform: 'rotate(5deg)' },
        },
        'pop': {
          '0%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.1)' },
          '100%': { transform: 'scale(1)' },
        },
        'slide-up': {
          from: { opacity: '0', transform: 'translateY(10px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-down': {
          from: { opacity: '0', transform: 'translateY(-10px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [
    require('tailwindcss-animate'),
  ],
}
