/**
 * RewardGuide - 獎勵說明組件
 * 說明如何獲得經驗值和金幣（基於目前可追蹤指標）
 */

import {
  BookOpen,
  FileCheck,
  Award,
} from 'lucide-react';
import { REWARD_RULES } from '../types/gamification';

interface RewardItem {
  icon: React.ReactNode;
  action: string;
  xp: number | string;
  coins: number | string;
  note?: string;
}

const rewardItems: RewardItem[] = [
  {
    icon: <BookOpen className="w-4 h-4" />,
    action: '完成學習任務',
    xp: REWARD_RULES.task.xp,
    coins: REWARD_RULES.task.coins,
  },
  {
    icon: <FileCheck className="w-4 h-4" />,
    action: '試卷及格',
    xp: REWARD_RULES.examPass.xp,
    coins: REWARD_RULES.examPass.coins,
  },
  {
    icon: <FileCheck className="w-4 h-4" />,
    action: '試卷無猜題（額外）',
    xp: '+' + REWARD_RULES.examNoGuessing.xp,
    coins: '+' + REWARD_RULES.examNoGuessing.coins,
    note: '及格時額外獎勵',
  },
  {
    icon: <Award className="w-4 h-4" />,
    action: '獲得銅徽章',
    xp: REWARD_RULES.badgeBronze.xp,
    coins: REWARD_RULES.badgeBronze.coins,
  },
  {
    icon: <Award className="w-4 h-4" />,
    action: '獲得銀徽章',
    xp: REWARD_RULES.badgeSilver.xp,
    coins: REWARD_RULES.badgeSilver.coins,
  },
  {
    icon: <Award className="w-4 h-4" />,
    action: '獲得金徽章',
    xp: REWARD_RULES.badgeGold.xp,
    coins: REWARD_RULES.badgeGold.coins,
  },
];

interface RewardGuideProps {
  compact?: boolean;
}

export function RewardGuide({ compact = false }: RewardGuideProps) {
  if (compact) {
    return (
      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-2 px-2 py-1.5 bg-teal-50 rounded-lg">
            <BookOpen className="w-3.5 h-3.5 text-teal-600" />
            <span className="text-gray-600">任務</span>
            <span className="ml-auto font-medium text-teal-700">+{REWARD_RULES.task.xp} XP</span>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 bg-blue-50 rounded-lg">
            <FileCheck className="w-3.5 h-3.5 text-blue-600" />
            <span className="text-gray-600">試卷及格</span>
            <span className="ml-auto font-medium text-blue-700">+{REWARD_RULES.examPass.xp} XP</span>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 bg-green-50 rounded-lg">
            <FileCheck className="w-3.5 h-3.5 text-green-600" />
            <span className="text-gray-600">無猜題</span>
            <span className="ml-auto font-medium text-green-700">+{REWARD_RULES.examNoGuessing.xp} XP</span>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 bg-amber-50 rounded-lg">
            <Award className="w-3.5 h-3.5 text-amber-600" />
            <span className="text-gray-600">徽章</span>
            <span className="ml-auto font-medium text-amber-700">+30~150 XP</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <div className="flex-1 h-px bg-gray-200" />
        <span>經驗值 (XP) 用於升級，金幣用於兌換獎品</span>
        <div className="flex-1 h-px bg-gray-200" />
      </div>

      {/* Reward Table */}
      <div className="bg-gray-50 rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-100 text-gray-600">
              <th className="text-left py-2 px-3 font-medium">行為</th>
              <th className="text-center py-2 px-2 font-medium w-20">XP</th>
              <th className="text-center py-2 px-2 font-medium w-20">金幣</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {rewardItems.map((item, index) => (
              <tr key={index} className="hover:bg-white transition-colors">
                <td className="py-2 px-3">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">{item.icon}</span>
                    <span className="text-gray-700">{item.action}</span>
                    {item.note && (
                      <span className="text-[10px] px-1.5 py-0.5 bg-gray-200 text-gray-500 rounded">
                        {item.note}
                      </span>
                    )}
                  </div>
                </td>
                <td className="text-center py-2 px-2">
                  <span className="font-medium text-teal-600">
                    {item.xp === '-' ? '-' : `+${item.xp}`}
                  </span>
                </td>
                <td className="text-center py-2 px-2">
                  <span className="font-medium text-amber-600">
                    {item.coins === '-' ? '-' : `+${item.coins}`}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Level Info */}
      <div className="flex items-center justify-center gap-4 text-xs text-gray-500">
        <span>等級越高可兌換越多獎品</span>
        <span className="text-gray-300">|</span>
        <span>Lv.2: 100 XP</span>
        <span className="text-gray-300">|</span>
        <span>Lv.5: 1000 XP</span>
        <span className="text-gray-300">|</span>
        <span>Lv.10: 5000 XP</span>
      </div>
    </div>
  );
}

export default RewardGuide;
