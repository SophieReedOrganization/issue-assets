/**
 * RewardGuide - 獎勵說明組件
 * 說明如何獲得經驗值和金幣（基於 docs/gamification-system/03-reward-rules.md）
 */

import {
  BookOpen,
  FileCheck,
  Award,
  Calendar,
  Sunrise,
  Trophy,
} from 'lucide-react';
import { DEFAULT_REWARDS, XP_PER_LEVEL } from '../types/gamification';

interface RewardItem {
  icon: React.ReactNode;
  action: string;
  xp: number | string;
  coins: number | string;
  note?: string;
}

const rewardItems: RewardItem[] = [
  // 任務獎勵
  {
    icon: <BookOpen className="w-4 h-4" />,
    action: '完成初級任務',
    xp: DEFAULT_REWARDS.taskBeginner.xp,
    coins: DEFAULT_REWARDS.taskBeginner.coins,
  },
  {
    icon: <BookOpen className="w-4 h-4" />,
    action: '完成中級任務',
    xp: DEFAULT_REWARDS.taskIntermediate.xp,
    coins: DEFAULT_REWARDS.taskIntermediate.coins,
  },
  {
    icon: <BookOpen className="w-4 h-4" />,
    action: '完成高級任務',
    xp: DEFAULT_REWARDS.taskAdvanced.xp,
    coins: DEFAULT_REWARDS.taskAdvanced.coins,
  },
  // 考試獎勵
  {
    icon: <FileCheck className="w-4 h-4" />,
    action: '考試及格 (70-79%)',
    xp: `+${DEFAULT_REWARDS.accuracyPass.xp}`,
    coins: `+${DEFAULT_REWARDS.accuracyPass.coins}`,
    note: '加成',
  },
  {
    icon: <FileCheck className="w-4 h-4" />,
    action: '考試優秀 (90%+)',
    xp: `+${DEFAULT_REWARDS.accuracyExcellent.xp}`,
    coins: `+${DEFAULT_REWARDS.accuracyExcellent.coins}`,
    note: '加成',
  },
  {
    icon: <FileCheck className="w-4 h-4" />,
    action: '考試完美 (100%)',
    xp: `+${DEFAULT_REWARDS.accuracyPerfect.xp}`,
    coins: `+${DEFAULT_REWARDS.accuracyPerfect.coins}`,
    note: '加成',
  },
  {
    icon: <FileCheck className="w-4 h-4" />,
    action: '無猜題獎勵',
    xp: `+${DEFAULT_REWARDS.examNoGuessing.xp}`,
    coins: `+${DEFAULT_REWARDS.examNoGuessing.coins}`,
    note: '額外',
  },
  // 登入獎勵
  {
    icon: <Calendar className="w-4 h-4" />,
    action: '每日登入',
    xp: DEFAULT_REWARDS.dailyLogin.xp,
    coins: DEFAULT_REWARDS.dailyLogin.coins,
  },
  {
    icon: <Trophy className="w-4 h-4" />,
    action: '7 日連續登入',
    xp: DEFAULT_REWARDS.streakDay7.xp,
    coins: DEFAULT_REWARDS.streakDay7.coins,
    note: '里程碑',
  },
  // 特殊事件
  {
    icon: <Sunrise className="w-4 h-4" />,
    action: '早起學習 (08:00前)',
    xp: `+${DEFAULT_REWARDS.earlyBird.xp}`,
    coins: `+${DEFAULT_REWARDS.earlyBird.coins}`,
    note: '每日一次',
  },
];

interface RewardGuideProps {
  compact?: boolean;
}

export function RewardGuide({ compact = false }: RewardGuideProps) {
  if (compact) {
    return (
      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-2 px-2 py-1.5 bg-teal-50 rounded-lg">
            <BookOpen className="w-3.5 h-3.5 text-teal-600" />
            <span className="text-gray-600">任務</span>
            <span className="ml-auto font-medium text-teal-700">30-70 XP</span>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 bg-blue-50 rounded-lg">
            <FileCheck className="w-3.5 h-3.5 text-blue-600" />
            <span className="text-gray-600">考試滿分</span>
            <span className="ml-auto font-medium text-blue-700">+{DEFAULT_REWARDS.accuracyPerfect.xp} XP</span>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 bg-green-50 rounded-lg">
            <Calendar className="w-3.5 h-3.5 text-green-600" />
            <span className="text-gray-600">每日登入</span>
            <span className="ml-auto font-medium text-green-700">+{DEFAULT_REWARDS.dailyLogin.xp} XP</span>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 bg-amber-50 rounded-lg">
            <Trophy className="w-3.5 h-3.5 text-amber-600" />
            <span className="text-gray-600">7日連續</span>
            <span className="ml-auto font-medium text-amber-700">+{DEFAULT_REWARDS.streakDay7.xp} XP</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <div className="flex-1 h-px bg-gray-200" />
        <span>經驗值 (XP) 用於升級，金幣用於兌換獎品</span>
        <div className="flex-1 h-px bg-gray-200" />
      </div>

      {/* Reward Table */}
      <div className="bg-gray-50 rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-100 text-gray-600">
              <th className="text-left py-2 px-3 font-medium">行為</th>
              <th className="text-center py-2 px-2 font-medium w-20">XP</th>
              <th className="text-center py-2 px-2 font-medium w-20">金幣</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {rewardItems.map((item, index) => (
              <tr key={index} className="hover:bg-white transition-colors">
                <td className="py-2 px-3">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">{item.icon}</span>
                    <span className="text-gray-700">{item.action}</span>
                    {item.note && (
                      <span className="text-[10px] px-1.5 py-0.5 bg-gray-200 text-gray-500 rounded">
                        {item.note}
                      </span>
                    )}
                  </div>
                </td>
                <td className="text-center py-2 px-2">
                  <span className="font-medium text-teal-600">
                    {typeof item.xp === 'string' ? item.xp : `+${item.xp}`}
                  </span>
                </td>
                <td className="text-center py-2 px-2">
                  <span className="font-medium text-amber-600">
                    {typeof item.coins === 'string' ? item.coins : `+${item.coins}`}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Level Info */}
      <div className="flex items-center justify-center gap-4 text-xs text-gray-500">
        <span>每 {XP_PER_LEVEL} XP 升一級</span>
        <span className="text-gray-300">|</span>
        <span>連續登入有加成倍率 (最高 1.5x)</span>
      </div>
    </div>
  );
}

export default RewardGuide;
