/**
 * TitleBadge - 稱號標籤組件
 * 顯示在用戶名字下方或旁邊的稱號
 */

import { cn } from '../lib/utils';

interface TitleBadgeProps {
  title: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'gradient' | 'outline';
  className?: string;
}

const sizeClasses = {
  sm: 'text-[10px] px-1.5 py-0.5',
  md: 'text-xs px-2 py-0.5',
  lg: 'text-sm px-2.5 py-1',
};

const variantClasses = {
  default: 'bg-teal-50 text-teal-700 border border-teal-200',
  gradient: 'bg-gradient-to-r from-teal-400 to-emerald-400 text-white',
  outline: 'bg-transparent text-teal-600 border-2 border-teal-300',
};

export function TitleBadge({
  title,
  size = 'md',
  variant = 'default',
  className,
}: TitleBadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full font-medium whitespace-nowrap',
        sizeClasses[size],
        variantClasses[variant],
        className
      )}
    >
      {title}
    </span>
  );
}

export default TitleBadge;
