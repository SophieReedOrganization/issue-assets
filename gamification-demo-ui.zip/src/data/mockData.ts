import type {
  VirtualReward,
  PhysicalReward,
  OrganizationReward,
  Order,
  UserGameProfile,
  Badge,
  LeaderboardEntry,
  RedemptionRecord,
  Title,
  Frame,
} from '../types/gamification';

// ============================================
// User Profile (示範用戶 - 中等活躍學生)
// ============================================

export const MOCK_USER_PROFILE: UserGameProfile = {
  userId: 'user-001',
  displayName: '小明',
  avatarEmoji: '🐱',
  level: 5,
  currentXp: 320,
  xpToNextLevel: 500,  // Lv.5 (1000) → Lv.6 (1500) 需要 500 XP
  totalXp: 1320,
  coins: 450,

  // 目前可追蹤的指標
  totalTasksCompleted: 95,         // 累計完成 95 個任務
  totalExamsPassed: 12,            // 累計 12 份試卷及格
  noGuessingExamsPassed: 8,        // 其中 8 份無猜題

  // 未來擴充（Demo 用）
  currentStreak: 12,
  longestStreak: 28,
  perfectExams: 3,

  // 稱號系統
  equippedTitle: 'title_diligent',
  ownedTitles: ['title_newbie', 'title_explorer', 'title_learner', 'title_diligent'],
};

// ============================================
// 64 個徽章定義（完整規格書資料）
// ============================================

export const MOCK_BADGES: Badge[] = [
  // ============================================
  // 📚 任務完成系列（7 個）
  // ============================================
  {
    id: 'task_10',
    name: '剛開始而已',
    description: '累計完成 10 個任務',
    tier: 'bronze',
    emoji: '📚',
    imageUrl: '/badges/task_10.png',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-20T00:00:00Z',
  },
  {
    id: 'task_30',
    name: '漸入佳境',
    description: '累計完成 30 個任務',
    tier: 'bronze',
    emoji: '📚',
    imageUrl: '/badges/task_30.png',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-28T00:00:00Z',
  },
  {
    id: 'task_50',
    name: '穩定輸出',
    description: '累計完成 50 個任務',
    tier: 'bronze',
    emoji: '📚',
    imageUrl: '/badges/task_50.png',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-05T00:00:00Z',
  },
  {
    id: 'task_100',
    name: '肝帝出沒',
    description: '累計完成 100 個任務',
    tier: 'silver',
    emoji: '📚',
    imageUrl: '/badges/task_100.png',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 95, target: 100, percentage: 95 },
  },
  {
    id: 'task_200',
    name: '刷題狂人',
    description: '累計完成 200 個任務',
    tier: 'silver',
    emoji: '📚',
    imageUrl: '/badges/task_200.png',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 95, target: 200, percentage: 47.5 },
  },
  {
    id: 'task_500',
    name: '任務終結者',
    description: '累計完成 500 個任務',
    tier: 'gold',
    emoji: '📚',
    imageUrl: '/badges/task_500.png',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 95, target: 500, percentage: 19 },
  },
  {
    id: 'task_1000',
    name: '傳說中的捲王',
    description: '累計完成 1,000 個任務',
    tier: 'diamond',
    emoji: '📚',
    imageUrl: '/badges/task_1000.png',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 95, target: 1000, percentage: 9.5 },
  },

  // ============================================
  // 📝 試卷完成系列（6 個）
  // ============================================
  {
    id: 'exam_5',
    imageUrl: '/badges/exam_5.png',
    name: '考試新手村',
    description: '累計完成 5 份試卷',
    tier: 'bronze',
    emoji: '📝',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-25T00:00:00Z',
  },
  {
    id: 'exam_15',
    imageUrl: '/badges/exam_15.png',
    name: '考卷殺手',
    description: '累計完成 15 份試卷',
    tier: 'bronze',
    emoji: '📝',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    progress: { current: 12, target: 15, percentage: 80 },
  },
  {
    id: 'exam_30',
    imageUrl: '/badges/exam_30.png',
    name: '身經百戰',
    description: '累計完成 30 份試卷',
    tier: 'silver',
    emoji: '📝',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 12, target: 30, percentage: 40 },
  },
  {
    id: 'exam_60',
    imageUrl: '/badges/exam_60.png',
    name: '考試機器',
    description: '累計完成 60 份試卷',
    tier: 'silver',
    emoji: '📝',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 12, target: 60, percentage: 20 },
  },
  {
    id: 'exam_100',
    imageUrl: '/badges/exam_100.png',
    name: '考場戰神',
    description: '累計完成 100 份試卷',
    tier: 'gold',
    emoji: '📝',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 12, target: 100, percentage: 12 },
  },
  {
    id: 'exam_200',
    imageUrl: '/badges/exam_200.png',
    name: '考神降臨',
    description: '累計完成 200 份試卷',
    tier: 'diamond',
    emoji: '📝',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 12, target: 200, percentage: 6 },
  },

  // ============================================
  // 🎯 正確率系列（6 個）
  // ============================================
  {
    id: 'acc_pass_10',
    imageUrl: '/badges/acc_pass_10.png',
    name: '安全下莊',
    description: '累計 10 份試卷正確率 ≥60%',
    tier: 'bronze',
    emoji: '🎯',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-01T00:00:00Z',
  },
  {
    id: 'acc_pass_30',
    imageUrl: '/badges/acc_pass_30.png',
    name: '穩穩der',
    description: '累計 30 份試卷正確率 ≥60%',
    tier: 'bronze',
    emoji: '🎯',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    progress: { current: 12, target: 30, percentage: 40 },
  },
  {
    id: 'acc_good_10',
    imageUrl: '/badges/acc_good_10.png',
    name: '有點東西',
    description: '累計 10 份試卷正確率 ≥80%',
    tier: 'silver',
    emoji: '🎯',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 8, target: 10, percentage: 80 },
  },
  {
    id: 'acc_good_30',
    imageUrl: '/badges/acc_good_30.png',
    name: '實力認證',
    description: '累計 30 份試卷正確率 ≥80%',
    tier: 'silver',
    emoji: '🎯',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 8, target: 30, percentage: 26.7 },
  },
  {
    id: 'acc_high_10',
    imageUrl: '/badges/acc_high_10.png',
    name: '神準狙擊手',
    description: '累計 10 份試卷正確率 ≥90%',
    tier: 'gold',
    emoji: '🎯',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 5, target: 10, percentage: 50 },
  },
  {
    id: 'acc_high_30',
    imageUrl: '/badges/acc_high_30.png',
    name: '人形答案機',
    description: '累計 30 份試卷正確率 ≥90%',
    tier: 'diamond',
    emoji: '🎯',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 5, target: 30, percentage: 16.7 },
  },

  // ============================================
  // 💯 滿分系列（6 個）
  // ============================================
  {
    id: 'perfect_1',
    imageUrl: '/badges/perfect_1.png',
    name: '開張啦',
    description: '獲得 1 次滿分',
    tier: 'bronze',
    emoji: '💯',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-30T00:00:00Z',
  },
  {
    id: 'perfect_3',
    imageUrl: '/badges/perfect_3.png',
    name: '三連滿貫',
    description: '累計 3 次滿分',
    tier: 'bronze',
    emoji: '💯',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-10T00:00:00Z',
  },
  {
    id: 'perfect_10',
    imageUrl: '/badges/perfect_10.png',
    name: '滿分常客',
    description: '累計 10 次滿分',
    tier: 'silver',
    emoji: '💯',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 3, target: 10, percentage: 30 },
  },
  {
    id: 'perfect_25',
    imageUrl: '/badges/perfect_25.png',
    name: '零失誤強迫症',
    description: '累計 25 次滿分',
    tier: 'silver',
    emoji: '💯',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 3, target: 25, percentage: 12 },
  },
  {
    id: 'perfect_50',
    imageUrl: '/badges/perfect_50.png',
    name: '滿分製造機',
    description: '累計 50 次滿分',
    tier: 'gold',
    emoji: '💯',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 3, target: 50, percentage: 6 },
  },
  {
    id: 'perfect_100',
    imageUrl: '/badges/perfect_100.png',
    name: '完美主義代言人',
    description: '累計 100 次滿分',
    tier: 'diamond',
    emoji: '💯',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 3, target: 100, percentage: 3 },
  },

  // ============================================
  // 💚 誠實作答系列（6 個）
  // ============================================
  {
    id: 'honest_5',
    imageUrl: '/badges/honest_5.png',
    name: '不猜不猜',
    description: '累計 5 份試卷無猜題',
    tier: 'bronze',
    emoji: '💚',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-28T00:00:00Z',
  },
  {
    id: 'honest_15',
    imageUrl: '/badges/honest_15.png',
    name: '腳踏實地',
    description: '累計 15 份試卷無猜題',
    tier: 'bronze',
    emoji: '💚',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    progress: { current: 8, target: 15, percentage: 53.3 },
  },
  {
    id: 'honest_30',
    imageUrl: '/badges/honest_30.png',
    name: '真材實料',
    description: '累計 30 份試卷無猜題',
    tier: 'silver',
    emoji: '💚',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 8, target: 30, percentage: 26.7 },
  },
  {
    id: 'honest_60',
    imageUrl: '/badges/honest_60.png',
    name: '硬底子學霸',
    description: '累計 60 份試卷無猜題',
    tier: 'silver',
    emoji: '💚',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 8, target: 60, percentage: 13.3 },
  },
  {
    id: 'honest_100',
    imageUrl: '/badges/honest_100.png',
    name: '靠實力不靠運氣',
    description: '累計 100 份試卷無猜題',
    tier: 'gold',
    emoji: '💚',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 8, target: 100, percentage: 8 },
  },
  {
    id: 'honest_200',
    imageUrl: '/badges/honest_200.png',
    name: '誠實界的神',
    description: '累計 200 份試卷無猜題',
    tier: 'diamond',
    emoji: '💚',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 8, target: 200, percentage: 4 },
  },

  // ============================================
  // ⭐ 任務高分系列（6 個）
  // ============================================
  {
    id: 'highscore_10',
    imageUrl: '/badges/highscore_10.png',
    name: '小有表現',
    description: '累計 10 個任務得分 ≥80',
    tier: 'bronze',
    emoji: '⭐',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-22T00:00:00Z',
  },
  {
    id: 'highscore_30',
    imageUrl: '/badges/highscore_30.png',
    name: '穩定輸出王',
    description: '累計 30 個任務得分 ≥80',
    tier: 'bronze',
    emoji: '⭐',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-08T00:00:00Z',
  },
  {
    id: 'highscore_60',
    imageUrl: '/badges/highscore_60.png',
    name: '高分提款機',
    description: '累計 60 個任務得分 ≥80',
    tier: 'silver',
    emoji: '⭐',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 48, target: 60, percentage: 80 },
  },
  {
    id: 'highscore_100',
    imageUrl: '/badges/highscore_100.png',
    name: '高分收割機',
    description: '累計 100 個任務得分 ≥80',
    tier: 'silver',
    emoji: '⭐',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 48, target: 100, percentage: 48 },
  },
  {
    id: 'highscore_200',
    imageUrl: '/badges/highscore_200.png',
    name: '分數掠奪者',
    description: '累計 200 個任務得分 ≥80',
    tier: 'gold',
    emoji: '⭐',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 48, target: 200, percentage: 24 },
  },
  {
    id: 'highscore_500',
    imageUrl: '/badges/highscore_500.png',
    name: '八十分俱樂部會長',
    description: '累計 500 個任務得分 ≥80',
    tier: 'diamond',
    emoji: '⭐',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 48, target: 500, percentage: 9.6 },
  },

  // ============================================
  // 📊 學習路徑系列（6 個）
  // ============================================
  {
    id: 'path_25',
    imageUrl: '/badges/path_25.png',
    name: '剛上路',
    description: '任一學習路徑進度達 25%',
    tier: 'bronze',
    emoji: '📊',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-18T00:00:00Z',
  },
  {
    id: 'path_50',
    imageUrl: '/badges/path_50.png',
    name: '半路殺出',
    description: '任一學習路徑進度達 50%',
    tier: 'bronze',
    emoji: '📊',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-02T00:00:00Z',
  },
  {
    id: 'path_75',
    imageUrl: '/badges/path_75.png',
    name: '就差一點點',
    description: '任一學習路徑進度達 75%',
    tier: 'silver',
    emoji: '📊',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 68, target: 75, percentage: 90.7 },
  },
  {
    id: 'path_100',
    imageUrl: '/badges/path_100.png',
    name: '破關啦',
    description: '任一學習路徑完成 100%',
    tier: 'silver',
    emoji: '📊',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 68, target: 100, percentage: 68 },
  },
  {
    id: 'path_complete_3',
    imageUrl: '/badges/path_complete_3.png',
    name: '三路通關王',
    description: '完成 3 條學習路徑',
    tier: 'gold',
    emoji: '📊',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 0, target: 3, percentage: 0 },
  },
  {
    id: 'path_complete_5',
    imageUrl: '/badges/path_complete_5.png',
    name: '全路線制霸',
    description: '完成 5 條學習路徑',
    tier: 'diamond',
    emoji: '📊',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 0, target: 5, percentage: 0 },
  },

  // ============================================
  // 🌅 早起學習系列（5 個）
  // ============================================
  {
    id: 'early_5',
    imageUrl: '/badges/early_5.png',
    name: '早八戰士',
    description: '清晨 6-8 點完成 5 個任務',
    tier: 'bronze',
    emoji: '🌅',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    progress: { current: 2, target: 5, percentage: 40 },
  },
  {
    id: 'early_20',
    imageUrl: '/badges/early_20.png',
    name: '日出刷題人',
    description: '清晨 6-8 點完成 20 個任務',
    tier: 'bronze',
    emoji: '🌅',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    progress: { current: 2, target: 20, percentage: 10 },
  },
  {
    id: 'early_50',
    imageUrl: '/badges/early_50.png',
    name: '早起內捲王',
    description: '清晨 6-8 點完成 50 個任務',
    tier: 'silver',
    emoji: '🌅',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 2, target: 50, percentage: 4 },
  },
  {
    id: 'early_100',
    imageUrl: '/badges/early_100.png',
    name: '晨讀頂尖高手',
    description: '清晨 6-8 點完成 100 個任務',
    tier: 'gold',
    emoji: '🌅',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 2, target: 100, percentage: 2 },
  },
  {
    id: 'early_300',
    imageUrl: '/badges/early_300.png',
    name: '太陽系最早起',
    description: '清晨 6-8 點完成 300 個任務',
    tier: 'diamond',
    emoji: '🌅',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 2, target: 300, percentage: 0.7 },
  },

  // ============================================
  // 🌙 夜間學習系列（5 個）
  // ============================================
  {
    id: 'night_5',
    imageUrl: '/badges/night_5.png',
    name: '夜貓出沒',
    description: '晚間 20-23 點完成 5 個任務',
    tier: 'bronze',
    emoji: '🌙',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-24T00:00:00Z',
  },
  {
    id: 'night_20',
    imageUrl: '/badges/night_20.png',
    name: '深夜食堂學習版',
    description: '晚間 20-23 點完成 20 個任務',
    tier: 'bronze',
    emoji: '🌙',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-12T00:00:00Z',
  },
  {
    id: 'night_50',
    imageUrl: '/badges/night_50.png',
    name: '月亮不睡我不睡',
    description: '晚間 20-23 點完成 50 個任務',
    tier: 'silver',
    emoji: '🌙',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 28, target: 50, percentage: 56 },
  },
  {
    id: 'night_100',
    imageUrl: '/badges/night_100.png',
    name: '熬夜冠軍',
    description: '晚間 20-23 點完成 100 個任務',
    tier: 'gold',
    emoji: '🌙',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 28, target: 100, percentage: 28 },
  },
  {
    id: 'night_300',
    imageUrl: '/badges/night_300.png',
    name: '夜行性學霸',
    description: '晚間 20-23 點完成 300 個任務',
    tier: 'diamond',
    emoji: '🌙',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 28, target: 300, percentage: 9.3 },
  },

  // ============================================
  // 📅 每日任務系列（6 個）
  // ============================================
  {
    id: 'daily_3',
    imageUrl: '/badges/daily_3.png',
    name: '三天熱度',
    description: '累計 3 天完成當日所有任務',
    tier: 'bronze',
    emoji: '📅',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-11-21T00:00:00Z',
  },
  {
    id: 'daily_7',
    imageUrl: '/badges/daily_7.png',
    name: '一週達人',
    description: '累計 7 天完成當日所有任務',
    tier: 'bronze',
    emoji: '📅',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-01T00:00:00Z',
  },
  {
    id: 'daily_14',
    imageUrl: '/badges/daily_14.png',
    name: '兩週沒翹課',
    description: '累計 14 天完成當日所有任務',
    tier: 'silver',
    emoji: '📅',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 10, target: 14, percentage: 71.4 },
  },
  {
    id: 'daily_30',
    imageUrl: '/badges/daily_30.png',
    name: '整月全勤獎',
    description: '累計 30 天完成當日所有任務',
    tier: 'silver',
    emoji: '📅',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 10, target: 30, percentage: 33.3 },
  },
  {
    id: 'daily_60',
    imageUrl: '/badges/daily_60.png',
    name: '打卡狂魔',
    description: '累計 60 天完成當日所有任務',
    tier: 'gold',
    emoji: '📅',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 10, target: 60, percentage: 16.7 },
  },
  {
    id: 'daily_100',
    imageUrl: '/badges/daily_100.png',
    name: '百日無缺席',
    description: '累計 100 天完成當日所有任務',
    tier: 'diamond',
    emoji: '📅',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 10, target: 100, percentage: 10 },
  },

  // ============================================
  // 🎁 收集系列（5 個）
  // ============================================
  {
    id: 'collect_10',
    imageUrl: '/badges/collect_10.png',
    name: '集章新手',
    description: '收集 10 個徽章',
    tier: 'bronze',
    emoji: '🎁',
    xpReward: 30,
    coinReward: 10,
    isHidden: false,
    earnedAt: '2024-12-05T00:00:00Z',
  },
  {
    id: 'collect_25',
    imageUrl: '/badges/collect_25.png',
    name: '勳章控',
    description: '收集 25 個徽章',
    tier: 'silver',
    emoji: '🎁',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 18, target: 25, percentage: 72 },
  },
  {
    id: 'collect_50',
    imageUrl: '/badges/collect_50.png',
    name: '徽章獵人',
    description: '收集 50 個徽章',
    tier: 'silver',
    emoji: '🎁',
    xpReward: 75,
    coinReward: 30,
    isHidden: false,
    progress: { current: 18, target: 50, percentage: 36 },
  },
  {
    id: 'collect_55',
    imageUrl: '/badges/collect_55.png',
    name: '榮譽蒐藏家',
    description: '收集 55 個徽章',
    tier: 'gold',
    emoji: '🎁',
    xpReward: 150,
    coinReward: 75,
    isHidden: false,
    progress: { current: 18, target: 55, percentage: 32.7 },
  },
  {
    id: 'collect_all',
    imageUrl: '/badges/collect_all.png',
    name: '全成就解鎖',
    description: '收集所有 59 個非收集類徽章',
    tier: 'diamond',
    emoji: '🎁',
    xpReward: 300,
    coinReward: 150,
    isHidden: false,
    progress: { current: 18, target: 59, percentage: 30.5 },
  },
];

// ============================================
// 31 個頭像框定義（完整規格書資料）
// ============================================

export const MOCK_FRAMES: Frame[] = [
  // ============================================
  // 免費贈送（4 個）- T1 Common
  // ============================================
  { id: 'frame_default',
    imageUrl: '/frames/frame_default.png', name: '素面圓框', description: '乾淨簡約的基礎框', rarity: 'common', acquisitionType: 'free' },
  { id: 'frame_welcome',
    imageUrl: '/frames/frame_welcome.png', name: '新手小白框', description: '歡迎新同學', rarity: 'common', acquisitionType: 'free' },
  { id: 'frame_first_task',
    imageUrl: '/frames/frame_first_task.png', name: '起步框', description: '第一步最重要', rarity: 'common', acquisitionType: 'free' },
  { id: 'frame_first_exam',
    imageUrl: '/frames/frame_first_exam.png', name: '初試身手框', description: '勇敢嘗試', rarity: 'common', acquisitionType: 'free' },

  // ============================================
  // 成就解鎖 - 任務系列（3 個）- T2~T4
  // ============================================
  { id: 'frame_task_bronze',
    imageUrl: '/frames/frame_task_bronze.png', name: '勤勞蜜蜂框', description: '努力的證明', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '50 tasks' },
  { id: 'frame_task_silver',
    imageUrl: '/frames/frame_task_silver.png', name: '任務達人框', description: '穩定輸出', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '200 tasks' },
  { id: 'frame_task_gold',
    imageUrl: '/frames/frame_task_gold.png', name: '任務之王框', description: '傳說中的肝帝', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '500 tasks' },

  // ============================================
  // 成就解鎖 - 試卷系列（3 個）- T2~T4
  // ============================================
  { id: 'frame_exam_bronze',
    imageUrl: '/frames/frame_exam_bronze.png', name: '考試新手框', description: '開始挑戰', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '15 exams' },
  { id: 'frame_exam_silver',
    imageUrl: '/frames/frame_exam_silver.png', name: '考場老手框', description: '身經百戰', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '60 exams' },
  { id: 'frame_exam_gold',
    imageUrl: '/frames/frame_exam_gold.png', name: '考神認證框', description: '考試之神', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '100 exams' },

  // ============================================
  // 成就解鎖 - 滿分系列（3 個）- T2~T4
  // ============================================
  { id: 'frame_perfect_bronze',
    imageUrl: '/frames/frame_perfect_bronze.png', name: '滿分新星框', description: '初嚐滿分', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '5 perfect' },
  { id: 'frame_perfect_silver',
    imageUrl: '/frames/frame_perfect_silver.png', name: '滿分達人框', description: '滿分常客', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '25 perfect' },
  { id: 'frame_perfect_gold',
    imageUrl: '/frames/frame_perfect_gold.png', name: '零失誤框', description: '完美主義', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '50 perfect' },

  // ============================================
  // 成就解鎖 - 誠實系列（3 個）- T2~T4
  // ============================================
  { id: 'frame_honest_bronze',
    imageUrl: '/frames/frame_honest_bronze.png', name: '誠實小將框', description: '腳踏實地', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '20 honest' },
  { id: 'frame_honest_silver',
    imageUrl: '/frames/frame_honest_silver.png', name: '實力派框', description: '真材實料', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '60 honest' },
  { id: 'frame_honest_gold',
    imageUrl: '/frames/frame_honest_gold.png', name: '硬底子框', description: '靠實力說話', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '100 honest' },

  // ============================================
  // 金幣購買 - 入門級（200-250 幣）Lv.1-2 - T2
  // ============================================
  { id: 'frame_star',
    imageUrl: '/frames/frame_star.png', name: '星星框', description: '閃閃發光', rarity: 'bronze', acquisitionType: 'purchase', price: 200, requiredLevel: 1 },
  { id: 'frame_forest',
    imageUrl: '/frames/frame_forest.png', name: '森林框', description: '自然的綠', rarity: 'bronze', acquisitionType: 'purchase', price: 200, requiredLevel: 1 },
  { id: 'frame_rainbow',
    imageUrl: '/frames/frame_rainbow.png', name: '彩虹框', description: '七彩繽紛', rarity: 'bronze', acquisitionType: 'purchase', price: 250, requiredLevel: 2 },

  // ============================================
  // 金幣購買 - 基礎級（350-400 幣）Lv.3-4 - T3
  // ============================================
  { id: 'frame_lightning',
    imageUrl: '/frames/frame_lightning.png', name: '閃電框', description: '電力十足', rarity: 'silver', acquisitionType: 'purchase', price: 350, requiredLevel: 3 },
  { id: 'frame_legendary',
    imageUrl: '/frames/frame_legendary.png', name: '傳奇框', description: '閃耀光芒', rarity: 'silver', acquisitionType: 'purchase', price: 350, requiredLevel: 3 },
  { id: 'frame_candy',
    imageUrl: '/frames/frame_candy.png', name: '糖果框', description: '甜甜的', rarity: 'silver', acquisitionType: 'purchase', price: 400, requiredLevel: 4 },

  // ============================================
  // 金幣購買 - 進階級（500-700 幣）Lv.5-7 - T3~T4
  // ============================================
  { id: 'frame_flame',
    imageUrl: '/frames/frame_flame.png', name: '烈焰框', description: '燃燒吧', rarity: 'silver', acquisitionType: 'purchase', price: 500, requiredLevel: 5 },
  { id: 'frame_ocean',
    imageUrl: '/frames/frame_ocean.png', name: '深海框', description: '海洋之心', rarity: 'silver', acquisitionType: 'purchase', price: 550, requiredLevel: 6 },
  { id: 'frame_sakura',
    imageUrl: '/frames/frame_sakura.png', name: '櫻花雨框', description: '浪漫飄落', rarity: 'gold', acquisitionType: 'purchase', price: 700, requiredLevel: 7 },

  // ============================================
  // 金幣購買 - 高級級（800-1200 幣）Lv.8-12 - T4
  // ============================================
  { id: 'frame_neon',
    imageUrl: '/frames/frame_neon.png', name: '霓虹派對框', description: '夜店風', rarity: 'gold', acquisitionType: 'purchase', price: 800, requiredLevel: 8 },
  { id: 'frame_crystal',
    imageUrl: '/frames/frame_crystal.png', name: '水晶寶石框', description: '璀璨奪目', rarity: 'gold', acquisitionType: 'purchase', price: 1000, requiredLevel: 10 },
  { id: 'frame_galaxy',
    imageUrl: '/frames/frame_galaxy.png', name: '銀河星雲框', description: '宇宙浩瀚', rarity: 'gold', acquisitionType: 'purchase', price: 1200, requiredLevel: 12 },

  // ============================================
  // 金幣購買 - 頂級（1500-3000 幣）Lv.15-20 - T5 Legendary
  // ============================================
  { id: 'frame_phoenix',
    imageUrl: '/frames/frame_phoenix.png', name: '鳳凰涅槃框', description: '浴火重生', rarity: 'legendary', acquisitionType: 'purchase', price: 1500, requiredLevel: 15 },
  { id: 'frame_dragon',
    imageUrl: '/frames/frame_dragon.png', name: '神龍騰雲框', description: '龍的傳人', rarity: 'legendary', acquisitionType: 'purchase', price: 2000, requiredLevel: 18 },
  { id: 'frame_ultimate',
    imageUrl: '/frames/frame_ultimate.png', name: '至尊榮耀框', description: '頂級尊貴', rarity: 'legendary', acquisitionType: 'purchase', price: 3000, requiredLevel: 20 },
];

// ============================================
// 30 個稱號定義（完整規格書資料）
// ============================================

export const MOCK_TITLES: Title[] = [
  // 免費贈送（3 個）
  { id: 'title_newbie', name: '萌新一枚', description: '註冊即獲得', rarity: 'common', acquisitionType: 'free' },
  { id: 'title_explorer', name: '好奇寶寶', description: '完成新手引導', rarity: 'common', acquisitionType: 'free' },
  { id: 'title_learner', name: '認真上課中', description: '累計完成 10 個任務', rarity: 'common', acquisitionType: 'free' },
  // 成就解鎖 - 任務相關（3 個）
  { id: 'title_diligent', name: '勤奮小蜜蜂', description: '累計完成 30 個任務', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '30 tasks' },
  { id: 'title_hardworker', name: '努力擔當', description: '累計完成 100 個任務', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '100 tasks' },
  { id: 'title_scholar', name: '超級捲王', description: '累計完成 300 個任務', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '300 tasks' },
  // 成就解鎖 - 試卷相關（3 個）
  { id: 'title_exam_rookie', name: '考試菜鳥', description: '累計完成 10 份試卷', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '10 exams' },
  { id: 'title_exam_veteran', name: '考試老司機', description: '累計完成 50 份試卷', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '50 exams' },
  { id: 'title_exam_master', name: '考神本人', description: '累計完成 100 份試卷', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '100 exams' },
  // 成就解鎖 - 正確率相關（3 個）
  { id: 'title_accurate', name: '穩定發揮', description: '累計 10 份試卷正確率 ≥80%', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '10 exams ≥80%' },
  { id: 'title_sharpshooter', name: '命中率爆表', description: '累計 30 份試卷正確率 ≥80%', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '30 exams ≥80%' },
  { id: 'title_sniper', name: '答案狙擊手', description: '累計 10 份試卷正確率 ≥90%', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '10 exams ≥90%' },
  // 成就解鎖 - 誠實相關（3 個）
  { id: 'title_honest_kid', name: '不靠運氣', description: '累計 10 份無猜題試卷', rarity: 'bronze', acquisitionType: 'achievement', unlockCondition: '10 honest' },
  { id: 'title_honest_star', name: '真才實學', description: '累計 50 份無猜題試卷', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '50 honest' },
  { id: 'title_integrity', name: '硬底子學霸', description: '累計 100 份無猜題試卷', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '100 honest' },
  // 成就解鎖 - 特殊相關（3 個）
  { id: 'title_early_bird', name: '早八勇者', description: '清晨 6-8 點完成 30 個任務', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '30 early tasks' },
  { id: 'title_night_owl', name: '夜貓學霸', description: '晚間 20-23 點完成 30 個任務', rarity: 'silver', acquisitionType: 'achievement', unlockCondition: '30 night tasks' },
  { id: 'title_perfectionist', name: '滿分狂人', description: '累計 30 次滿分', rarity: 'gold', acquisitionType: 'achievement', unlockCondition: '30 perfect' },
  // 金幣兌換（12 個）
  { id: 'title_cool', name: '帥氣登場', description: '展現個人風格', rarity: 'bronze', acquisitionType: 'purchase', price: 200, requiredLevel: 1 },
  { id: 'title_smart', name: '頭腦很好', description: '聰明伶俐的你', rarity: 'bronze', acquisitionType: 'purchase', price: 200, requiredLevel: 1 },
  { id: 'title_brave', name: '勇者無懼', description: '勇於挑戰的精神', rarity: 'bronze', acquisitionType: 'purchase', price: 250, requiredLevel: 2 },
  { id: 'title_genius', name: '小小天才', description: '天資聰穎', rarity: 'silver', acquisitionType: 'purchase', price: 300, requiredLevel: 2 },
  { id: 'title_star_student', name: '班上風雲人物', description: '閃耀的學習之星', rarity: 'silver', acquisitionType: 'purchase', price: 400, requiredLevel: 3 },
  { id: 'title_champion', name: '學習王者', description: '學習競賽的王者', rarity: 'silver', acquisitionType: 'purchase', price: 500, requiredLevel: 5 },
  { id: 'title_professor', name: '學問很大', description: '博學多聞', rarity: 'gold', acquisitionType: 'purchase', price: 600, requiredLevel: 7 },
  { id: 'title_sage', name: '智慧擔當', description: '智慧的化身', rarity: 'gold', acquisitionType: 'purchase', price: 700, requiredLevel: 8 },
  { id: 'title_master', name: '學習之神', description: '精通學習之道', rarity: 'gold', acquisitionType: 'purchase', price: 800, requiredLevel: 10 },
  { id: 'title_legend', name: '傳說中的人', description: '傳說中的學習者', rarity: 'legendary', acquisitionType: 'purchase', price: 1000, requiredLevel: 12 },
  { id: 'title_immortal', name: '學神降臨', description: '學習的神話', rarity: 'legendary', acquisitionType: 'purchase', price: 1500, requiredLevel: 15 },
  { id: 'title_supreme', name: '宇宙最強', description: '最高榮譽稱號', rarity: 'legendary', acquisitionType: 'purchase', price: 2000, requiredLevel: 20 },
];

// Helper function to get title by ID
export function getTitleById(titleId: string): Title | undefined {
  return MOCK_TITLES.find(t => t.id === titleId);
}

// Helper function to get frame by ID
export function getFrameById(frameId: string): Frame | undefined {
  return MOCK_FRAMES.find(f => f.id === frameId);
}

// ============================================
// Platform Shop - Virtual Rewards (頭像框+稱號+表情包)
// ============================================

export const MOCK_VIRTUAL_REWARDS: VirtualReward[] = [
  // ============================================
  // 頭像框 - 入門級（200-250 XP）Lv.1-2 - T2
  // ============================================
  { id: 'vr-frame-star',
    imageUrl: '/frames/frame_star.png', name: '星星框', description: '閃閃發光', price: 200, currency: 'xp', emoji: '⭐', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 1 },
  { id: 'vr-frame-forest',
    imageUrl: '/frames/frame_forest.png', name: '森林框', description: '自然的綠', price: 200, currency: 'xp', emoji: '🌿', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 1 },
  { id: 'vr-frame-rainbow',
    imageUrl: '/frames/frame_rainbow.png', name: '彩虹框', description: '七彩繽紛', price: 250, currency: 'xp', emoji: '🌈', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 2 },

  // ============================================
  // 頭像框 - 基礎級（350-400 XP）Lv.3-4 - T3
  // ============================================
  { id: 'vr-frame-lightning',
    imageUrl: '/frames/frame_lightning.png', name: '閃電框', description: '電力十足', price: 350, currency: 'xp', emoji: '⚡', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 3 },
  { id: 'vr-frame-legendary',
    imageUrl: '/frames/frame_legendary.png', name: '傳奇框', description: '閃耀光芒', price: 350, currency: 'xp', emoji: '✨', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 3 },
  { id: 'vr-frame-candy',
    imageUrl: '/frames/frame_candy.png', name: '糖果框', description: '甜甜的', price: 400, currency: 'xp', emoji: '🍬', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 4 },

  // ============================================
  // 頭像框 - 進階級（500-700 XP）Lv.5-7 - T3~T4
  // ============================================
  { id: 'vr-frame-flame',
    imageUrl: '/frames/frame_flame.png', name: '烈焰框', description: '燃燒吧', price: 500, currency: 'xp', emoji: '🔥', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 5 },
  { id: 'vr-frame-ocean',
    imageUrl: '/frames/frame_ocean.png', name: '深海框', description: '海洋之心', price: 550, currency: 'xp', emoji: '🌊', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 6 },
  { id: 'vr-frame-sakura',
    imageUrl: '/frames/frame_sakura.png', name: '櫻花雨框', description: '浪漫飄落', price: 700, currency: 'xp', emoji: '🌸', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 7 },

  // ============================================
  // 頭像框 - 高級級（800-1200 XP）Lv.8-12 - T4
  // ============================================
  { id: 'vr-frame-neon',
    imageUrl: '/frames/frame_neon.png', name: '霓虹派對框', description: '夜店風', price: 800, currency: 'xp', emoji: '💜', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 8 },
  { id: 'vr-frame-crystal',
    imageUrl: '/frames/frame_crystal.png', name: '水晶寶石框', description: '璀璨奪目', price: 1000, currency: 'xp', emoji: '💎', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 10 },
  { id: 'vr-frame-galaxy',
    imageUrl: '/frames/frame_galaxy.png', name: '銀河星雲框', description: '宇宙浩瀚', price: 1200, currency: 'xp', emoji: '🌌', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 12 },

  // ============================================
  // 頭像框 - 頂級（1500-3000 XP）Lv.15-20 - T5 Legendary
  // ============================================
  { id: 'vr-frame-phoenix',
    imageUrl: '/frames/frame_phoenix.png', name: '鳳凰涅槃框', description: '浴火重生', price: 1500, currency: 'xp', emoji: '🦅', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 15 },
  { id: 'vr-frame-dragon',
    imageUrl: '/frames/frame_dragon.png', name: '神龍騰雲框', description: '龍的傳人', price: 2000, currency: 'xp', emoji: '🐉', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 18 },
  { id: 'vr-frame-ultimate',
    imageUrl: '/frames/frame_ultimate.png', name: '至尊榮耀框', description: '頂級尊貴', price: 3000, currency: 'xp', emoji: '👑', stock: 999, type: 'virtual', category: 'avatar_frame', requiredLevel: 20 },

  // ============================================
  // 稱號 - 入門級（200-250 XP）Lv.1-2
  // ============================================
  { id: 'vr-title-cool', name: '帥氣登場', description: '展現個人風格', price: 200, currency: 'xp', emoji: '😎', stock: 999, type: 'virtual', category: 'title', requiredLevel: 1 },
  { id: 'vr-title-smart', name: '頭腦很好', description: '聰明伶俐的你', price: 200, currency: 'xp', emoji: '🧠', stock: 999, type: 'virtual', category: 'title', requiredLevel: 1 },
  { id: 'vr-title-brave', name: '勇者無懼', description: '勇於挑戰的精神', price: 250, currency: 'xp', emoji: '💪', stock: 999, type: 'virtual', category: 'title', requiredLevel: 2 },

  // ============================================
  // 稱號 - 基礎級（300-400 XP）Lv.2-3
  // ============================================
  { id: 'vr-title-genius', name: '小小天才', description: '天資聰穎', price: 300, currency: 'xp', emoji: '🌟', stock: 999, type: 'virtual', category: 'title', requiredLevel: 2 },
  { id: 'vr-title-star_student', name: '班上風雲人物', description: '閃耀的學習之星', price: 400, currency: 'xp', emoji: '⭐', stock: 999, type: 'virtual', category: 'title', requiredLevel: 3 },

  // ============================================
  // 稱號 - 進階級（500-700 XP）Lv.5-8
  // ============================================
  { id: 'vr-title-champion', name: '學習王者', description: '學習競賽的王者', price: 500, currency: 'xp', emoji: '🏆', stock: 999, type: 'virtual', category: 'title', requiredLevel: 5 },
  { id: 'vr-title-professor', name: '學問很大', description: '博學多聞', price: 600, currency: 'xp', emoji: '🎓', stock: 999, type: 'virtual', category: 'title', requiredLevel: 7 },
  { id: 'vr-title-sage', name: '智慧擔當', description: '智慧的化身', price: 700, currency: 'xp', emoji: '📚', stock: 999, type: 'virtual', category: 'title', requiredLevel: 8 },

  // ============================================
  // 稱號 - 高級級（800-1200 XP）Lv.10-12
  // ============================================
  { id: 'vr-title-master', name: '學習之神', description: '精通學習之道', price: 800, currency: 'xp', emoji: '🔮', stock: 999, type: 'virtual', category: 'title', requiredLevel: 10 },
  { id: 'vr-title-legend', name: '傳說中的人', description: '傳說中的學習者', price: 1200, currency: 'xp', emoji: '🦁', stock: 999, type: 'virtual', category: 'title', requiredLevel: 12 },

  // ============================================
  // 稱號 - 頂級（1500-2500 XP）Lv.15-20
  // ============================================
  { id: 'vr-title-immortal', name: '學神降臨', description: '學習的神話', price: 1500, currency: 'xp', emoji: '👑', stock: 999, type: 'virtual', category: 'title', requiredLevel: 15 },
  { id: 'vr-title-supreme', name: '宇宙最強', description: '最高榮譽稱號', price: 2500, currency: 'xp', emoji: '✨', stock: 999, type: 'virtual', category: 'title', requiredLevel: 20 },
];

// ============================================
// Platform Shop - Physical Rewards (符合規格書定價)
// ============================================

export const MOCK_PHYSICAL_REWARDS: PhysicalReward[] = [
  {
    id: 'pr-001',
    name: '精美鉛筆',
    description: '卡通圖案鉛筆一支',
    price: 50,
    currency: 'coins',
    emoji: '✏️',
    stock: 50,
    type: 'physical',
    redemptionInstructions: '請至補習班櫃檯出示兌換碼領取',
    expiryDays: 30,
  },
  {
    id: 'pr-002',
    name: '造型橡皮擦',
    description: '可愛造型橡皮擦一個',
    price: 80,
    currency: 'coins',
    emoji: '🧽',
    stock: 40,
    type: 'physical',
    redemptionInstructions: '請至補習班櫃檯出示兌換碼領取',
    expiryDays: 30,
  },
  {
    id: 'pr-003',
    name: '乖乖餅乾',
    description: '經典綠色乖乖一包',
    price: 100,
    currency: 'coins',
    emoji: '🍪',
    stock: 30,
    type: 'physical',
    redemptionInstructions: '請至補習班櫃檯出示兌換碼領取',
    expiryDays: 14,
  },
  {
    id: 'pr-004',
    name: '超商飲料',
    description: '7-11 或全家飲料兌換券',
    price: 250,
    currency: 'coins',
    emoji: '🧃',
    stock: 20,
    type: 'physical',
    redemptionInstructions: '請至補習班櫃檯領取兌換券，再至超商使用',
    expiryDays: 60,
  },
  {
    id: 'pr-005',
    name: '麥當勞中薯',
    description: '麥當勞中薯兌換券',
    price: 500,
    currency: 'coins',
    emoji: '🍟',
    stock: 10,
    type: 'physical',
    redemptionInstructions: '請至補習班櫃檯領取兌換券，再至麥當勞門市使用',
    expiryDays: 90,
  },
];

// ============================================
// Organization Shop - Demo 補習班 專屬獎品
// ============================================

export const MOCK_ORG_REWARDS: OrganizationReward[] = [
  {
    id: 'org-001',
    name: '免作業券',
    description: '可免除一次作業，需老師簽核',
    price: 80,
    currency: 'coins',
    emoji: '📝',
    stock: 5,
    type: 'physical',
    organizationId: 'demo-org',
    organizationName: 'Demo 補習班',
    category: 'privilege',
    createdAt: '2024-12-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
  },
  {
    id: 'org-002',
    name: '遲到免責券',
    description: '可免除一次遲到記點，需老師簽核',
    price: 120,
    currency: 'coins',
    emoji: '⏰',
    stock: 3,
    type: 'physical',
    organizationId: 'demo-org',
    organizationName: 'Demo 補習班',
    category: 'privilege',
    createdAt: '2024-12-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
  },
  {
    id: 'org-003',
    name: '換座位券',
    description: '可選擇下次上課座位',
    price: 60,
    currency: 'coins',
    emoji: '💺',
    stock: 8,
    type: 'physical',
    organizationId: 'demo-org',
    organizationName: 'Demo 補習班',
    category: 'privilege',
    createdAt: '2024-12-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
  },
  {
    id: 'org-004',
    name: '小老師體驗券',
    description: '擔任一節課的小老師',
    price: 150,
    currency: 'coins',
    emoji: '👨‍🏫',
    stock: 2,
    type: 'physical',
    organizationId: 'demo-org',
    organizationName: 'Demo 補習班',
    category: 'privilege',
    createdAt: '2024-12-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
  },
  {
    id: 'org-005',
    name: '點心加購券',
    description: '下課時間可加購一份點心',
    price: 40,
    currency: 'coins',
    emoji: '🍰',
    stock: 15,
    type: 'physical',
    organizationId: 'demo-org',
    organizationName: 'Demo 補習班',
    category: 'physical',
    createdAt: '2024-12-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
  },
];

// ============================================
// Orders
// ============================================

export const MOCK_ORDERS: Order[] = [
  {
    id: 'ORD-2024-001',
    rewardId: 'pr-001',
    rewardName: '精美鉛筆',
    rewardEmoji: '✏️',
    rewardType: 'physical',
    shopType: 'platform',
    currencySpent: 50,
    currencyType: 'coins',
    redemptionCode: 'GAME-ABCD-1234',
    status: 'ready',
    createdAt: '2024-12-20T10:30:00Z',
    expiresAt: '2025-01-20T10:30:00Z',
    redemptionInstructions: '請至補習班櫃檯出示兌換碼領取',
  },
  {
    id: 'ORD-2024-002',
    rewardId: 'org-001',
    rewardName: '免作業券',
    rewardEmoji: '📝',
    rewardType: 'physical',
    shopType: 'organization',
    organizationName: 'Demo 補習班',
    currencySpent: 80,
    currencyType: 'coins',
    redemptionCode: 'DEMO-WXYZ-5678',
    status: 'ready',
    createdAt: '2024-12-18T14:20:00Z',
    expiresAt: '2025-01-18T14:20:00Z',
    redemptionInstructions: '請向老師出示兌換碼，並經老師簽核後使用',
  },
  {
    id: 'ORD-2024-003',
    rewardId: 'vr-title-cool',
    rewardName: '酷炫小子',
    rewardEmoji: '😎',
    rewardType: 'virtual',
    shopType: 'platform',
    currencySpent: 200,
    currencyType: 'xp',
    status: 'completed',
    createdAt: '2024-12-15T09:00:00Z',
    completedAt: '2024-12-15T09:00:00Z',
  },
  {
    id: 'ORD-2024-004',
    rewardId: 'pr-003',
    rewardName: '乖乖餅乾',
    rewardEmoji: '🍪',
    rewardType: 'physical',
    shopType: 'platform',
    currencySpent: 100,
    currencyType: 'coins',
    redemptionCode: 'GAME-EFGH-9012',
    status: 'completed',
    createdAt: '2024-12-10T11:45:00Z',
    completedAt: '2024-12-12T16:30:00Z',
    redemptionInstructions: '請至補習班櫃檯出示兌換碼領取',
  },
];

// ============================================
// Leaderboard (排行榜)
// ============================================

export const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, userId: 'user-top1', displayName: '學霸王', avatarEmoji: '🦁', level: 12, value: 8420, change: 0 },
  { rank: 2, userId: 'user-top2', displayName: '小天才', avatarEmoji: '🐯', level: 11, value: 7850, change: 1 },
  { rank: 3, userId: 'user-top3', displayName: '努力達人', avatarEmoji: '🐻', level: 10, value: 7200, change: -1 },
  { rank: 4, userId: 'user-top4', displayName: '認真小子', avatarEmoji: '🐼', level: 9, value: 6580, change: 2 },
  { rank: 5, userId: 'user-top5', displayName: '好學生', avatarEmoji: '🐨', level: 8, value: 5920, change: 0 },
  { rank: 6, userId: 'user-top6', displayName: '加油王', avatarEmoji: '🐸', level: 7, value: 4850, change: -2 },
  { rank: 7, userId: 'user-001', displayName: '小明', avatarEmoji: '🐱', level: 5, value: 1320, change: 3, isCurrentUser: true },
  { rank: 8, userId: 'user-top8', displayName: '小花', avatarEmoji: '🐰', level: 5, value: 1280, change: -1 },
  { rank: 9, userId: 'user-top9', displayName: '阿強', avatarEmoji: '🐶', level: 4, value: 980, change: 0 },
  { rank: 10, userId: 'user-top10', displayName: '小美', avatarEmoji: '🦊', level: 4, value: 920, change: 1 },
];

// ============================================
// Organization Management - Redemption Records
// ============================================

export const MOCK_REDEMPTION_RECORDS: RedemptionRecord[] = [
  {
    id: 'rec-001',
    orderId: 'ORD-2024-002',
    studentId: 'user-001',
    studentName: '小明',
    rewardId: 'org-001',
    rewardName: '免作業券',
    currencySpent: 80,
    currencyType: 'coins',
    redemptionCode: 'DEMO-WXYZ-5678',
    status: 'ready',
    createdAt: '2024-12-18T14:20:00Z',
  },
  {
    id: 'rec-002',
    orderId: 'ORD-2024-010',
    studentId: 'user-top2',
    studentName: '小天才',
    rewardId: 'org-003',
    rewardName: '換座位券',
    currencySpent: 60,
    currencyType: 'coins',
    redemptionCode: 'DEMO-QRST-9999',
    status: 'completed',
    createdAt: '2024-12-15T09:30:00Z',
    completedAt: '2024-12-16T10:00:00Z',
  },
  {
    id: 'rec-003',
    orderId: 'ORD-2024-011',
    studentId: 'user-top3',
    studentName: '努力達人',
    rewardId: 'org-002',
    rewardName: '遲到免責券',
    currencySpent: 120,
    currencyType: 'coins',
    redemptionCode: 'DEMO-UVWX-7777',
    status: 'ready',
    createdAt: '2024-12-20T08:15:00Z',
  },
];

// ============================================
// Helper Functions
// ============================================

export function generateRedemptionCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const segments = [4, 4, 4];
  return segments
    .map((len) =>
      Array.from({ length: len }, () =>
        chars.charAt(Math.floor(Math.random() * chars.length))
      ).join('')
    )
    .join('-');
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('zh-TW', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function formatDateTime(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('zh-TW', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getStatusText(status: Order['status']): string {
  const statusMap: Record<Order['status'], string> = {
    pending: '處理中',
    ready: '待領取',
    completed: '已完成',
    expired: '已過期',
    cancelled: '已取消',
  };
  return statusMap[status];
}

export function getStatusColor(status: Order['status']): string {
  const colorMap: Record<Order['status'], string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    ready: 'bg-green-100 text-green-800',
    completed: 'bg-gray-100 text-gray-600',
    expired: 'bg-red-100 text-red-800',
    cancelled: 'bg-gray-100 text-gray-500',
  };
  return colorMap[status];
}

// ============================================
// 徽章統計函數
// ============================================

export function getBadgeStats() {
  const earned = MOCK_BADGES.filter(b => b.earnedAt);
  const inProgress = MOCK_BADGES.filter(b => b.progress && !b.earnedAt);
  const locked = MOCK_BADGES.filter(b => !b.earnedAt && !b.progress);

  const byTier = {
    bronze: MOCK_BADGES.filter(b => b.tier === 'bronze'),
    silver: MOCK_BADGES.filter(b => b.tier === 'silver'),
    gold: MOCK_BADGES.filter(b => b.tier === 'gold'),
    diamond: MOCK_BADGES.filter(b => b.tier === 'diamond'),
  };

  return {
    total: MOCK_BADGES.length,
    earned: earned.length,
    inProgress: inProgress.length,
    locked: locked.length,
    byTier: {
      bronze: { total: byTier.bronze.length, earned: byTier.bronze.filter(b => b.earnedAt).length },
      silver: { total: byTier.silver.length, earned: byTier.silver.filter(b => b.earnedAt).length },
      gold: { total: byTier.gold.length, earned: byTier.gold.filter(b => b.earnedAt).length },
      diamond: { total: byTier.diamond.length, earned: byTier.diamond.filter(b => b.earnedAt).length },
    },
  };
}

// ============================================
// Org Admin Mock Data
// ============================================

import type {
  ShopProduct,
  AdminOrder,
  ShopStats,
  SalesDataPoint,
  TopProduct,
  StudentSpending,
  Organization,
} from '../types/org-admin';

// 機構資訊
export const MOCK_ORGANIZATION: Organization = {
  id: 'demo-org',
  name: 'Demo 補習班',
  slug: 'demo',
  logoUrl: undefined,
  shopEnabled: true,
  shopSettings: {
    allowPhysicalRewards: true,
    allowPrivileges: true,
    maxDailyOrders: 10,
    orderExpiryDays: 7,
  },
  studentCount: 156,
  activeStudents: 89,
  createdAt: '2024-01-01T00:00:00Z',
  updatedAt: '2024-12-01T00:00:00Z',
};

// 機構商品列表 (完整版)
export const MOCK_ADMIN_PRODUCTS: ShopProduct[] = [
  {
    id: 'prod-001',
    name: '免作業券',
    description: '可免除一次作業，需老師簽核',
    emoji: '📝',
    type: 'privilege',
    category: 'homework',
    price: 80,
    currency: 'coins',
    requiredLevel: 1,
    maxPerUser: 3,
    stock: 5,
    lowStockThreshold: 2,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 28,
    totalRevenue: 2240,
    createdAt: '2024-10-01T00:00:00Z',
    updatedAt: '2024-12-20T00:00:00Z',
  },
  {
    id: 'prod-002',
    name: '遲到免責券',
    description: '可免除一次遲到記點，需老師簽核',
    emoji: '⏰',
    type: 'privilege',
    category: 'attendance',
    price: 120,
    currency: 'coins',
    requiredLevel: 2,
    maxPerUser: 2,
    stock: 3,
    lowStockThreshold: 1,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 15,
    totalRevenue: 1800,
    createdAt: '2024-10-01T00:00:00Z',
    updatedAt: '2024-12-18T00:00:00Z',
  },
  {
    id: 'prod-003',
    name: '換座位券',
    description: '可選擇下次上課座位',
    emoji: '💺',
    type: 'privilege',
    category: 'seating',
    price: 60,
    currency: 'coins',
    requiredLevel: 1,
    maxPerUser: 5,
    stock: 8,
    lowStockThreshold: 3,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 42,
    totalRevenue: 2520,
    createdAt: '2024-10-01T00:00:00Z',
    updatedAt: '2024-12-19T00:00:00Z',
  },
  {
    id: 'prod-004',
    name: '小老師體驗券',
    description: '擔任一節課的小老師',
    emoji: '👨‍🏫',
    type: 'privilege',
    category: 'experience',
    price: 150,
    currency: 'coins',
    requiredLevel: 5,
    maxPerUser: 1,
    stock: 2,
    lowStockThreshold: 1,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 5,
    totalRevenue: 750,
    createdAt: '2024-10-15T00:00:00Z',
    updatedAt: '2024-12-10T00:00:00Z',
  },
  {
    id: 'prod-005',
    name: '點心加購券',
    description: '下課時間可加購一份點心',
    emoji: '🍰',
    type: 'physical',
    category: 'snack',
    price: 40,
    currency: 'coins',
    requiredLevel: 1,
    maxPerUser: 10,
    stock: 15,
    lowStockThreshold: 5,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 89,
    totalRevenue: 3560,
    createdAt: '2024-10-01T00:00:00Z',
    updatedAt: '2024-12-21T00:00:00Z',
  },
  {
    id: 'prod-006',
    name: '巧克力棒',
    description: '美味的巧克力棒一支',
    emoji: '🍫',
    type: 'physical',
    category: 'snack',
    price: 30,
    currency: 'coins',
    requiredLevel: 1,
    maxPerUser: 0,
    stock: 25,
    lowStockThreshold: 10,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 156,
    totalRevenue: 4680,
    createdAt: '2024-09-01T00:00:00Z',
    updatedAt: '2024-12-21T00:00:00Z',
  },
  {
    id: 'prod-007',
    name: '造型橡皮擦',
    description: '可愛造型橡皮擦一個',
    emoji: '🧽',
    type: 'physical',
    category: 'stationery',
    price: 50,
    currency: 'coins',
    requiredLevel: 1,
    maxPerUser: 5,
    stock: 0,
    lowStockThreshold: 5,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 67,
    totalRevenue: 3350,
    createdAt: '2024-09-15T00:00:00Z',
    updatedAt: '2024-12-15T00:00:00Z',
  },
  {
    id: 'prod-008',
    name: 'VIP 座位體驗',
    description: '享受一週 VIP 專屬座位',
    emoji: '🏆',
    type: 'privilege',
    category: 'seating',
    price: 200,
    currency: 'coins',
    requiredLevel: 8,
    maxPerUser: 1,
    stock: -1,
    lowStockThreshold: 0,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: false,
    totalSold: 3,
    totalRevenue: 600,
    createdAt: '2024-11-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
  },
  {
    id: 'prod-009',
    name: '文具福袋',
    description: '隨機文具 3-5 件組合',
    emoji: '🎁',
    type: 'physical',
    category: 'stationery',
    price: 100,
    currency: 'coins',
    requiredLevel: 3,
    maxPerUser: 2,
    stock: 10,
    lowStockThreshold: 3,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 23,
    totalRevenue: 2300,
    createdAt: '2024-11-15T00:00:00Z',
    updatedAt: '2024-12-20T00:00:00Z',
  },
  {
    id: 'prod-010',
    name: '飲料兌換券',
    description: '可兌換任一杯飲料',
    emoji: '🧃',
    type: 'physical',
    category: 'drink',
    price: 80,
    currency: 'coins',
    requiredLevel: 1,
    maxPerUser: 0,
    stock: 20,
    lowStockThreshold: 5,
    source: 'organization',
    organizationId: 'demo-org',
    isActive: true,
    totalSold: 112,
    totalRevenue: 8960,
    createdAt: '2024-09-01T00:00:00Z',
    updatedAt: '2024-12-21T00:00:00Z',
  },
];

// 機構訂單列表
export const MOCK_ADMIN_ORDERS: AdminOrder[] = [
  {
    id: 'order-001',
    orderNumber: 'GAME-DEMO-001',
    studentId: 'user-001',
    studentName: '王小明',
    studentAvatar: '🐱',
    className: '國一A班',
    itemId: 'prod-001',
    itemSnapshot: {
      name: '免作業券',
      type: 'privilege',
      price: 80,
      currency: 'coins',
      emoji: '📝',
    },
    quantity: 1,
    totalPrice: 80,
    status: 'pending',
    createdAt: '2025-01-12T14:30:00Z',
    updatedAt: '2025-01-12T14:30:00Z',
  },
  {
    id: 'order-002',
    orderNumber: 'GAME-DEMO-002',
    studentId: 'user-002',
    studentName: '李小華',
    studentAvatar: '🐰',
    className: '國二B班',
    itemId: 'prod-003',
    itemSnapshot: {
      name: '換座位券',
      type: 'privilege',
      price: 60,
      currency: 'coins',
      emoji: '💺',
    },
    quantity: 1,
    totalPrice: 60,
    status: 'pending',
    createdAt: '2025-01-12T15:00:00Z',
    updatedAt: '2025-01-12T15:00:00Z',
  },
  {
    id: 'order-003',
    orderNumber: 'GAME-DEMO-003',
    studentId: 'user-003',
    studentName: '陳小美',
    studentAvatar: '🦊',
    className: '國一A班',
    itemId: 'prod-006',
    itemSnapshot: {
      name: '巧克力棒',
      type: 'physical',
      price: 30,
      currency: 'coins',
      emoji: '🍫',
    },
    quantity: 2,
    totalPrice: 60,
    status: 'confirmed',
    confirmedAt: '2025-01-12T10:15:00Z',
    confirmedBy: 'admin-001',
    createdAt: '2025-01-12T10:00:00Z',
    updatedAt: '2025-01-12T10:15:00Z',
  },
  {
    id: 'order-004',
    orderNumber: 'GAME-DEMO-004',
    studentId: 'user-004',
    studentName: '張小強',
    studentAvatar: '🐯',
    className: '國二A班',
    itemId: 'prod-009',
    itemSnapshot: {
      name: '文具福袋',
      type: 'physical',
      price: 100,
      currency: 'coins',
      emoji: '🎁',
    },
    quantity: 1,
    totalPrice: 100,
    status: 'ready',
    redemptionCode: 'WXYZ-5678',
    redemptionInstructions: '請至補習班櫃檯出示兌換碼領取',
    expiresAt: '2025-01-19T23:59:59Z',
    confirmedAt: '2025-01-11T14:00:00Z',
    confirmedBy: 'admin-001',
    createdAt: '2025-01-11T10:30:00Z',
    updatedAt: '2025-01-11T14:00:00Z',
  },
  {
    id: 'order-005',
    orderNumber: 'GAME-DEMO-005',
    studentId: 'user-005',
    studentName: '林小玲',
    studentAvatar: '🐻',
    className: '國一B班',
    itemId: 'prod-010',
    itemSnapshot: {
      name: '飲料兌換券',
      type: 'physical',
      price: 80,
      currency: 'coins',
      emoji: '🧃',
    },
    quantity: 1,
    totalPrice: 80,
    status: 'ready',
    redemptionCode: 'ABCD-1234',
    redemptionInstructions: '請至補習班櫃檯出示兌換碼領取',
    expiresAt: '2025-01-18T23:59:59Z',
    confirmedAt: '2025-01-10T16:00:00Z',
    confirmedBy: 'admin-001',
    createdAt: '2025-01-10T15:45:00Z',
    updatedAt: '2025-01-10T16:00:00Z',
  },
  {
    id: 'order-006',
    orderNumber: 'GAME-DEMO-006',
    studentId: 'user-006',
    studentName: '黃小龍',
    studentAvatar: '🐲',
    className: '國三A班',
    itemId: 'prod-001',
    itemSnapshot: {
      name: '免作業券',
      type: 'privilege',
      price: 80,
      currency: 'coins',
      emoji: '📝',
    },
    quantity: 1,
    totalPrice: 80,
    status: 'completed',
    redemptionCode: 'EFGH-9012',
    confirmedAt: '2025-01-08T09:00:00Z',
    confirmedBy: 'admin-001',
    completedAt: '2025-01-09T14:30:00Z',
    completedBy: 'teacher-001',
    createdAt: '2025-01-08T08:30:00Z',
    updatedAt: '2025-01-09T14:30:00Z',
  },
  {
    id: 'order-007',
    orderNumber: 'GAME-DEMO-007',
    studentId: 'user-007',
    studentName: '吳小雨',
    studentAvatar: '🐸',
    className: '國二B班',
    itemId: 'prod-005',
    itemSnapshot: {
      name: '點心加購券',
      type: 'physical',
      price: 40,
      currency: 'coins',
      emoji: '🍰',
    },
    quantity: 1,
    totalPrice: 40,
    status: 'completed',
    redemptionCode: 'IJKL-3456',
    confirmedAt: '2025-01-07T11:00:00Z',
    confirmedBy: 'admin-001',
    completedAt: '2025-01-07T15:00:00Z',
    completedBy: 'admin-001',
    createdAt: '2025-01-07T10:30:00Z',
    updatedAt: '2025-01-07T15:00:00Z',
  },
  {
    id: 'order-008',
    orderNumber: 'GAME-DEMO-008',
    studentId: 'user-008',
    studentName: '趙小風',
    studentAvatar: '🦁',
    className: '國一A班',
    itemId: 'prod-002',
    itemSnapshot: {
      name: '遲到免責券',
      type: 'privilege',
      price: 120,
      currency: 'coins',
      emoji: '⏰',
    },
    quantity: 1,
    totalPrice: 120,
    status: 'cancelled',
    cancelledAt: '2025-01-06T10:00:00Z',
    cancelledBy: 'admin-001',
    cancelReason: '學生申請取消，已退還金幣',
    createdAt: '2025-01-05T16:00:00Z',
    updatedAt: '2025-01-06T10:00:00Z',
  },
  {
    id: 'order-009',
    orderNumber: 'GAME-DEMO-009',
    studentId: 'user-009',
    studentName: '周小月',
    studentAvatar: '🐼',
    className: '國三B班',
    itemId: 'prod-006',
    itemSnapshot: {
      name: '巧克力棒',
      type: 'physical',
      price: 30,
      currency: 'coins',
      emoji: '🍫',
    },
    quantity: 3,
    totalPrice: 90,
    status: 'expired',
    redemptionCode: 'MNOP-7890',
    expiresAt: '2025-01-05T23:59:59Z',
    confirmedAt: '2024-12-29T14:00:00Z',
    confirmedBy: 'admin-001',
    createdAt: '2024-12-29T13:30:00Z',
    updatedAt: '2025-01-06T00:00:00Z',
  },
  {
    id: 'order-010',
    orderNumber: 'GAME-DEMO-010',
    studentId: 'user-010',
    studentName: '孫小光',
    studentAvatar: '🐨',
    className: '國二A班',
    itemId: 'prod-004',
    itemSnapshot: {
      name: '小老師體驗券',
      type: 'privilege',
      price: 150,
      currency: 'coins',
      emoji: '👨‍🏫',
    },
    quantity: 1,
    totalPrice: 150,
    status: 'pending',
    createdAt: '2025-01-12T16:00:00Z',
    updatedAt: '2025-01-12T16:00:00Z',
  },
];

// 商店統計資料
export const MOCK_SHOP_STATS: ShopStats = {
  totalProducts: 10,
  activeProducts: 9,
  outOfStockProducts: 1,
  totalOrders: 156,
  pendingOrders: 3,
  completedOrders: 142,
  totalRevenue: 28760,
  todayRevenue: 320,
  weekRevenue: 2180,
  monthRevenue: 8960,
  revenueGrowth: 12.5,
  orderGrowth: 8.3,
};

// 銷售趨勢資料 (過去 14 天)
export const MOCK_SALES_DATA: SalesDataPoint[] = [
  { date: '2024-12-29', orders: 8, revenue: 520 },
  { date: '2024-12-30', orders: 12, revenue: 780 },
  { date: '2024-12-31', orders: 6, revenue: 380 },
  { date: '2025-01-01', orders: 3, revenue: 180 },
  { date: '2025-01-02', orders: 9, revenue: 620 },
  { date: '2025-01-03', orders: 11, revenue: 840 },
  { date: '2025-01-04', orders: 7, revenue: 490 },
  { date: '2025-01-05', orders: 10, revenue: 720 },
  { date: '2025-01-06', orders: 14, revenue: 980 },
  { date: '2025-01-07', orders: 8, revenue: 560 },
  { date: '2025-01-08', orders: 13, revenue: 920 },
  { date: '2025-01-09', orders: 9, revenue: 640 },
  { date: '2025-01-10', orders: 11, revenue: 780 },
  { date: '2025-01-11', orders: 15, revenue: 1100 },
];

// 熱門商品排行
export const MOCK_TOP_PRODUCTS: TopProduct[] = [
  { product: MOCK_ADMIN_PRODUCTS[5], soldCount: 156, revenue: 4680, rank: 1 }, // 巧克力棒
  { product: MOCK_ADMIN_PRODUCTS[9], soldCount: 112, revenue: 8960, rank: 2 }, // 飲料兌換券
  { product: MOCK_ADMIN_PRODUCTS[4], soldCount: 89, revenue: 3560, rank: 3 },  // 點心加購券
  { product: MOCK_ADMIN_PRODUCTS[6], soldCount: 67, revenue: 3350, rank: 4 },  // 造型橡皮擦
  { product: MOCK_ADMIN_PRODUCTS[2], soldCount: 42, revenue: 2520, rank: 5 },  // 換座位券
];

// 學生消費統計
export const MOCK_STUDENT_SPENDING: StudentSpending[] = [
  { studentId: 'user-top1', studentName: '學霸王', studentAvatar: '🦁', className: '國三A班', totalSpent: 1250, orderCount: 18, lastOrderDate: '2025-01-11' },
  { studentId: 'user-top2', studentName: '小天才', studentAvatar: '🐯', className: '國三A班', totalSpent: 980, orderCount: 15, lastOrderDate: '2025-01-10' },
  { studentId: 'user-top3', studentName: '努力達人', studentAvatar: '🐻', className: '國二A班', totalSpent: 860, orderCount: 12, lastOrderDate: '2025-01-09' },
  { studentId: 'user-001', studentName: '王小明', studentAvatar: '🐱', className: '國一A班', totalSpent: 450, orderCount: 8, lastOrderDate: '2025-01-12' },
  { studentId: 'user-002', studentName: '李小華', studentAvatar: '🐰', className: '國二B班', totalSpent: 320, orderCount: 6, lastOrderDate: '2025-01-12' },
];

// Helper: 生成訂單編號
export function generateOrderNumber(orgSlug: string): string {
  const seq = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `GAME-${orgSlug.toUpperCase()}-${seq}`;
}

// Helper: 計算訂單統計
export function getOrderStats(orders: AdminOrder[]) {
  return {
    pending: orders.filter(o => o.status === 'pending').length,
    confirmed: orders.filter(o => o.status === 'confirmed').length,
    ready: orders.filter(o => o.status === 'ready').length,
    completed: orders.filter(o => o.status === 'completed').length,
    cancelled: orders.filter(o => o.status === 'cancelled').length,
    expired: orders.filter(o => o.status === 'expired').length,
  };
}

// Helper: 計算商品統計
export function getProductStats(products: ShopProduct[]) {
  return {
    total: products.length,
    active: products.filter(p => p.isActive && p.stock !== 0).length,
    outOfStock: products.filter(p => p.isActive && p.stock === 0).length,
    inactive: products.filter(p => !p.isActive).length,
  };
}

// ============================================
// Platform Admin Mock Data
// ============================================

import type {
  PlatformProduct,
  PlatformOrder,
  ManagedOrganization,
  PlatformStats,
  PlatformSalesDataPoint,
  OrganizationRanking,
} from '../types/platform-admin';

// 平台商品 (虛擬道具為主)
export const MOCK_PLATFORM_PRODUCTS: PlatformProduct[] = [
  ...MOCK_VIRTUAL_REWARDS.map((reward, index) => ({
    id: `platform-${reward.id}`,
    name: reward.name,
    description: reward.description || '',
    imageUrl: reward.imageUrl || '',
    emoji: reward.emoji,
    type: 'virtual' as const,
    category: reward.category,
    price: reward.price,
    currency: reward.currency,
    requiredLevel: reward.requiredLevel || 1,
    maxPerUser: 1,
    stock: -1, // 無限
    lowStockThreshold: 0,
    source: 'platform' as const,
    isActive: true,
    totalSold: Math.floor(Math.random() * 500) + 50,
    totalRevenue: 0,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
    isGlobal: true,
    featuredOrder: index < 5 ? index + 1 : undefined,
    tags: reward.category === 'avatar_frame' ? ['頭像框', '裝飾'] : ['稱號', '身份'],
  })),
];

// 計算 totalRevenue
MOCK_PLATFORM_PRODUCTS.forEach(p => {
  p.totalRevenue = p.totalSold * p.price;
});

// 管理的機構列表
export const MOCK_MANAGED_ORGANIZATIONS: ManagedOrganization[] = [
  {
    id: 'demo-org',
    name: 'Demo 補習班',
    slug: 'demo',
    shopEnabled: true,
    shopSettings: {
      allowPhysicalRewards: true,
      allowPrivileges: true,
      maxDailyOrders: 10,
      orderExpiryDays: 7,
    },
    studentCount: 156,
    activeStudents: 89,
    productCount: 10,
    totalOrders: 156,
    totalRevenue: 28760,
    pendingOrders: 3,
    status: 'active',
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-12-01T00:00:00Z',
    lastActivityAt: '2025-01-12T16:00:00Z',
  },
  {
    id: 'org-002',
    name: '明星英語',
    slug: 'mingxing',
    shopEnabled: true,
    shopSettings: {
      allowPhysicalRewards: true,
      allowPrivileges: true,
      maxDailyOrders: 15,
      orderExpiryDays: 7,
    },
    studentCount: 234,
    activeStudents: 145,
    productCount: 15,
    totalOrders: 312,
    totalRevenue: 45680,
    pendingOrders: 5,
    status: 'active',
    createdAt: '2024-02-15T00:00:00Z',
    updatedAt: '2024-12-10T00:00:00Z',
    lastActivityAt: '2025-01-12T14:30:00Z',
  },
  {
    id: 'org-003',
    name: '數學天才班',
    slug: 'mathgenius',
    shopEnabled: true,
    shopSettings: {
      allowPhysicalRewards: true,
      allowPrivileges: false,
      maxDailyOrders: 8,
      orderExpiryDays: 5,
    },
    studentCount: 98,
    activeStudents: 67,
    productCount: 8,
    totalOrders: 89,
    totalRevenue: 12450,
    pendingOrders: 2,
    status: 'active',
    createdAt: '2024-03-01T00:00:00Z',
    updatedAt: '2024-11-20T00:00:00Z',
    lastActivityAt: '2025-01-11T10:00:00Z',
  },
  {
    id: 'org-004',
    name: '科學實驗室',
    slug: 'sciencelab',
    shopEnabled: false,
    shopSettings: {
      allowPhysicalRewards: true,
      allowPrivileges: true,
      maxDailyOrders: 10,
      orderExpiryDays: 7,
    },
    studentCount: 45,
    activeStudents: 28,
    productCount: 0,
    totalOrders: 0,
    totalRevenue: 0,
    pendingOrders: 0,
    status: 'inactive',
    createdAt: '2024-06-01T00:00:00Z',
    updatedAt: '2024-10-15T00:00:00Z',
  },
  {
    id: 'org-005',
    name: '全科補習中心',
    slug: 'allsubjects',
    shopEnabled: true,
    shopSettings: {
      allowPhysicalRewards: true,
      allowPrivileges: true,
      maxDailyOrders: 20,
      orderExpiryDays: 10,
    },
    studentCount: 320,
    activeStudents: 198,
    productCount: 22,
    totalOrders: 567,
    totalRevenue: 78900,
    pendingOrders: 8,
    status: 'active',
    createdAt: '2024-01-15T00:00:00Z',
    updatedAt: '2024-12-15T00:00:00Z',
    lastActivityAt: '2025-01-12T17:00:00Z',
  },
];

// 全平台訂單 (跨機構)
export const MOCK_PLATFORM_ORDERS: PlatformOrder[] = [
  ...MOCK_ADMIN_ORDERS.map(order => ({
    ...order,
    organizationId: 'demo-org',
    organizationName: 'Demo 補習班',
  })),
  // 添加其他機構的訂單
  {
    id: 'platform-order-001',
    orderNumber: 'GAME-MINGXING-001',
    studentId: 'mx-user-001',
    studentName: '張小文',
    studentAvatar: '🐶',
    className: '英文進階班',
    itemId: 'mx-prod-001',
    itemSnapshot: {
      name: '英文單字本',
      type: 'physical',
      price: 50,
      currency: 'coins',
      emoji: '📖',
    },
    quantity: 1,
    totalPrice: 50,
    status: 'pending',
    createdAt: '2025-01-12T15:30:00Z',
    updatedAt: '2025-01-12T15:30:00Z',
    organizationId: 'org-002',
    organizationName: '明星英語',
  },
  {
    id: 'platform-order-002',
    orderNumber: 'GAME-MINGXING-002',
    studentId: 'mx-user-002',
    studentName: '李小英',
    studentAvatar: '🐱',
    className: '英文基礎班',
    itemId: 'mx-prod-002',
    itemSnapshot: {
      name: '口語練習券',
      type: 'privilege',
      price: 100,
      currency: 'coins',
      emoji: '🎤',
    },
    quantity: 1,
    totalPrice: 100,
    status: 'confirmed',
    confirmedAt: '2025-01-12T10:00:00Z',
    confirmedBy: 'admin-mx-001',
    createdAt: '2025-01-12T09:30:00Z',
    updatedAt: '2025-01-12T10:00:00Z',
    organizationId: 'org-002',
    organizationName: '明星英語',
  },
  {
    id: 'platform-order-003',
    orderNumber: 'GAME-ALLSUB-001',
    studentId: 'as-user-001',
    studentName: '王大明',
    studentAvatar: '🦊',
    className: '國三全科班',
    itemId: 'as-prod-001',
    itemSnapshot: {
      name: '自習室優先券',
      type: 'privilege',
      price: 80,
      currency: 'coins',
      emoji: '📚',
    },
    quantity: 1,
    totalPrice: 80,
    status: 'ready',
    redemptionCode: 'ASUB-1234',
    expiresAt: '2025-01-19T23:59:59Z',
    confirmedAt: '2025-01-11T14:00:00Z',
    confirmedBy: 'admin-as-001',
    createdAt: '2025-01-11T13:30:00Z',
    updatedAt: '2025-01-11T14:00:00Z',
    organizationId: 'org-005',
    organizationName: '全科補習中心',
  },
];

// 平台統計
export const MOCK_PLATFORM_STATS: PlatformStats = {
  totalOrganizations: 5,
  activeOrganizations: 4,
  totalStudents: 853,
  activeStudents: 527,
  totalProducts: MOCK_PLATFORM_PRODUCTS.length + 55, // 平台商品 + 機構商品總和
  platformProducts: MOCK_PLATFORM_PRODUCTS.length,
  orgProducts: 55,
  totalOrders: 1124,
  pendingOrders: 18,
  completedOrders: 986,
  todayOrders: 23,
  totalRevenue: 165790,
  todayRevenue: 2340,
  weekRevenue: 15680,
  monthRevenue: 45230,
  revenueGrowth: 15.8,
  orderGrowth: 12.3,
  studentGrowth: 8.5,
};

// 平台銷售趨勢 (過去 14 天)
export const MOCK_PLATFORM_SALES_DATA: PlatformSalesDataPoint[] = [
  { date: '2024-12-29', platformOrders: 12, orgOrders: 28, platformRevenue: 1800, orgRevenue: 2200 },
  { date: '2024-12-30', platformOrders: 15, orgOrders: 35, platformRevenue: 2250, orgRevenue: 2800 },
  { date: '2024-12-31', platformOrders: 8, orgOrders: 18, platformRevenue: 1200, orgRevenue: 1400 },
  { date: '2025-01-01', platformOrders: 5, orgOrders: 10, platformRevenue: 750, orgRevenue: 800 },
  { date: '2025-01-02', platformOrders: 14, orgOrders: 32, platformRevenue: 2100, orgRevenue: 2560 },
  { date: '2025-01-03', platformOrders: 18, orgOrders: 38, platformRevenue: 2700, orgRevenue: 3040 },
  { date: '2025-01-04', platformOrders: 10, orgOrders: 24, platformRevenue: 1500, orgRevenue: 1920 },
  { date: '2025-01-05', platformOrders: 16, orgOrders: 30, platformRevenue: 2400, orgRevenue: 2400 },
  { date: '2025-01-06', platformOrders: 20, orgOrders: 42, platformRevenue: 3000, orgRevenue: 3360 },
  { date: '2025-01-07', platformOrders: 12, orgOrders: 26, platformRevenue: 1800, orgRevenue: 2080 },
  { date: '2025-01-08', platformOrders: 19, orgOrders: 40, platformRevenue: 2850, orgRevenue: 3200 },
  { date: '2025-01-09', platformOrders: 14, orgOrders: 28, platformRevenue: 2100, orgRevenue: 2240 },
  { date: '2025-01-10', platformOrders: 17, orgOrders: 34, platformRevenue: 2550, orgRevenue: 2720 },
  { date: '2025-01-11', platformOrders: 22, orgOrders: 45, platformRevenue: 3300, orgRevenue: 3600 },
];

// 機構排行榜
export const MOCK_ORGANIZATION_RANKINGS: OrganizationRanking[] = MOCK_MANAGED_ORGANIZATIONS
  .filter(org => org.status === 'active')
  .sort((a, b) => b.totalRevenue - a.totalRevenue)
  .map((org, index) => ({
    organization: org,
    rank: index + 1,
    revenue: org.totalRevenue,
    orderCount: org.totalOrders,
    studentCount: org.activeStudents,
    growth: Math.random() * 30 - 5, // -5% ~ 25% 隨機增長
  }));

// Helper: 計算平台訂單統計
export function getPlatformOrderStats(orders: PlatformOrder[]) {
  return {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    confirmed: orders.filter(o => o.status === 'confirmed').length,
    ready: orders.filter(o => o.status === 'ready').length,
    completed: orders.filter(o => o.status === 'completed').length,
    cancelled: orders.filter(o => o.status === 'cancelled').length,
    expired: orders.filter(o => o.status === 'expired').length,
  };
}

// Helper: 依機構分組訂單
export function getOrdersByOrganization(orders: PlatformOrder[]) {
  const grouped: Record<string, { name: string; orders: PlatformOrder[] }> = {};

  orders.forEach(order => {
    if (!grouped[order.organizationId]) {
      grouped[order.organizationId] = {
        name: order.organizationName,
        orders: [],
      };
    }
    grouped[order.organizationId].orders.push(order);
  });

  return grouped;
}
