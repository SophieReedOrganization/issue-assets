/**
 * Org Admin Types - 機構管理後台類型定義
 */

// ============================================
// 商品相關
// ============================================

// Org Admin 只能建立實體獎品和特權（虛擬道具由 Platform Admin 管理）
export type ProductType = 'physical' | 'privilege';
export type ProductStatus = 'active' | 'inactive' | 'out_of_stock';
export type CurrencyType = 'coins' | 'xp';

export interface ShopProduct {
  id: string;

  // 基本資訊
  name: string;
  description: string;
  imageUrl?: string;
  emoji?: string;

  // 分類
  type: ProductType;
  category?: string;

  // 定價
  price: number;
  currency: CurrencyType;

  // 購買限制
  requiredLevel: number;
  maxPerUser: number; // 0 = 無限

  // 庫存管理
  stock: number; // -1 = 無限
  lowStockThreshold: number;

  // 來源
  source: 'platform' | 'organization';
  organizationId?: string;

  // 狀態
  isActive: boolean;

  // 統計
  totalSold: number;
  totalRevenue: number;

  // 時間戳
  createdAt: string;
  updatedAt: string;
}

export interface ProductFormData {
  name: string;
  description: string;
  imageUrl?: string;
  emoji?: string;
  type: ProductType;
  category?: string;
  price: number;
  currency: CurrencyType;
  requiredLevel: number;
  maxPerUser: number;
  stock: number;
  lowStockThreshold: number;
  isActive: boolean;
}

export interface ProductFilter {
  status?: ProductStatus | 'all';
  type?: ProductType | 'all';
  search?: string;
}

// ============================================
// 訂單相關
// ============================================

export type OrderStatus = 'pending' | 'confirmed' | 'ready' | 'completed' | 'cancelled' | 'expired';

export interface AdminOrder {
  id: string;
  orderNumber: string;

  // 學生資訊
  studentId: string;
  studentName: string;
  studentAvatar?: string;
  className?: string;

  // 商品資訊
  itemId: string;
  itemSnapshot: {
    name: string;
    type: ProductType;
    price: number;
    currency: CurrencyType;
    imageUrl?: string;
    emoji?: string;
  };

  // 訂單資訊
  quantity: number;
  totalPrice: number;
  status: OrderStatus;

  // 兌換資訊
  redemptionCode?: string;
  redemptionInstructions?: string;
  expiresAt?: string;

  // 處理記錄
  confirmedAt?: string;
  confirmedBy?: string;
  completedAt?: string;
  completedBy?: string;
  cancelledAt?: string;
  cancelledBy?: string;
  cancelReason?: string;

  // 備註
  notes?: string;

  // 時間戳
  createdAt: string;
  updatedAt: string;
}

export interface OrderFilter {
  status?: OrderStatus | 'all';
  search?: string;
  dateRange?: {
    start: string;
    end: string;
  };
}

export interface OrderAction {
  type: 'confirm' | 'ready' | 'complete' | 'cancel';
  orderId: string;
  reason?: string;
  notes?: string;
}

// ============================================
// 庫存相關
// ============================================

export type StockAdjustmentType = 'add' | 'subtract' | 'set';

export interface StockAdjustment {
  productId: string;
  type: StockAdjustmentType;
  quantity: number;
  reason: string;
  adjustedBy: string;
  adjustedAt: string;
}

export interface InventoryItem extends ShopProduct {
  stockHistory: StockAdjustment[];
  lastRestockDate?: string;
  averageDailySales?: number;
  daysUntilStockout?: number;
}

// ============================================
// 統計相關
// ============================================

export interface ShopStats {
  // 總覽
  totalProducts: number;
  activeProducts: number;
  outOfStockProducts: number;

  // 訂單
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;

  // 收入
  totalRevenue: number;
  todayRevenue: number;
  weekRevenue: number;
  monthRevenue: number;

  // 趨勢
  revenueGrowth: number; // 百分比
  orderGrowth: number;
}

export interface SalesDataPoint {
  date: string;
  orders: number;
  revenue: number;
}

export interface TopProduct {
  product: ShopProduct;
  soldCount: number;
  revenue: number;
  rank: number;
}

export interface StudentSpending {
  studentId: string;
  studentName: string;
  studentAvatar?: string;
  className?: string;
  totalSpent: number;
  orderCount: number;
  lastOrderDate: string;
}

// ============================================
// 機構資訊
// ============================================

export interface Organization {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;

  // 商店設定
  shopEnabled: boolean;
  shopSettings: {
    allowPhysicalRewards: boolean;
    allowPrivileges: boolean;
    maxDailyOrders: number;
    orderExpiryDays: number;
  };

  // 統計
  studentCount: number;
  activeStudents: number;

  createdAt: string;
  updatedAt: string;
}

// ============================================
// 通知相關
// ============================================

export type NotificationType = 'low_stock' | 'new_order' | 'order_expired' | 'daily_summary';

export interface ShopNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
}

// ============================================
// 批量操作
// ============================================

export interface BulkProductAction {
  action: 'activate' | 'deactivate' | 'delete';
  productIds: string[];
}

export interface BulkOrderAction {
  action: 'confirm' | 'cancel';
  orderIds: string[];
  reason?: string;
}

// ============================================
// 分頁
// ============================================

export interface PaginationParams {
  page: number;
  pageSize: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// ============================================
// UI 狀態
// ============================================

export interface AdminUIState {
  selectedProductIds: string[];
  selectedOrderIds: string[];
  isProductFormOpen: boolean;
  isOrderDetailOpen: boolean;
  editingProductId: string | null;
  viewingOrderId: string | null;
}
