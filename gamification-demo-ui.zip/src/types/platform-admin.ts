/**
 * Platform Admin Types - 平台管理後台類型定義
 */

import type { AdminOrder, OrderStatus, CurrencyType } from './org-admin';

// ============================================
// 平台商品類型（虛擬道具）
// ============================================

// Platform Admin 管理虛擬道具，不同於 Org Admin 的實體獎品
export type PlatformProductType = 'virtual';
export type VirtualItemCategory = 'avatar_frame' | 'title' | 'emoji_pack' | 'theme';

export interface PlatformProduct {
  id: string;

  // 基本資訊
  name: string;
  description: string;
  imageUrl?: string;
  emoji?: string;

  // 分類 - 虛擬道具類型
  type: PlatformProductType;
  category: VirtualItemCategory;

  // 定價
  price: number;
  currency: CurrencyType;

  // 購買限制
  requiredLevel: number;
  maxPerUser: number; // 0 = 無限

  // 庫存管理
  stock: number; // -1 = 無限
  lowStockThreshold: number;

  // 來源
  source: 'platform';

  // 狀態
  isActive: boolean;
  isGlobal: boolean;               // 是否全平台可見
  featuredOrder?: number;          // 精選排序（用於首頁推薦）
  tags?: string[];                 // 商品標籤

  // 統計
  totalSold: number;
  totalRevenue: number;

  // 時間戳
  createdAt: string;
  updatedAt: string;
}

export interface PlatformProductFormData {
  name: string;
  description: string;
  imageUrl?: string;
  emoji?: string;
  type: PlatformProductType;
  category: VirtualItemCategory;
  price: number;
  currency: CurrencyType;
  requiredLevel: number;
  maxPerUser: number;
  stock: number;
  lowStockThreshold: number;
  isActive: boolean;
  isGlobal: boolean;
  featuredOrder?: number;
  tags?: string[];
}

// ============================================
// 全平台訂單相關
// ============================================

export interface PlatformOrder extends AdminOrder {
  // 訂單來源機構
  organizationId: string;
  organizationName: string;
}

export interface PlatformOrderFilter {
  status?: OrderStatus | 'all';
  organizationId?: string | 'all';
  search?: string;
  dateRange?: {
    start: string;
    end: string;
  };
}

// ============================================
// 機構管理相關
// ============================================

export interface ManagedOrganization {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;

  // 商店狀態
  shopEnabled: boolean;
  shopSettings: {
    allowPhysicalRewards: boolean;
    allowPrivileges: boolean;
    maxDailyOrders: number;
    orderExpiryDays: number;
  };

  // 統計數據
  studentCount: number;
  activeStudents: number;
  productCount: number;
  totalOrders: number;
  totalRevenue: number;
  pendingOrders: number;

  // 狀態
  status: 'active' | 'inactive' | 'suspended';

  // 時間戳
  createdAt: string;
  updatedAt: string;
  lastActivityAt?: string;
}

export interface OrganizationStats {
  totalOrganizations: number;
  activeOrganizations: number;
  totalStudents: number;
  activeStudents: number;
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
}

// ============================================
// 平台統計相關
// ============================================

export interface PlatformStats {
  // 總覽
  totalOrganizations: number;
  activeOrganizations: number;
  totalStudents: number;
  activeStudents: number;

  // 商品
  totalProducts: number;
  platformProducts: number;
  orgProducts: number;

  // 訂單
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  todayOrders: number;

  // 營收
  totalRevenue: number;
  todayRevenue: number;
  weekRevenue: number;
  monthRevenue: number;

  // 趨勢
  revenueGrowth: number;
  orderGrowth: number;
  studentGrowth: number;
}

export interface PlatformSalesDataPoint {
  date: string;
  platformOrders: number;
  orgOrders: number;
  platformRevenue: number;
  orgRevenue: number;
}

export interface OrganizationRanking {
  organization: ManagedOrganization;
  rank: number;
  revenue: number;
  orderCount: number;
  studentCount: number;
  growth: number;
}

// ============================================
// 平台商品分類
// ============================================

export interface ProductCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  emoji?: string;
  productCount: number;
  isActive: boolean;
}

// ============================================
// 通知相關
// ============================================

export type PlatformNotificationType =
  | 'new_organization'
  | 'organization_suspended'
  | 'high_volume_orders'
  | 'system_alert'
  | 'daily_summary';

export interface PlatformNotification {
  id: string;
  type: PlatformNotificationType;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
}

// ============================================
// UI 狀態
// ============================================

export interface PlatformAdminUIState {
  selectedOrganizationId: string | null;
  selectedProductIds: string[];
  selectedOrderIds: string[];
  isProductFormOpen: boolean;
  isOrgDetailOpen: boolean;
  viewingOrderId: string | null;
}
