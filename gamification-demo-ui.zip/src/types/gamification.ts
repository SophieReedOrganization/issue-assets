// Gamification System Type Definitions

// ============================================
// Shop & Rewards
// ============================================

export type RewardType = 'virtual' | 'physical';
export type ShopType = 'platform' | 'organization';
export type CurrencyType = 'coins' | 'xp';

export interface BaseReward {
  id: string;
  name: string;
  description?: string;
  price: number;
  currency: CurrencyType; // 'xp' for virtual, 'coins' for physical
  emoji: string;
  imageUrl?: string;
  stock: number;
  type: RewardType;
  requiredLevel?: number; // 等級門檻，未達等級無法購買
}

export interface VirtualReward extends BaseReward {
  type: 'virtual';
  category: 'avatar_frame' | 'title' | 'emoji_pack' | 'theme';
}

export interface PhysicalReward extends BaseReward {
  type: 'physical';
  estimatedDelivery?: string;
  redemptionInstructions?: string;
  expiryDays?: number; // days until redemption code expires
}

export type Reward = VirtualReward | PhysicalReward;

export interface OrganizationReward extends BaseReward {
  organizationId: string;
  organizationName: string;
  category: 'privilege' | 'physical' | 'other';
  createdAt: string;
  updatedAt: string;
}

// ============================================
// Orders & Redemptions
// ============================================

export type OrderStatus = 'pending' | 'ready' | 'completed' | 'expired' | 'cancelled';

export interface Order {
  id: string;
  rewardId: string;
  rewardName: string;
  rewardEmoji: string;
  rewardType: RewardType;
  shopType: ShopType;
  organizationName?: string;
  currencySpent: number;
  currencyType: CurrencyType;
  redemptionCode?: string;
  status: OrderStatus;
  createdAt: string;
  expiresAt?: string;
  completedAt?: string;
  redemptionInstructions?: string;
}

// ============================================
// User Profile
// ============================================

export interface UserGameProfile {
  userId: string;
  displayName: string;
  avatarEmoji: string;
  level: number;
  currentXp: number;
  xpToNextLevel: number;
  totalXp: number;
  coins: number;

  // 目前可追蹤的指標
  totalTasksCompleted: number;      // 累計完成任務數
  totalExamsPassed: number;         // 累計及格試卷數
  noGuessingExamsPassed: number;    // 累計無猜題及格試卷數

  // 未來擴充（需後端支援）
  currentStreak?: number;           // 連續登入天數
  longestStreak?: number;           // 最長連續登入
  maxCorrectCombo?: number;         // 最高連續答對數
  perfectExams?: number;            // 滿分試卷數

  // 稱號系統
  equippedTitle?: string;           // 當前裝備的稱號 ID
  ownedTitles: string[];            // 已擁有的稱號 ID 列表
}

// ============================================
// 稱號定義
// ============================================

export type ItemRarity = 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';
export type AcquisitionType = 'free' | 'achievement' | 'purchase';

export interface Title {
  id: string;
  name: string;
  description: string;
  rarity: ItemRarity;
  acquisitionType: AcquisitionType;
  price?: number;
  requiredLevel?: number;
  unlockCondition?: string;
}

// ============================================
// 頭像框定義
// ============================================

export interface Frame {
  id: string;
  name: string;
  description: string;
  rarity: ItemRarity;
  acquisitionType: AcquisitionType;
  price?: number;
  requiredLevel?: number;
  unlockCondition?: string;
  imageUrl?: string;
}

// 獎勵規則常量（基於現有後端 API 資料）
export const REWARD_RULES = {
  // 任務獎勵（來源：StudentPathTask）
  task: { xp: 10, coins: 3 },           // status = completed
  taskHighScore: { xp: 5, coins: 2 },   // achieved_score >= 80

  // 試卷獎勵（來源：ExamSubmissionResponse）
  examPass: { xp: 20, coins: 5 },       // accuracy_rate >= 60
  examGood: { xp: 30, coins: 10 },      // accuracy_rate >= 80
  examPerfect: { xp: 50, coins: 20 },   // accuracy_rate = 100
  examNoGuessing: { xp: 10, coins: 5 }, // is_guessing_detected = false

  // 徽章獎勵
  badgeBronze: { xp: 30, coins: 10 },
  badgeSilver: { xp: 75, coins: 30 },
  badgeGold: { xp: 150, coins: 75 },
  badgeDiamond: { xp: 300, coins: 150 },
} as const;

// 等級經驗值表 (Lv.1-20)
export const LEVEL_XP_TABLE: Record<number, number> = {
  1: 0, 2: 100, 3: 300, 4: 600, 5: 1000,
  6: 1500, 7: 2200, 8: 3000, 9: 4000, 10: 5000,
  11: 6200, 12: 7600, 13: 9200, 14: 11000, 15: 13000,
  16: 15500, 17: 18500, 18: 22000, 19: 26000, 20: 30000,
};

// 每日上限
export const DAILY_LIMITS = {
  taskXp: 150, // 任務 XP 每日上限
};

// ============================================
// Badges
// ============================================

export type BadgeTier = 'bronze' | 'silver' | 'gold' | 'diamond';

export interface Badge {
  id: string;
  name: string;
  description: string;
  tier: BadgeTier;
  imageUrl?: string;
  emoji: string;
  xpReward: number;
  coinReward: number;
  isHidden: boolean;
  earnedAt?: string;
  progress?: {
    current: number;
    target: number;
    percentage: number;
  };
}

// ============================================
// Leaderboard
// ============================================

export type LeaderboardScope = 'class' | 'school' | 'global';
export type LeaderboardTimeframe = 'weekly' | 'monthly' | 'all_time';
export type LeaderboardMetric = 'xp' | 'accuracy' | 'streak';

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  displayName: string;
  avatarEmoji: string;
  level: number;
  value: number;
  change?: number; // rank change from previous period
  isCurrentUser?: boolean;
}

// ============================================
// Organization Management
// ============================================

export interface OrganizationShopSettings {
  organizationId: string;
  organizationName: string;
  isEnabled: boolean;
  rewards: OrganizationReward[];
}

export interface RedemptionRecord {
  id: string;
  orderId: string;
  studentId: string;
  studentName: string;
  rewardId: string;
  rewardName: string;
  currencySpent: number;
  currencyType: CurrencyType;
  redemptionCode: string;
  status: OrderStatus;
  createdAt: string;
  completedAt?: string;
}

// ============================================
// UI State
// ============================================

export interface ShopFilter {
  shopType: ShopType;
  rewardType: RewardType | 'all';
  category?: string;
}

export interface RedemptionState {
  isConfirming: boolean;
  isProcessing: boolean;
  isSuccess: boolean;
  selectedReward: Reward | OrganizationReward | null;
  redemptionCode?: string;
  error?: string;
}
