// Gamification System Type Definitions

// ============================================
// Shop & Rewards
// ============================================

export type RewardType = 'virtual' | 'physical';
export type ShopType = 'platform' | 'organization';
export type CurrencyType = 'coins' | 'xp';

export interface BaseReward {
  id: string;
  name: string;
  description?: string;
  price: number;
  currency: CurrencyType; // 'xp' for virtual, 'coins' for physical
  emoji: string;
  imageUrl?: string;
  stock: number;
  type: RewardType;
  requiredLevel?: number; // 等級門檻，未達等級無法購買
}

export interface VirtualReward extends BaseReward {
  type: 'virtual';
  category: 'avatar_frame' | 'title' | 'emoji_pack' | 'theme';
}

export interface PhysicalReward extends BaseReward {
  type: 'physical';
  estimatedDelivery?: string;
  redemptionInstructions?: string;
  expiryDays?: number; // days until redemption code expires
}

export type Reward = VirtualReward | PhysicalReward;

export interface OrganizationReward extends BaseReward {
  organizationId: string;
  organizationName: string;
  category: 'privilege' | 'physical' | 'other';
  createdAt: string;
  updatedAt: string;
}

// ============================================
// Orders & Redemptions
// ============================================

export type OrderStatus = 'pending' | 'ready' | 'completed' | 'expired' | 'cancelled';

export interface Order {
  id: string;
  rewardId: string;
  rewardName: string;
  rewardEmoji: string;
  rewardType: RewardType;
  shopType: ShopType;
  organizationName?: string;
  currencySpent: number;
  currencyType: CurrencyType;
  redemptionCode?: string;
  status: OrderStatus;
  createdAt: string;
  expiresAt?: string;
  completedAt?: string;
  redemptionInstructions?: string;
}

// ============================================
// User Profile
// ============================================

export interface UserGameProfile {
  userId: string;
  displayName: string;
  avatarEmoji: string;
  level: number;
  currentXp: number;
  xpToNextLevel: number;
  totalXp: number;
  coins: number;

  // 目前可追蹤的指標
  totalTasksCompleted: number;      // 累計完成任務數
  totalExamsPassed: number;         // 累計及格試卷數
  noGuessingExamsPassed: number;    // 累計無猜題及格試卷數

  // 未來擴充（需後端支援）
  currentStreak?: number;           // 連續登入天數
  longestStreak?: number;           // 最長連續登入
  maxCorrectCombo?: number;         // 最高連續答對數
  perfectExams?: number;            // 滿分試卷數

  // 稱號系統
  equippedTitle?: string;           // 當前裝備的稱號 ID
  ownedTitles: string[];            // 已擁有的稱號 ID 列表
}

// ============================================
// 稱號定義
// ============================================

export type ItemRarity = 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';
export type AcquisitionType = 'free' | 'achievement' | 'purchase';

export interface Title {
  id: string;
  name: string;
  description: string;
  rarity: ItemRarity;
  acquisitionType: AcquisitionType;
  price?: number;
  requiredLevel?: number;
  unlockCondition?: string;
}

// ============================================
// 頭像框定義
// ============================================

export interface Frame {
  id: string;
  name: string;
  description: string;
  rarity: ItemRarity;
  acquisitionType: AcquisitionType;
  price?: number;
  requiredLevel?: number;
  unlockCondition?: string;
  imageUrl?: string;
}

// ============================================
// 獎勵系統 (基於 docs/gamification-system/03-reward-rules.md)
// ============================================

/**
 * 獎勵數值結構
 * 後端可回傳實際獎勵，未回傳則使用預設值
 */
export interface RewardAmount {
  xp: number;
  coins: number;
}

/**
 * 任務難度等級
 */
export type TaskDifficulty = 'beginner' | 'intermediate' | 'advanced';

/**
 * 考試類型
 */
export type ExamType = 'quiz' | 'exam' | 'practice';

/**
 * 任務完成回應 - 後端 API 回傳格式
 * 獎勵欄位為可選，未提供時前端使用 DEFAULT_REWARDS
 */
export interface TaskCompletionResponse {
  success: boolean;
  taskId: string;
  taskType: 'task' | 'exam' | 'badge' | 'login' | 'streak';

  // 彈性獎勵：後端可覆蓋預設值
  rewards?: Partial<RewardAmount>;

  // 額外資訊
  message?: string;
  bonusReason?: string; // e.g., "高分獎勵", "連續答對", "早起學習"
}

/**
 * 計算最終獎勵（合併後端回傳與預設值）
 */
export function resolveRewards(
  response: TaskCompletionResponse,
  defaultReward: RewardAmount
): RewardAmount {
  return {
    xp: response.rewards?.xp ?? defaultReward.xp,
    coins: response.rewards?.coins ?? defaultReward.coins,
  };
}

// ============================================
// 預設獎勵規則 (DEFAULT_REWARDS)
// ============================================

export const DEFAULT_REWARDS = {
  // ----------------------------------------
  // 任務基礎獎勵（依難度）
  // ----------------------------------------
  taskBeginner: { xp: 30, coins: 5 },      // 初級任務
  taskIntermediate: { xp: 50, coins: 10 }, // 中級任務
  taskAdvanced: { xp: 70, coins: 15 },     // 高級任務

  // ----------------------------------------
  // 考試基礎獎勵（依類型）
  // ----------------------------------------
  examQuiz: { xp: 30, coins: 5 },          // 小考
  examExam: { xp: 50, coins: 10 },         // 正式考試
  examPractice: { xp: 20, coins: 3 },      // 練習

  // ----------------------------------------
  // 考試準確度加成
  // ----------------------------------------
  accuracyPerfect: { xp: 50, coins: 20 },  // 100% 完美
  accuracyExcellent: { xp: 30, coins: 10 },// 90-99% 優秀
  accuracyGood: { xp: 15, coins: 5 },      // 80-89% 良好
  accuracyPass: { xp: 5, coins: 2 },       // 70-79% 及格

  // ----------------------------------------
  // 考試特殊獎勵
  // ----------------------------------------
  examNoGuessing: { xp: 20, coins: 5 },    // 無猜題獎勵

  // 連續正確獎勵
  streak5: { xp: 10, coins: 2 },           // 5 連勝
  streak10: { xp: 25, coins: 5 },          // 10 連勝
  streak20: { xp: 50, coins: 10 },         // 20 連勝
  streak50: { xp: 100, coins: 25 },        // 50 連勝

  // ----------------------------------------
  // 每日登入獎勵
  // ----------------------------------------
  dailyLogin: { xp: 10, coins: 5 },        // 每日首次登入

  // Streak 里程碑獎勵（一次性）
  streakDay7: { xp: 50, coins: 20 },       // 7 日連續 + 徽章
  streakDay14: { xp: 100, coins: 50 },     // 14 日連續 + 徽章
  streakDay30: { xp: 200, coins: 100 },    // 30 日連續 + 徽章
  streakDay60: { xp: 300, coins: 150 },    // 60 日連續 + 徽章
  streakDay100: { xp: 500, coins: 300 },   // 100 日連續 + 徽章

  // ----------------------------------------
  // 特殊事件獎勵
  // ----------------------------------------
  earlyBird: { xp: 10, coins: 5 },         // 早起學習 (08:00 前) 每日一次
  weekendWarrior: { xp: 15, coins: 8 },    // 週末戰士
  perfectDay: { xp: 50, coins: 25 },       // 完美日（當日全部完成）每日一次

  // ----------------------------------------
  // 升級獎勵（金幣）
  // ----------------------------------------
  levelUp2to5: { xp: 0, coins: 20 },       // 升級 2-5
  levelUp6to10: { xp: 0, coins: 30 },      // 升級 6-10
  levelUp11to15: { xp: 0, coins: 40 },     // 升級 11-15
  levelUp16plus: { xp: 0, coins: 50 },     // 升級 16+
} as const satisfies Record<string, RewardAmount>;

// 向後相容：保留舊名稱
/** @deprecated 使用 DEFAULT_REWARDS */
export const REWARD_RULES = DEFAULT_REWARDS;

// ============================================
// Streak 連續登入加成倍率
// ============================================

export const STREAK_MULTIPLIERS: Record<string, number> = {
  '1-6': 1.0,     // 基礎倍率
  '7-13': 1.1,    // 一週達成
  '14-29': 1.15,  // 雙週達成
  '30-59': 1.2,   // 一月達成
  '60-99': 1.3,   // 雙月達成
  '100+': 1.5,    // 百日達成
};

/**
 * 根據連續天數取得加成倍率
 */
export function getStreakMultiplier(streakDays: number): number {
  if (streakDays >= 100) return 1.5;
  if (streakDays >= 60) return 1.3;
  if (streakDays >= 30) return 1.2;
  if (streakDays >= 14) return 1.15;
  if (streakDays >= 7) return 1.1;
  return 1.0;
}

// ============================================
// 等級系統 (XP_PER_LEVEL = 300)
// ============================================

export const XP_PER_LEVEL = 300;

/**
 * 根據總 XP 計算等級
 */
export function calculateLevel(totalXp: number): number {
  return Math.floor(totalXp / XP_PER_LEVEL) + 1;
}

/**
 * 計算當前等級進度
 */
export function calculateLevelProgress(totalXp: number): {
  level: number;
  currentXp: number;
  xpToNextLevel: number;
  progressPercent: number;
} {
  const level = calculateLevel(totalXp);
  const xpForCurrentLevel = (level - 1) * XP_PER_LEVEL;
  const currentXp = totalXp - xpForCurrentLevel;
  const xpToNextLevel = XP_PER_LEVEL - currentXp;
  const progressPercent = (currentXp / XP_PER_LEVEL) * 100;

  return { level, currentXp, xpToNextLevel, progressPercent };
}

// 等級稱號
export const LEVEL_TITLES: Record<string, { key: string; zh: string; en: string }> = {
  '1-5': { key: 'adventurer', zh: '學習冒險者', en: 'Learning Adventurer' },
  '6-10': { key: 'explorer', zh: '知識探索家', en: 'Knowledge Explorer' },
  '11-15': { key: 'seeker', zh: '智慧追尋者', en: 'Wisdom Seeker' },
  '16+': { key: 'master', zh: '學霸大師', en: 'Learning Master' },
};

/**
 * 根據等級取得稱號
 */
export function getLevelTitle(level: number): { key: string; zh: string; en: string } {
  if (level >= 16) return LEVEL_TITLES['16+'];
  if (level >= 11) return LEVEL_TITLES['11-15'];
  if (level >= 6) return LEVEL_TITLES['6-10'];
  return LEVEL_TITLES['1-5'];
}

// ============================================
// 每日獎勵上限
// ============================================

export const DAILY_LIMITS = {
  taskXp: 2000,       // 任務 XP 每日上限
  taskCoins: 500,     // 任務金幣每日上限
  examXp: 1000,       // 考試 XP 每日上限
  examCoins: 300,     // 考試金幣每日上限
  loginXp: 10,        // 登入 XP（每日一次）
  loginCoins: 5,      // 登入金幣（每日一次）
};

// ============================================
// 金幣經濟常數
// ============================================

/**
 * 金幣對新台幣匯率
 * 1000 金幣 = 1 NTD
 */
export const COINS_PER_NTD = 1000;

/**
 * 每月金幣收入預估（供成本控制參考）
 */
export const MONTHLY_COIN_ESTIMATES = {
  casual: 600,       // 偶爾使用學生
  regular: 900,      // 一般活躍學生
  active: 1200,      // 高度活躍學生
  hardcore: 1800,    // 頂尖學生（接近日限）
} as const;

/**
 * 每月成本預估（NTD）
 * monthly_cost = monthly_coins / COINS_PER_NTD
 */
export const MONTHLY_COST_ESTIMATES = {
  casual: 0.6,       // ~0.6 NTD/月
  regular: 0.9,      // ~0.9 NTD/月
  active: 1.2,       // ~1.2 NTD/月
  hardcore: 1.8,     // ~1.8 NTD/月
} as const;

/**
 * XP 對金幣比例說明
 * - 任務/考試基礎：約 5:1 ~ 6:1 (XP:金幣)
 * - 特殊加成：約 2:1 ~ 3:1 (鼓勵特定行為)
 * - 設計原則：XP 升級較容易，金幣較珍貴
 */
export const XP_TO_COIN_RATIO = {
  taskBase: 5,       // 任務基礎比例
  examBase: 5,       // 考試基礎比例
  bonusAvg: 2.5,     // 加成平均比例
  overallAvg: 4,     // 整體平均比例
} as const;

// ============================================
// 時長加成計算
// ============================================

/**
 * 根據任務預估時長計算額外獎勵
 * duration_bonus_xp = floor(estimated_duration / 10) * 10
 * duration_bonus_coins = floor(duration_bonus_xp / 10)
 */
export function calculateDurationBonus(estimatedMinutes: number): RewardAmount {
  const bonusXp = Math.floor(estimatedMinutes / 10) * 10;
  const bonusCoins = Math.floor(bonusXp / 10);
  return { xp: bonusXp, coins: bonusCoins };
}

// ============================================
// Badges
// ============================================

export type BadgeTier = 'bronze' | 'silver' | 'gold' | 'diamond';

export interface Badge {
  id: string;
  name: string;
  description: string;
  tier: BadgeTier;
  imageUrl?: string;
  emoji: string;
  xpReward: number;
  coinReward: number;
  isHidden: boolean;
  earnedAt?: string;
  progress?: {
    current: number;
    target: number;
    percentage: number;
  };
}

// ============================================
// Leaderboard
// ============================================

export type LeaderboardScope = 'class' | 'school' | 'global';
export type LeaderboardTimeframe = 'weekly' | 'monthly' | 'all_time';
export type LeaderboardMetric = 'xp' | 'accuracy' | 'streak';

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  displayName: string;
  avatarEmoji: string;
  level: number;
  value: number;
  change?: number; // rank change from previous period
  isCurrentUser?: boolean;
}

// ============================================
// Organization Management
// ============================================

export interface OrganizationShopSettings {
  organizationId: string;
  organizationName: string;
  isEnabled: boolean;
  rewards: OrganizationReward[];
}

export interface RedemptionRecord {
  id: string;
  orderId: string;
  studentId: string;
  studentName: string;
  rewardId: string;
  rewardName: string;
  currencySpent: number;
  currencyType: CurrencyType;
  redemptionCode: string;
  status: OrderStatus;
  createdAt: string;
  completedAt?: string;
}

// ============================================
// UI State
// ============================================

export interface ShopFilter {
  shopType: ShopType;
  rewardType: RewardType | 'all';
  category?: string;
}

export interface RedemptionState {
  isConfirming: boolean;
  isProcessing: boolean;
  isSuccess: boolean;
  selectedReward: Reward | OrganizationReward | null;
  redemptionCode?: string;
  error?: string;
}
