/**
 * Org Admin - 商品表單頁面
 *
 * 功能：
 * - 新增商品
 * - 編輯商品
 * - 表單驗證
 * - 圖片/Emoji 選擇
 */

import { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Package,
  Gift,
  Ticket,
  Save,
  AlertCircle,
  Check,
  Smile,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import type { ShopProduct, ProductType, CurrencyType, ProductFormData } from '../../types/org-admin';
import { MOCK_ADMIN_PRODUCTS } from '../../data/mockData';

// ============================================
// Constants
// ============================================

const PRODUCT_TYPES: { key: ProductType; label: string; icon: typeof Package; description: string }[] = [
  { key: 'physical', label: '實體獎品', icon: Gift, description: '需要現場領取的獎品' },
  { key: 'privilege', label: '特權', icon: Ticket, description: '特殊權益或服務' },
];

const CURRENCY_OPTIONS: { key: CurrencyType; label: string; icon: string }[] = [
  { key: 'coins', label: '金幣', icon: '🪙' },
  { key: 'xp', label: '經驗值', icon: '⚡' },
];

const COMMON_EMOJIS = [
  '📝', '⏰', '💺', '👨‍🏫', '🍰', '🍫', '🧽', '🎁',
  '✏️', '📚', '🎮', '🏆', '⭐', '🎯', '🎨', '🎵',
  '🧃', '🍟', '🍪', '🍬', '🎪', '🎭', '🎠', '🎡',
];

const DEFAULT_FORM_DATA: ProductFormData = {
  name: '',
  description: '',
  emoji: '📦',
  type: 'physical',
  category: '',
  price: 0,
  currency: 'coins',
  requiredLevel: 1,
  maxPerUser: 0,
  stock: 10,
  lowStockThreshold: 5,
  isActive: true,
};

// ============================================
// Components
// ============================================

function EmojiPicker({
  selected,
  onSelect,
  onClose,
}: {
  selected: string;
  onSelect: (emoji: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="absolute top-full left-0 mt-2 p-3 bg-white rounded-xl shadow-lg border border-surface-border z-20">
      <div className="grid grid-cols-8 gap-1">
        {COMMON_EMOJIS.map((emoji) => (
          <button
            key={emoji}
            type="button"
            onClick={() => {
              onSelect(emoji);
              onClose();
            }}
            className={cn(
              'w-10 h-10 rounded-lg text-xl flex items-center justify-center transition-colors',
              selected === emoji
                ? 'bg-tiffany-100 border-2 border-tiffany-500'
                : 'hover:bg-surface-hover'
            )}
          >
            {emoji}
          </button>
        ))}
      </div>
    </div>
  );
}

function FormSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-4">
      <h3 className="font-display text-text-primary border-b border-surface-border pb-2">
        {title}
      </h3>
      {children}
    </div>
  );
}

function FormField({
  label,
  required,
  error,
  hint,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <label className="block text-sm font-display text-text-secondary">
        {label}
        {required && <span className="text-accent-coral ml-1">*</span>}
      </label>
      {children}
      {error && (
        <p className="text-xs text-accent-coral flex items-center gap-1">
          <AlertCircle className="w-3 h-3" />
          {error}
        </p>
      )}
      {hint && !error && (
        <p className="text-xs text-text-muted">{hint}</p>
      )}
    </div>
  );
}

// ============================================
// Main Component
// ============================================

interface ProductFormPageProps {
  productId?: string;
  onBack: () => void;
  onSave: (product: ProductFormData) => void;
}

export function ProductFormPage({ productId, onBack, onSave }: ProductFormPageProps) {
  const isEditing = !!productId;
  const [formData, setFormData] = useState<ProductFormData>(DEFAULT_FORM_DATA);
  const [errors, setErrors] = useState<Partial<Record<keyof ProductFormData, string>>>({});
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // 載入編輯資料
  useEffect(() => {
    if (productId) {
      const product = MOCK_ADMIN_PRODUCTS.find((p) => p.id === productId);
      if (product) {
        setFormData({
          name: product.name,
          description: product.description,
          imageUrl: product.imageUrl,
          emoji: product.emoji,
          type: product.type,
          category: product.category,
          price: product.price,
          currency: product.currency,
          requiredLevel: product.requiredLevel,
          maxPerUser: product.maxPerUser,
          stock: product.stock,
          lowStockThreshold: product.lowStockThreshold,
          isActive: product.isActive,
        });
      }
    }
  }, [productId]);

  // 表單更新
  const updateField = <K extends keyof ProductFormData>(
    field: K,
    value: ProductFormData[K]
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // 清除該欄位的錯誤
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  // 表單驗證
  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof ProductFormData, string>> = {};

    if (!formData.name.trim()) {
      newErrors.name = '請輸入商品名稱';
    } else if (formData.name.length > 50) {
      newErrors.name = '商品名稱不能超過 50 個字';
    }

    if (!formData.description.trim()) {
      newErrors.description = '請輸入商品描述';
    } else if (formData.description.length > 200) {
      newErrors.description = '商品描述不能超過 200 個字';
    }

    if (formData.price < 0) {
      newErrors.price = '價格不能為負數';
    } else if (formData.price === 0) {
      newErrors.price = '請設定商品價格';
    }

    if (formData.requiredLevel < 1 || formData.requiredLevel > 20) {
      newErrors.requiredLevel = '等級要求需在 1-20 之間';
    }

    if (formData.stock < -1) {
      newErrors.stock = '庫存設定無效';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // 提交表單
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) return;

    setIsSaving(true);

    // 模擬 API 請求
    await new Promise((resolve) => setTimeout(resolve, 1000));

    setIsSaving(false);
    setSaveSuccess(true);

    setTimeout(() => {
      onSave(formData);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={onBack}
            className="p-2 rounded-xl hover:bg-surface-hover transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-text-secondary" />
          </button>
          <div>
            <h1 className="text-2xl font-display text-text-primary">
              {isEditing ? '編輯商品' : '新增商品'}
            </h1>
            <p className="text-sm text-text-muted">
              {isEditing ? '修改商品資訊' : '設定商品資訊和價格'}
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 基本資訊 */}
          <div className="card p-5">
            <FormSection title="基本資訊">
              {/* 商品名稱 */}
              <FormField label="商品名稱" required error={errors.name}>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  placeholder="輸入商品名稱..."
                  maxLength={50}
                  className={cn(
                    'w-full px-4 py-2.5 rounded-xl border bg-surface-bg transition-colors',
                    errors.name
                      ? 'border-accent-coral focus:border-accent-coral'
                      : 'border-surface-border focus:border-tiffany-500'
                  )}
                />
              </FormField>

              {/* 商品描述 */}
              <FormField
                label="商品描述"
                required
                error={errors.description}
                hint={`${formData.description.length}/200`}
              >
                <textarea
                  value={formData.description}
                  onChange={(e) => updateField('description', e.target.value)}
                  placeholder="輸入商品描述..."
                  maxLength={200}
                  rows={3}
                  className={cn(
                    'w-full px-4 py-2.5 rounded-xl border bg-surface-bg transition-colors resize-none',
                    errors.description
                      ? 'border-accent-coral focus:border-accent-coral'
                      : 'border-surface-border focus:border-tiffany-500'
                  )}
                />
              </FormField>

              {/* 圖示 */}
              <FormField label="商品圖示" hint="選擇一個代表商品的 Emoji">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                      className="w-16 h-16 rounded-xl bg-surface-elevated border-2 border-surface-border hover:border-tiffany-500 transition-colors flex items-center justify-center text-3xl"
                    >
                      {formData.emoji || '📦'}
                    </button>
                    {showEmojiPicker && (
                      <>
                        <div
                          className="fixed inset-0 z-10"
                          onClick={() => setShowEmojiPicker(false)}
                        />
                        <EmojiPicker
                          selected={formData.emoji || '📦'}
                          onSelect={(emoji) => updateField('emoji', emoji)}
                          onClose={() => setShowEmojiPicker(false)}
                        />
                      </>
                    )}
                  </div>
                  <button
                    type="button"
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-dashed border-surface-border hover:border-tiffany-500 text-text-muted hover:text-tiffany-600 transition-colors"
                    onClick={() => setShowEmojiPicker(true)}
                  >
                    <Smile className="w-4 h-4" />
                    選擇其他
                  </button>
                </div>
              </FormField>
            </FormSection>
          </div>

          {/* 商品類型 */}
          <div className="card p-5">
            <FormSection title="商品類型">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {PRODUCT_TYPES.map((type) => {
                  const Icon = type.icon;
                  const isSelected = formData.type === type.key;
                  return (
                    <button
                      key={type.key}
                      type="button"
                      onClick={() => updateField('type', type.key)}
                      className={cn(
                        'p-4 rounded-xl border-2 text-left transition-all',
                        isSelected
                          ? 'border-tiffany-500 bg-tiffany-50'
                          : 'border-surface-border hover:border-tiffany-300'
                      )}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <div
                          className={cn(
                            'w-10 h-10 rounded-lg flex items-center justify-center',
                            isSelected
                              ? 'bg-tiffany-500 text-white'
                              : 'bg-surface-elevated text-text-muted'
                          )}
                        >
                          <Icon className="w-5 h-5" />
                        </div>
                        {isSelected && (
                          <Check className="w-5 h-5 text-tiffany-500 ml-auto" />
                        )}
                      </div>
                      <p className="font-display text-text-primary">{type.label}</p>
                      <p className="text-xs text-text-muted">{type.description}</p>
                    </button>
                  );
                })}
              </div>
            </FormSection>
          </div>

          {/* 定價設定 */}
          <div className="card p-5">
            <FormSection title="定價設定">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 價格 */}
                <FormField label="價格" required error={errors.price}>
                  <input
                    type="number"
                    value={formData.price || ''}
                    onChange={(e) =>
                      updateField('price', parseInt(e.target.value) || 0)
                    }
                    placeholder="輸入價格..."
                    min={0}
                    className={cn(
                      'w-full px-4 py-2.5 rounded-xl border bg-surface-bg transition-colors',
                      errors.price
                        ? 'border-accent-coral focus:border-accent-coral'
                        : 'border-surface-border focus:border-tiffany-500'
                    )}
                  />
                </FormField>

                {/* 貨幣類型 */}
                <FormField label="貨幣類型">
                  <div className="flex gap-2">
                    {CURRENCY_OPTIONS.map((option) => (
                      <button
                        key={option.key}
                        type="button"
                        onClick={() => updateField('currency', option.key)}
                        className={cn(
                          'flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border-2 transition-all',
                          formData.currency === option.key
                            ? 'border-tiffany-500 bg-tiffany-50 text-tiffany-600'
                            : 'border-surface-border text-text-secondary hover:border-tiffany-300'
                        )}
                      >
                        <span>{option.icon}</span>
                        <span className="font-display">{option.label}</span>
                      </button>
                    ))}
                  </div>
                </FormField>
              </div>

              {/* 等級要求 */}
              <FormField
                label="等級要求"
                error={errors.requiredLevel}
                hint="學生需達到此等級才能購買"
              >
                <input
                  type="number"
                  value={formData.requiredLevel}
                  onChange={(e) =>
                    updateField('requiredLevel', parseInt(e.target.value) || 1)
                  }
                  min={1}
                  max={20}
                  className="w-32 px-4 py-2.5 rounded-xl border border-surface-border bg-surface-bg focus:border-tiffany-500 transition-colors"
                />
              </FormField>

              {/* 每人限購 */}
              <FormField
                label="每人限購"
                hint="設為 0 表示不限制"
              >
                <input
                  type="number"
                  value={formData.maxPerUser}
                  onChange={(e) =>
                    updateField('maxPerUser', parseInt(e.target.value) || 0)
                  }
                  min={0}
                  className="w-32 px-4 py-2.5 rounded-xl border border-surface-border bg-surface-bg focus:border-tiffany-500 transition-colors"
                />
              </FormField>
            </FormSection>
          </div>

          {/* 庫存設定 */}
          <div className="card p-5">
            <FormSection title="庫存設定">
              {/* 無限庫存開關 */}
              <label className="flex items-center gap-3 cursor-pointer">
                <div
                  className={cn(
                    'w-12 h-6 rounded-full transition-colors relative',
                    formData.stock === -1
                      ? 'bg-tiffany-500'
                      : 'bg-surface-hover'
                  )}
                  onClick={() =>
                    updateField('stock', formData.stock === -1 ? 10 : -1)
                  }
                >
                  <div
                    className={cn(
                      'absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform',
                      formData.stock === -1 ? 'translate-x-6' : 'translate-x-0.5'
                    )}
                  />
                </div>
                <span className="text-text-primary">無限庫存</span>
              </label>

              {formData.stock !== -1 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  {/* 庫存數量 */}
                  <FormField label="庫存數量" error={errors.stock}>
                    <input
                      type="number"
                      value={formData.stock}
                      onChange={(e) =>
                        updateField('stock', parseInt(e.target.value) || 0)
                      }
                      min={0}
                      className="w-full px-4 py-2.5 rounded-xl border border-surface-border bg-surface-bg focus:border-tiffany-500 transition-colors"
                    />
                  </FormField>

                  {/* 低庫存警告 */}
                  <FormField
                    label="低庫存警告"
                    hint="低於此數量時顯示警告"
                  >
                    <input
                      type="number"
                      value={formData.lowStockThreshold}
                      onChange={(e) =>
                        updateField(
                          'lowStockThreshold',
                          parseInt(e.target.value) || 0
                        )
                      }
                      min={0}
                      className="w-full px-4 py-2.5 rounded-xl border border-surface-border bg-surface-bg focus:border-tiffany-500 transition-colors"
                    />
                  </FormField>
                </div>
              )}
            </FormSection>
          </div>

          {/* 狀態設定 */}
          <div className="card p-5">
            <FormSection title="商品狀態">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-display text-text-primary">
                    {formData.isActive ? '上架中' : '已下架'}
                  </p>
                  <p className="text-sm text-text-muted">
                    {formData.isActive
                      ? '學生可在商店中看到此商品'
                      : '商品不會顯示在商店中'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => updateField('isActive', !formData.isActive)}
                  className={cn(
                    'w-14 h-8 rounded-full transition-colors relative',
                    formData.isActive ? 'bg-accent-mint' : 'bg-surface-hover'
                  )}
                >
                  <div
                    className={cn(
                      'absolute top-1 w-6 h-6 rounded-full bg-white shadow transition-transform',
                      formData.isActive ? 'translate-x-7' : 'translate-x-1'
                    )}
                  />
                </button>
              </div>
            </FormSection>
          </div>

          {/* 操作按鈕 */}
          <div className="flex gap-3 justify-end">
            <button
              type="button"
              onClick={onBack}
              className="px-6 py-2.5 rounded-xl border border-surface-border text-text-secondary hover:bg-surface-hover transition-colors font-display"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={isSaving || saveSuccess}
              className={cn(
                'flex items-center gap-2 px-6 py-2.5 rounded-xl font-display transition-all',
                saveSuccess
                  ? 'bg-accent-mint text-white'
                  : 'btn-teal'
              )}
            >
              {isSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  儲存中...
                </>
              ) : saveSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  已儲存
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  {isEditing ? '更新商品' : '建立商品'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ProductFormPage;
