/**
 * Org Admin - 獎品管理頁面
 *
 * 功能：
 * - 獎品列表展示（表格/卡片視圖）
 * - 搜尋和篩選
 * - 新增/編輯/刪除獎品
 * - 批量操作
 */

import { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Filter,
  Package,
  Gift,
  Ticket,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import type { ShopProduct, ProductType, ProductStatus } from '../../types/org-admin';
import { MOCK_ADMIN_PRODUCTS, getProductStats } from '../../data/mockData';

// ============================================
// Constants
// ============================================

const PRODUCT_TYPE_CONFIG: Record<ProductType, { label: string; icon: typeof Package; color: string }> = {
  physical: { label: '實體獎品', icon: Gift, color: 'text-tier-gold bg-tier-gold/10 border-tier-gold/30' },
  privilege: { label: '特權', icon: Ticket, color: 'text-accent-pink bg-accent-pink/10 border-accent-pink/30' },
};

const STATUS_TABS: { key: ProductStatus | 'all'; label: string }[] = [
  { key: 'all', label: '全部' },
  { key: 'active', label: '上架中' },
  { key: 'out_of_stock', label: '缺貨' },
  { key: 'inactive', label: '已下架' },
];

const PAGE_SIZE = 10;

// ============================================
// Helper Functions
// ============================================

function getProductStatus(product: ShopProduct): ProductStatus {
  if (!product.isActive) return 'inactive';
  if (product.stock === 0) return 'out_of_stock';
  return 'active';
}

function getStatusBadge(status: ProductStatus) {
  const config = {
    active: { label: '上架中', class: 'bg-accent-mint/10 text-accent-mint border-accent-mint/30' },
    out_of_stock: { label: '缺貨', class: 'bg-accent-coral/10 text-accent-coral border-accent-coral/30' },
    inactive: { label: '已下架', class: 'bg-surface-hover text-text-muted border-surface-border' },
  };
  return config[status];
}

// ============================================
// Components
// ============================================

function StatsCards({ products }: { products: ShopProduct[] }) {
  const stats = getProductStats(products);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
      <div className="card p-4">
        <div className="flex items-center gap-2 text-text-muted text-sm mb-1">
          <Gift className="w-4 h-4" />
          全部獎品
        </div>
        <p className="text-2xl font-display text-text-primary">{stats.total}</p>
      </div>
      <div className="card p-4 border-2 border-accent-mint/20">
        <div className="flex items-center gap-2 text-accent-mint text-sm mb-1">
          <Eye className="w-4 h-4" />
          上架中
        </div>
        <p className="text-2xl font-display text-accent-mint">{stats.active}</p>
      </div>
      <div className="card p-4 border-2 border-accent-coral/20">
        <div className="flex items-center gap-2 text-accent-coral text-sm mb-1">
          <AlertTriangle className="w-4 h-4" />
          缺貨
        </div>
        <p className="text-2xl font-display text-accent-coral">{stats.outOfStock}</p>
      </div>
      <div className="card p-4">
        <div className="flex items-center gap-2 text-text-muted text-sm mb-1">
          <EyeOff className="w-4 h-4" />
          已下架
        </div>
        <p className="text-2xl font-display text-text-secondary">{stats.inactive}</p>
      </div>
    </div>
  );
}

function ProductRow({
  product,
  onEdit,
  onToggleStatus,
  onDelete,
}: {
  product: ShopProduct;
  onEdit: () => void;
  onToggleStatus: () => void;
  onDelete: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const status = getProductStatus(product);
  const statusBadge = getStatusBadge(status);
  const typeConfig = PRODUCT_TYPE_CONFIG[product.type];
  const TypeIcon = typeConfig.icon;
  const isLowStock = product.stock > 0 && product.stock <= product.lowStockThreshold;

  return (
    <tr className="border-b border-surface-border hover:bg-surface-elevated/50 transition-colors">
      {/* 獎品 */}
      <td className="py-4 px-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-surface-elevated flex items-center justify-center text-2xl border border-surface-border">
            {product.emoji || '🎁'}
          </div>
          <div>
            <p className="font-display text-text-primary">{product.name}</p>
            <p className="text-xs text-text-muted line-clamp-1">{product.description}</p>
          </div>
        </div>
      </td>

      {/* 類型 */}
      <td className="py-4 px-4">
        <span className={cn(
          'inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-display border',
          typeConfig.color
        )}>
          <TypeIcon className="w-3 h-3" />
          {typeConfig.label}
        </span>
      </td>

      {/* 價格 */}
      <td className="py-4 px-4">
        <span className="flex items-center gap-1 font-display text-text-primary">
          {product.currency === 'coins' ? '🪙' : '⚡'}
          {product.price}
        </span>
      </td>

      {/* 庫存 */}
      <td className="py-4 px-4">
        <div className="flex items-center gap-2">
          <span className={cn(
            'font-display',
            product.stock === -1 ? 'text-text-secondary' :
            product.stock === 0 ? 'text-accent-coral' :
            isLowStock ? 'text-tier-gold' : 'text-text-primary'
          )}>
            {product.stock === -1 ? '∞' : product.stock}
          </span>
          {isLowStock && (
            <AlertTriangle className="w-4 h-4 text-tier-gold" />
          )}
        </div>
      </td>

      {/* 狀態 */}
      <td className="py-4 px-4">
        <span className={cn(
          'inline-flex px-2 py-1 rounded-lg text-xs font-display border',
          statusBadge.class
        )}>
          {statusBadge.label}
        </span>
      </td>

      {/* 兌換次數 */}
      <td className="py-4 px-4 text-text-secondary">
        {product.totalSold}
      </td>

      {/* 操作 */}
      <td className="py-4 px-4">
        <div className="relative">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 rounded-lg hover:bg-surface-hover transition-colors"
          >
            <MoreVertical className="w-4 h-4 text-text-muted" />
          </button>

          {menuOpen && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setMenuOpen(false)}
              />
              <div className="absolute right-0 top-full mt-1 w-36 bg-white rounded-xl shadow-lg border border-surface-border z-20 py-1">
                <button
                  onClick={() => { onEdit(); setMenuOpen(false); }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-text-primary hover:bg-surface-elevated transition-colors"
                >
                  <Edit className="w-4 h-4" />
                  編輯
                </button>
                <button
                  onClick={() => { onToggleStatus(); setMenuOpen(false); }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-text-primary hover:bg-surface-elevated transition-colors"
                >
                  {product.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  {product.isActive ? '下架' : '上架'}
                </button>
                <button
                  onClick={() => { onDelete(); setMenuOpen(false); }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-accent-coral hover:bg-accent-coral/10 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  刪除
                </button>
              </div>
            </>
          )}
        </div>
      </td>
    </tr>
  );
}

function Pagination({
  currentPage,
  totalPages,
  onPageChange,
}: {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-2 mt-4">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={cn(
          'p-2 rounded-lg transition-colors',
          currentPage === 1
            ? 'text-text-muted cursor-not-allowed'
            : 'text-text-secondary hover:bg-surface-hover'
        )}
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
        <button
          key={page}
          onClick={() => onPageChange(page)}
          className={cn(
            'w-10 h-10 rounded-lg font-display transition-colors',
            page === currentPage
              ? 'bg-tiffany-500 text-white'
              : 'text-text-secondary hover:bg-surface-hover'
          )}
        >
          {page}
        </button>
      ))}

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={cn(
          'p-2 rounded-lg transition-colors',
          currentPage === totalPages
            ? 'text-text-muted cursor-not-allowed'
            : 'text-text-secondary hover:bg-surface-hover'
        )}
      >
        <ChevronRight className="w-5 h-5" />
      </button>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

export function ProductsListPage() {
  const [products, setProducts] = useState<ShopProduct[]>(MOCK_ADMIN_PRODUCTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<ProductStatus | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<ProductType | 'all'>('all');
  const [currentPage, setCurrentPage] = useState(1);

  // 篩選獎品
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      // 搜尋
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        if (!product.name.toLowerCase().includes(query) &&
            !product.description.toLowerCase().includes(query)) {
          return false;
        }
      }

      // 狀態篩選
      if (statusFilter !== 'all') {
        const status = getProductStatus(product);
        if (status !== statusFilter) return false;
      }

      // 類型篩選
      if (typeFilter !== 'all' && product.type !== typeFilter) {
        return false;
      }

      return true;
    });
  }, [products, searchQuery, statusFilter, typeFilter]);

  // 分頁
  const totalPages = Math.ceil(filteredProducts.length / PAGE_SIZE);
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  // 處理狀態切換
  const handleToggleStatus = (productId: string) => {
    setProducts(prev => prev.map(p =>
      p.id === productId ? { ...p, isActive: !p.isActive } : p
    ));
  };

  // 處理刪除
  const handleDelete = (productId: string) => {
    if (confirm('確定要刪除此獎品嗎？')) {
      setProducts(prev => prev.filter(p => p.id !== productId));
    }
  };

  // 重置頁碼當篩選改變
  const handleFilterChange = (filter: ProductStatus | 'all') => {
    setStatusFilter(filter);
    setCurrentPage(1);
  };

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-display text-text-primary">獎品管理</h1>
            <p className="text-sm text-text-muted">管理機構所有兌換獎品</p>
          </div>
          <button className="btn-teal flex items-center gap-2">
            <Plus className="w-4 h-4" />
            新增獎品
          </button>
        </div>

        {/* Stats */}
        <StatsCards products={products} />

        {/* Filters */}
        <div className="card p-4 mb-4">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
              <input
                type="text"
                placeholder="搜尋獎品名稱..."
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-surface-border bg-surface-bg focus:outline-none focus:border-tiffany-500 transition-colors"
              />
            </div>

            {/* Type Filter */}
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-text-muted" />
              <select
                value={typeFilter}
                onChange={(e) => { setTypeFilter(e.target.value as ProductType | 'all'); setCurrentPage(1); }}
                className="px-3 py-2.5 rounded-xl border border-surface-border bg-surface-bg focus:outline-none focus:border-tiffany-500 transition-colors"
              >
                <option value="all">全部類型</option>
                <option value="physical">實體獎品</option>
                <option value="virtual">虛擬道具</option>
                <option value="privilege">特權</option>
              </select>
            </div>
          </div>

          {/* Status Tabs */}
          <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
            {STATUS_TABS.map(tab => {
              const count = tab.key === 'all'
                ? products.length
                : products.filter(p => getProductStatus(p) === tab.key).length;

              return (
                <button
                  key={tab.key}
                  onClick={() => handleFilterChange(tab.key)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-xl font-display text-sm whitespace-nowrap transition-all',
                    statusFilter === tab.key
                      ? 'bg-tiffany-500 text-white'
                      : 'bg-surface-elevated text-text-secondary hover:bg-surface-hover'
                  )}
                >
                  {tab.label}
                  <span className={cn(
                    'px-1.5 py-0.5 rounded-full text-xs',
                    statusFilter === tab.key
                      ? 'bg-white/20'
                      : 'bg-surface-hover'
                  )}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Products Table */}
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-surface-border bg-surface-elevated">
                  <th className="py-3 px-4 text-left text-sm font-display text-text-secondary">獎品</th>
                  <th className="py-3 px-4 text-left text-sm font-display text-text-secondary">類型</th>
                  <th className="py-3 px-4 text-left text-sm font-display text-text-secondary">價格</th>
                  <th className="py-3 px-4 text-left text-sm font-display text-text-secondary">庫存</th>
                  <th className="py-3 px-4 text-left text-sm font-display text-text-secondary">狀態</th>
                  <th className="py-3 px-4 text-left text-sm font-display text-text-secondary">兌換次數</th>
                  <th className="py-3 px-4 text-left text-sm font-display text-text-secondary">操作</th>
                </tr>
              </thead>
              <tbody>
                {paginatedProducts.map(product => (
                  <ProductRow
                    key={product.id}
                    product={product}
                    onEdit={() => console.log('Edit', product.id)}
                    onToggleStatus={() => handleToggleStatus(product.id)}
                    onDelete={() => handleDelete(product.id)}
                  />
                ))}
              </tbody>
            </table>
          </div>

          {/* Empty State */}
          {paginatedProducts.length === 0 && (
            <div className="py-12 text-center">
              <Gift className="w-12 h-12 text-text-muted mx-auto mb-3" />
              <p className="text-text-muted font-display">沒有符合條件的獎品</p>
            </div>
          )}

          {/* Pagination */}
          <div className="p-4 border-t border-surface-border">
            <div className="flex items-center justify-between text-sm text-text-muted">
              <span>
                顯示 {(currentPage - 1) * PAGE_SIZE + 1} - {Math.min(currentPage * PAGE_SIZE, filteredProducts.length)} 共 {filteredProducts.length} 項
              </span>
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductsListPage;
