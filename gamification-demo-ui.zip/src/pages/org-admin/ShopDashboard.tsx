/**
 * Org Admin - 獎品兌換管理儀表板
 *
 * 功能：
 * - 兌換總覽統計
 * - 兌換趨勢圖表
 * - 熱門獎品排行
 * - 最新兌換申請
 * - 學生兌換排行
 */

import { useState } from 'react';
import {
  Gift,
  Package,
  Repeat,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  BarChart3,
  Coins,
  ChevronRight,
  Search,
  CheckCircle,
  X,
  Keyboard,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import {
  MOCK_ORGANIZATION,
  MOCK_SHOP_STATS,
  MOCK_SALES_DATA,
  MOCK_TOP_PRODUCTS,
  MOCK_STUDENT_SPENDING,
  MOCK_ADMIN_ORDERS,
  formatDateTime,
} from '../../data/mockData';

// ============================================
// Components
// ============================================

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendValue,
  variant = 'default',
}: {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: typeof Gift;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  variant?: 'default' | 'primary' | 'warning' | 'danger';
}) {
  const variantStyles = {
    default: 'bg-white border-surface-border',
    primary: 'bg-gradient-to-br from-tiffany-50 to-accent-cyan/10 border-tiffany-200',
    warning: 'bg-tier-gold/5 border-tier-gold/30',
    danger: 'bg-accent-coral/5 border-accent-coral/30',
  };

  const iconStyles = {
    default: 'bg-surface-elevated text-text-muted',
    primary: 'bg-tiffany-500 text-white',
    warning: 'bg-tier-gold text-white',
    danger: 'bg-accent-coral text-white',
  };

  return (
    <div className={cn('card p-5 border-2', variantStyles[variant])}>
      <div className="flex items-start justify-between">
        <div
          className={cn(
            'w-12 h-12 rounded-xl flex items-center justify-center',
            iconStyles[variant]
          )}
        >
          <Icon className="w-6 h-6" />
        </div>
        {trend && trendValue && (
          <div
            className={cn(
              'flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-display',
              trend === 'up'
                ? 'bg-accent-mint/10 text-accent-mint'
                : trend === 'down'
                  ? 'bg-accent-coral/10 text-accent-coral'
                  : 'bg-surface-elevated text-text-muted'
            )}
          >
            {trend === 'up' ? (
              <TrendingUp className="w-3 h-3" />
            ) : trend === 'down' ? (
              <TrendingDown className="w-3 h-3" />
            ) : null}
            {trendValue}
          </div>
        )}
      </div>
      <div className="mt-4">
        <p className="text-2xl font-display text-text-primary">{value}</p>
        <p className="text-sm text-text-muted">{title}</p>
        {subtitle && <p className="text-xs text-text-muted mt-1">{subtitle}</p>}
      </div>
    </div>
  );
}

function RedemptionChart() {
  const maxRevenue = Math.max(...MOCK_SALES_DATA.map((d) => d.revenue));
  // Bar chart area: 120px for bars, leaving room for dots (12px) and date labels (16px)
  const maxBarHeight = 120;

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-display text-text-primary">兌換趨勢</h3>
          <p className="text-sm text-text-muted">過去 14 天</p>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-tiffany-500" />
            <span className="text-text-muted">金幣消耗</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-accent-pink" />
            <span className="text-text-muted">兌換數</span>
          </div>
        </div>
      </div>

      {/* Simple Bar Chart - fixed height with overflow protection */}
      <div className="h-48 flex items-end gap-2 overflow-hidden">
        {MOCK_SALES_DATA.map((data, index) => {
          const barHeight = maxRevenue > 0 ? (data.revenue / maxRevenue) * maxBarHeight : 0;

          return (
            <div key={data.date} className="flex-1 flex flex-col items-center gap-1 min-w-0">
              <div className="w-full flex flex-col items-center gap-0.5">
                {/* Revenue Bar */}
                <div
                  className="w-full bg-gradient-to-t from-tiffany-500 to-tiffany-400 rounded-t transition-all hover:from-tiffany-600 hover:to-tiffany-500 cursor-pointer"
                  style={{
                    height: `${barHeight}px`,
                    minHeight: data.revenue > 0 ? '4px' : '0px',
                  }}
                  title={`${data.revenue.toLocaleString()} 金幣`}
                />
                {/* Order dots */}
                <div className="flex gap-0.5 h-3 items-center">
                  {Array.from({ length: Math.min(data.orders, 5) }).map((_, i) => (
                    <div
                      key={i}
                      className="w-1.5 h-1.5 rounded-full bg-accent-pink"
                    />
                  ))}
                </div>
              </div>
              {/* Date Label (show every other) */}
              {index % 2 === 0 && (
                <span className="text-[10px] text-text-muted h-4">
                  {new Date(data.date).getDate()}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TopRewardsList({ onViewAll }: { onViewAll: () => void }) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-text-primary">熱門獎品</h3>
        <button
          onClick={onViewAll}
          className="flex items-center gap-1 text-sm text-tiffany-600 hover:text-tiffany-700"
        >
          查看全部
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {MOCK_TOP_PRODUCTS.slice(0, 5).map((item) => (
          <div
            key={item.product.id}
            className="flex items-center gap-3 p-3 rounded-xl bg-surface-elevated"
          >
            {/* Rank */}
            <div
              className={cn(
                'w-8 h-8 rounded-lg flex items-center justify-center font-display text-sm',
                item.rank === 1
                  ? 'bg-tier-gold/20 text-tier-gold'
                  : item.rank === 2
                    ? 'bg-gray-200 text-gray-600'
                    : item.rank === 3
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-surface-hover text-text-muted'
              )}
            >
              {item.rank}
            </div>

            {/* Product Info */}
            <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
              {item.product.emoji || '🎁'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-display text-text-primary text-sm truncate">
                {item.product.name}
              </p>
              <p className="text-xs text-text-muted">
                已兌換 {item.soldCount} 次
              </p>
            </div>

            {/* Coins Spent */}
            <div className="text-right">
              <p className="font-display text-tier-gold flex items-center gap-1">
                🪙 {item.revenue.toLocaleString()}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RecentRedemptionsList({ onViewAll }: { onViewAll: () => void }) {
  const recentOrders = MOCK_ADMIN_ORDERS.slice(0, 5);

  const statusColors: Record<string, string> = {
    pending: 'bg-tier-gold/10 text-tier-gold border-tier-gold/30',
    confirmed: 'bg-tiffany-50 text-tiffany-600 border-tiffany-200',
    ready: 'bg-accent-mint/10 text-accent-mint border-accent-mint/30',
    completed: 'bg-surface-elevated text-text-muted border-surface-border',
    cancelled: 'bg-accent-coral/10 text-accent-coral border-accent-coral/30',
    expired: 'bg-surface-hover text-text-muted border-surface-border',
  };

  const statusLabels: Record<string, string> = {
    pending: '待處理',
    confirmed: '已確認',
    ready: '可領取',
    completed: '已領取',
    cancelled: '已取消',
    expired: '已過期',
  };

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-text-primary">最新兌換</h3>
        <button
          onClick={onViewAll}
          className="flex items-center gap-1 text-sm text-tiffany-600 hover:text-tiffany-700"
        >
          查看全部
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {recentOrders.map((order) => (
          <div
            key={order.id}
            className="flex items-center gap-3 p-3 rounded-xl bg-surface-elevated"
          >
            {/* Student Avatar */}
            <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
              {order.studentAvatar || '👤'}
            </div>

            {/* Order Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="font-display text-text-primary text-sm">
                  {order.studentName}
                </p>
                <span
                  className={cn(
                    'px-2 py-0.5 rounded text-[10px] font-display border',
                    statusColors[order.status]
                  )}
                >
                  {statusLabels[order.status]}
                </span>
              </div>
              <p className="text-xs text-text-muted truncate">
                {order.itemSnapshot.name} × {order.quantity}
              </p>
            </div>

            {/* Time */}
            <div className="text-right">
              <p className="text-xs text-text-muted">
                {formatDateTime(order.createdAt).split(' ')[1]}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StudentRedemptionRankingList({ onViewAll }: { onViewAll: () => void }) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-text-primary">兌換排行</h3>
        <button
          onClick={onViewAll}
          className="flex items-center gap-1 text-sm text-tiffany-600 hover:text-tiffany-700"
        >
          查看全部
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {MOCK_STUDENT_SPENDING.map((student, index) => (
          <div
            key={student.studentId}
            className="flex items-center gap-3 p-3 rounded-xl bg-surface-elevated"
          >
            {/* Rank */}
            <div
              className={cn(
                'w-8 h-8 rounded-lg flex items-center justify-center font-display text-sm',
                index === 0
                  ? 'bg-tier-gold/20 text-tier-gold'
                  : index === 1
                    ? 'bg-gray-200 text-gray-600'
                    : index === 2
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-surface-hover text-text-muted'
              )}
            >
              {index + 1}
            </div>

            {/* Student Info */}
            <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
              {student.studentAvatar || '👤'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-display text-text-primary text-sm truncate">
                {student.studentName}
              </p>
              <p className="text-xs text-text-muted">
                {student.className} • {student.orderCount} 次兌換
              </p>
            </div>

            {/* Total Spent */}
            <div className="text-right">
              <p className="font-display text-tier-gold flex items-center gap-1">
                🪙 {student.totalSpent.toLocaleString()}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function QuickActions({
  onNavigate,
}: {
  onNavigate: (page: string) => void;
}) {
  const actions = [
    {
      icon: Gift,
      label: '新增獎品',
      description: '上架新的兌換獎品',
      color: 'bg-tiffany-500',
      onClick: () => onNavigate('product-form'),
    },
    {
      icon: Repeat,
      label: '處理兌換',
      description: `${MOCK_SHOP_STATS.pendingOrders} 筆待處理`,
      color: 'bg-tier-gold',
      badge: MOCK_SHOP_STATS.pendingOrders,
      onClick: () => onNavigate('orders'),
    },
    {
      icon: AlertTriangle,
      label: '庫存警告',
      description: `${MOCK_SHOP_STATS.outOfStockProducts} 個缺貨獎品`,
      color: 'bg-accent-coral',
      badge: MOCK_SHOP_STATS.outOfStockProducts,
      onClick: () => onNavigate('products'),
    },
    {
      icon: BarChart3,
      label: '查看報表',
      description: '詳細兌換分析',
      color: 'bg-accent-pink',
      onClick: () => onNavigate('reports'),
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {actions.map((action) => (
        <button
          key={action.label}
          onClick={action.onClick}
          className="card p-4 text-left hover:shadow-md transition-all group cursor-pointer"
        >
          <div className="flex items-start justify-between mb-3">
            <div
              className={cn(
                'w-10 h-10 rounded-xl flex items-center justify-center text-white',
                action.color
              )}
            >
              <action.icon className="w-5 h-5" />
            </div>
            {action.badge && action.badge > 0 && (
              <span className="px-2 py-0.5 bg-accent-coral text-white text-xs font-bold rounded-full">
                {action.badge}
              </span>
            )}
          </div>
          <p className="font-display text-text-primary group-hover:text-tiffany-600 transition-colors">
            {action.label}
          </p>
          <p className="text-xs text-text-muted">{action.description}</p>
        </button>
      ))}
    </div>
  );
}

// Quick Redemption Code Input Component
function QuickRedemptionInput({
  onRedemptionComplete,
}: {
  onRedemptionComplete?: () => void;
}) {
  const [code, setCode] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [foundOrder, setFoundOrder] = useState<typeof MOCK_ADMIN_ORDERS[0] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  // Search for order by redemption code
  const handleSearch = () => {
    if (!code.trim()) {
      setError('請輸入兌換碼');
      return;
    }

    setIsSearching(true);
    setError(null);
    setFoundOrder(null);

    // Simulate API call - search in mock data
    setTimeout(() => {
      const normalizedCode = code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
      const order = MOCK_ADMIN_ORDERS.find((o) => {
        const orderCode = o.redemptionCode?.toUpperCase().replace(/[^A-Z0-9]/g, '');
        return orderCode === normalizedCode && o.status === 'ready';
      });

      if (order) {
        setFoundOrder(order);
      } else {
        // Check if code exists but wrong status
        const anyOrder = MOCK_ADMIN_ORDERS.find((o) => {
          const orderCode = o.redemptionCode?.toUpperCase().replace(/[^A-Z0-9]/g, '');
          return orderCode === normalizedCode;
        });

        if (anyOrder) {
          if (anyOrder.status === 'completed') {
            setError('此兌換碼已使用完畢');
          } else if (anyOrder.status === 'cancelled') {
            setError('此兌換碼已被取消');
          } else if (anyOrder.status === 'expired') {
            setError('此兌換碼已過期');
          } else {
            setError('此訂單尚未準備好領取');
          }
        } else {
          setError('找不到此兌換碼，請確認輸入是否正確');
        }
      }
      setIsSearching(false);
    }, 500);
  };

  // Handle confirm redemption
  const handleConfirmRedemption = () => {
    if (!foundOrder) return;

    // In real app, this would call API to complete the order
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setFoundOrder(null);
      setCode('');
      onRedemptionComplete?.();
    }, 2000);
  };

  // Handle key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  // Reset state
  const handleReset = () => {
    setCode('');
    setFoundOrder(null);
    setError(null);
    setShowSuccess(false);
  };

  const statusLabels: Record<string, string> = {
    pending: '待處理',
    confirmed: '已確認',
    ready: '可領取',
    completed: '已領取',
    cancelled: '已取消',
    expired: '已過期',
  };

  return (
    <div className="card p-5">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent-mint to-tiffany-500 flex items-center justify-center">
          <Keyboard className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="font-display text-text-primary">快捷兌換</h3>
          <p className="text-xs text-text-muted">輸入兌換碼完成領取</p>
        </div>
      </div>

      {/* Success Message */}
      {showSuccess && (
        <div className="p-4 rounded-xl bg-accent-mint/10 border border-accent-mint/30 mb-4">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-accent-mint" />
            <div>
              <p className="font-display text-accent-mint">兌換完成！</p>
              <p className="text-sm text-accent-mint/80">
                {foundOrder?.studentName} 已成功領取 {foundOrder?.itemSnapshot.name}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Code Input */}
      {!showSuccess && !foundOrder && (
        <div className="space-y-3">
          <div className="relative">
            <input
              type="text"
              placeholder="輸入兌換碼 (例: ABCD-1234)"
              value={code}
              onChange={(e) => {
                setCode(e.target.value.toUpperCase());
                setError(null);
              }}
              onKeyPress={handleKeyPress}
              className={cn(
                'w-full pl-4 pr-12 py-3 rounded-xl bg-surface-elevated border text-sm font-mono tracking-wider',
                'focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 focus:border-tiffany-500',
                'placeholder:font-sans placeholder:tracking-normal',
                error ? 'border-accent-coral' : 'border-surface-border'
              )}
              maxLength={9}
            />
            <button
              onClick={handleSearch}
              disabled={isSearching || !code.trim()}
              className={cn(
                'absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-colors',
                code.trim()
                  ? 'bg-tiffany-500 text-white hover:bg-tiffany-600'
                  : 'bg-surface-hover text-text-muted'
              )}
            >
              {isSearching ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Search className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <p className="text-sm text-accent-coral flex items-center gap-1">
              <X className="w-4 h-4" />
              {error}
            </p>
          )}

          <p className="text-xs text-text-muted">
            請學生出示兌換碼，輸入後按 Enter 或點擊搜尋
          </p>
        </div>
      )}

      {/* Found Order Preview */}
      {!showSuccess && foundOrder && (
        <div className="space-y-4">
          {/* Order Info Card */}
          <div className="p-4 rounded-xl bg-surface-elevated border-2 border-accent-mint/30">
            <div className="flex items-start gap-3">
              {/* Student Avatar */}
              <div className="w-12 h-12 rounded-xl bg-surface-bg flex items-center justify-center text-2xl">
                {foundOrder.studentAvatar || '👤'}
              </div>

              <div className="flex-1 min-w-0">
                {/* Student Name & Status */}
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-display text-text-primary">{foundOrder.studentName}</p>
                  <span className="px-2 py-0.5 rounded text-[10px] font-display bg-accent-mint/10 text-accent-mint border border-accent-mint/30">
                    {statusLabels[foundOrder.status]}
                  </span>
                </div>

                {/* Class */}
                <p className="text-xs text-text-muted mb-2">{foundOrder.className}</p>

                {/* Item Info */}
                <div className="flex items-center gap-2 p-2 rounded-lg bg-surface-bg">
                  <span className="text-lg">{foundOrder.itemSnapshot.emoji || '🎁'}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-display text-text-primary truncate">
                      {foundOrder.itemSnapshot.name}
                    </p>
                    <p className="text-xs text-text-muted">× {foundOrder.quantity}</p>
                  </div>
                  <p className="font-display text-tier-gold">🪙 {foundOrder.totalPrice}</p>
                </div>
              </div>
            </div>

            {/* Redemption Code Display */}
            <div className="mt-3 p-2 rounded-lg bg-accent-mint/10 border border-accent-mint/20">
              <div className="flex items-center justify-between">
                <span className="text-xs text-accent-mint">兌換碼</span>
                <span className="font-mono font-bold text-accent-mint">{foundOrder.redemptionCode}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleReset}
              className="flex-1 px-4 py-3 rounded-xl border border-surface-border text-text-secondary hover:bg-surface-hover transition-colors"
            >
              取消
            </button>
            <button
              onClick={handleConfirmRedemption}
              className="flex-1 px-4 py-3 rounded-xl bg-gradient-to-r from-accent-mint to-tiffany-500 text-white font-display hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              確認領取
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// Main Component
// ============================================

interface ShopDashboardProps {
  onNavigate: (page: string) => void;
}

export function ShopDashboard({ onNavigate }: ShopDashboardProps) {
  const stats = MOCK_SHOP_STATS;

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-tiffany-500 to-accent-cyan flex items-center justify-center shadow-teal">
              <Gift className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-display text-text-primary">
                獎品兌換管理
              </h1>
              <p className="text-sm text-text-muted">
                {MOCK_ORGANIZATION.name} 兌換儀表板
              </p>
            </div>
          </div>
        </div>

        {/* Quick Actions & Quick Redemption */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="lg:col-span-2">
            <QuickActions onNavigate={onNavigate} />
          </div>
          <div>
            <QuickRedemptionInput />
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            title="本月金幣消耗"
            value={`🪙 ${stats.monthRevenue.toLocaleString()}`}
            icon={Coins}
            trend={stats.revenueGrowth > 0 ? 'up' : 'down'}
            trendValue={`${stats.revenueGrowth > 0 ? '+' : ''}${stats.revenueGrowth}%`}
            variant="primary"
          />
          <StatCard
            title="本月兌換"
            value={stats.totalOrders}
            subtitle={`待處理 ${stats.pendingOrders} 筆`}
            icon={Repeat}
            trend={stats.orderGrowth > 0 ? 'up' : 'down'}
            trendValue={`${stats.orderGrowth > 0 ? '+' : ''}${stats.orderGrowth}%`}
            variant={stats.pendingOrders > 0 ? 'warning' : 'default'}
          />
          <StatCard
            title="上架獎品"
            value={stats.activeProducts}
            subtitle={`共 ${stats.totalProducts} 個獎品`}
            icon={Package}
            variant="default"
          />
          <StatCard
            title="庫存警告"
            value={stats.outOfStockProducts}
            subtitle="需要補貨"
            icon={AlertTriangle}
            variant={stats.outOfStockProducts > 0 ? 'danger' : 'default'}
          />
        </div>

        {/* Charts and Lists */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <RedemptionChart />
          <TopRewardsList onViewAll={() => onNavigate('products')} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentRedemptionsList onViewAll={() => onNavigate('orders')} />
          <StudentRedemptionRankingList onViewAll={() => onNavigate('reports')} />
        </div>
      </div>
    </div>
  );
}

export default ShopDashboard;
