/**
 * Org Admin - 兌換申請管理頁面
 *
 * 功能：
 * - 兌換申請列表展示（狀態標籤）
 * - 搜尋和篩選
 * - 兌換狀態操作（確認、準備、完成、取消）
 * - 兌換詳情檢視
 */

import { useState, useMemo } from 'react';
import {
  Search,
  Clock,
  CheckCircle,
  Package,
  XCircle,
  AlertTriangle,
  MoreVertical,
  Eye,
  Check,
  X,
  Copy,
  ChevronLeft,
  ChevronRight,
  User,
  Calendar,
  Ticket,
  RefreshCw,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import type { AdminOrder, OrderStatus } from '../../types/org-admin';
import { MOCK_ADMIN_ORDERS, getOrderStats, formatDateTime } from '../../data/mockData';

// ============================================
// Constants
// ============================================

const STATUS_CONFIG: Record<
  OrderStatus,
  { label: string; icon: typeof Clock; color: string; bgColor: string }
> = {
  pending: {
    label: '待處理',
    icon: Clock,
    color: 'text-tier-gold',
    bgColor: 'bg-tier-gold/10 border-tier-gold/30',
  },
  confirmed: {
    label: '已確認',
    icon: CheckCircle,
    color: 'text-tiffany-600',
    bgColor: 'bg-tiffany-50 border-tiffany-200',
  },
  ready: {
    label: '可領取',
    icon: Package,
    color: 'text-accent-mint',
    bgColor: 'bg-accent-mint/10 border-accent-mint/30',
  },
  completed: {
    label: '已領取',
    icon: Check,
    color: 'text-text-muted',
    bgColor: 'bg-surface-elevated border-surface-border',
  },
  cancelled: {
    label: '已取消',
    icon: XCircle,
    color: 'text-accent-coral',
    bgColor: 'bg-accent-coral/10 border-accent-coral/30',
  },
  expired: {
    label: '已過期',
    icon: AlertTriangle,
    color: 'text-text-muted',
    bgColor: 'bg-surface-hover border-surface-border',
  },
};

const STATUS_TABS: { key: OrderStatus | 'all'; label: string }[] = [
  { key: 'all', label: '全部' },
  { key: 'pending', label: '待處理' },
  { key: 'confirmed', label: '已確認' },
  { key: 'ready', label: '可領取' },
  { key: 'completed', label: '已領取' },
  { key: 'cancelled', label: '已取消' },
];

const PAGE_SIZE = 10;

// ============================================
// Components
// ============================================

function StatsCards({ orders }: { orders: AdminOrder[] }) {
  const stats = getOrderStats(orders);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-6">
      <div className="card p-4 border-2 border-tier-gold/20">
        <div className="flex items-center gap-2 text-tier-gold text-sm mb-1">
          <Clock className="w-4 h-4" />
          待處理
        </div>
        <p className="text-2xl font-display text-tier-gold">{stats.pending}</p>
      </div>
      <div className="card p-4 border-2 border-tiffany-200">
        <div className="flex items-center gap-2 text-tiffany-600 text-sm mb-1">
          <CheckCircle className="w-4 h-4" />
          已確認
        </div>
        <p className="text-2xl font-display text-tiffany-600">{stats.confirmed}</p>
      </div>
      <div className="card p-4 border-2 border-accent-mint/20">
        <div className="flex items-center gap-2 text-accent-mint text-sm mb-1">
          <Package className="w-4 h-4" />
          可領取
        </div>
        <p className="text-2xl font-display text-accent-mint">{stats.ready}</p>
      </div>
      <div className="card p-4">
        <div className="flex items-center gap-2 text-text-muted text-sm mb-1">
          <Check className="w-4 h-4" />
          已領取
        </div>
        <p className="text-2xl font-display text-text-secondary">{stats.completed}</p>
      </div>
      <div className="card p-4">
        <div className="flex items-center gap-2 text-accent-coral text-sm mb-1">
          <XCircle className="w-4 h-4" />
          已取消
        </div>
        <p className="text-2xl font-display text-accent-coral">{stats.cancelled}</p>
      </div>
      <div className="card p-4">
        <div className="flex items-center gap-2 text-text-muted text-sm mb-1">
          <AlertTriangle className="w-4 h-4" />
          已過期
        </div>
        <p className="text-2xl font-display text-text-muted">{stats.expired}</p>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const config = STATUS_CONFIG[status];
  const Icon = config.icon;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-display border',
        config.bgColor,
        config.color
      )}
    >
      <Icon className="w-3 h-3" />
      {config.label}
    </span>
  );
}

function OrderCard({
  order,
  onConfirm,
  onReady,
  onComplete,
  onCancel,
  onViewDetail,
}: {
  order: AdminOrder;
  onConfirm: () => void;
  onReady: () => void;
  onComplete: () => void;
  onCancel: () => void;
  onViewDetail: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopyCode = async () => {
    if (order.redemptionCode) {
      await navigator.clipboard.writeText(order.redemptionCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="card p-4 hover:shadow-md transition-shadow">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          {/* 學生頭像 */}
          <div className="w-12 h-12 rounded-xl bg-surface-elevated flex items-center justify-center text-2xl border border-surface-border">
            {order.studentAvatar || '👤'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <p className="font-display text-text-primary">{order.studentName}</p>
              {order.className && (
                <span className="px-2 py-0.5 bg-surface-elevated text-text-muted text-xs rounded">
                  {order.className}
                </span>
              )}
            </div>
            <p className="text-xs text-text-muted">{order.orderNumber}</p>
          </div>
        </div>
        <StatusBadge status={order.status} />
      </div>

      {/* 獎品資訊 */}
      <div className="flex items-center gap-3 p-3 bg-surface-elevated rounded-xl mb-3">
        <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
          {order.itemSnapshot.emoji || '🎁'}
        </div>
        <div className="flex-1">
          <p className="font-display text-text-primary text-sm">
            {order.itemSnapshot.name}
          </p>
          <div className="flex items-center gap-2 text-xs text-text-muted">
            <span>數量: {order.quantity}</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              {order.itemSnapshot.currency === 'coins' ? '🪙' : '⚡'}
              {order.totalPrice}
            </span>
          </div>
        </div>
      </div>

      {/* 兌換碼 (如果有) */}
      {order.redemptionCode && (
        <div className="flex items-center justify-between p-2 bg-tier-gold/5 rounded-lg border border-tier-gold/20 mb-3">
          <div className="flex items-center gap-2">
            <Ticket className="w-4 h-4 text-tier-gold" />
            <code className="font-mono text-sm text-tier-gold font-bold">
              {order.redemptionCode}
            </code>
          </div>
          <button
            onClick={handleCopyCode}
            className={cn(
              'p-1.5 rounded-lg transition-colors',
              copied ? 'bg-accent-mint text-white' : 'hover:bg-tier-gold/10 text-tier-gold'
            )}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      )}

      {/* 時間資訊 */}
      <div className="flex items-center gap-4 text-xs text-text-muted mb-3">
        <span className="flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          {formatDateTime(order.createdAt)}
        </span>
        {order.expiresAt && order.status === 'ready' && (
          <span className="flex items-center gap-1 text-accent-coral">
            <AlertTriangle className="w-3 h-3" />
            {formatDateTime(order.expiresAt)} 前領取
          </span>
        )}
      </div>

      {/* 操作按鈕 */}
      <div className="flex items-center justify-end gap-2 pt-3 border-t border-surface-border">
        <button
          onClick={onViewDetail}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm text-text-secondary hover:bg-surface-hover transition-colors"
        >
          <Eye className="w-4 h-4" />
          詳情
        </button>

        {order.status === 'pending' && (
          <>
            <button
              onClick={onCancel}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm text-accent-coral hover:bg-accent-coral/10 transition-colors"
            >
              <X className="w-4 h-4" />
              拒絕
            </button>
            <button
              onClick={onConfirm}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm bg-tiffany-500 text-white hover:bg-tiffany-600 transition-colors"
            >
              <Check className="w-4 h-4" />
              確認
            </button>
          </>
        )}

        {order.status === 'confirmed' && (
          <>
            <button
              onClick={onCancel}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm text-accent-coral hover:bg-accent-coral/10 transition-colors"
            >
              取消退款
            </button>
            <button
              onClick={onReady}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm bg-accent-mint text-white hover:bg-accent-mint/90 transition-colors"
            >
              <Package className="w-4 h-4" />
              可領取
            </button>
          </>
        )}

        {order.status === 'ready' && (
          <>
            <button
              onClick={onCancel}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm text-accent-coral hover:bg-accent-coral/10 transition-colors"
            >
              取消退款
            </button>
            <button
              onClick={onComplete}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm bg-tiffany-500 text-white hover:bg-tiffany-600 transition-colors"
            >
              <Check className="w-4 h-4" />
              完成領取
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function OrderDetailModal({
  order,
  onClose,
  onConfirm,
  onReady,
  onComplete,
  onCancel,
}: {
  order: AdminOrder;
  onClose: () => void;
  onConfirm: () => void;
  onReady: () => void;
  onComplete: () => void;
  onCancel: () => void;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopyCode = async () => {
    if (order.redemptionCode) {
      await navigator.clipboard.writeText(order.redemptionCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="card p-6 max-w-md w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-display text-text-primary">兌換詳情</h3>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-surface-hover transition-colors"
          >
            <X className="w-5 h-5 text-text-muted" />
          </button>
        </div>

        {/* 訂單編號和狀態 */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-text-muted font-mono">{order.orderNumber}</p>
          <StatusBadge status={order.status} />
        </div>

        {/* 學生資訊 */}
        <div className="p-4 bg-surface-elevated rounded-xl mb-4">
          <p className="text-xs text-text-muted mb-2">學生資訊</p>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-surface-bg flex items-center justify-center text-2xl">
              {order.studentAvatar || '👤'}
            </div>
            <div>
              <p className="font-display text-text-primary">{order.studentName}</p>
              {order.className && (
                <p className="text-sm text-text-muted">{order.className}</p>
              )}
            </div>
          </div>
        </div>

        {/* 獎品資訊 */}
        <div className="p-4 bg-surface-elevated rounded-xl mb-4">
          <p className="text-xs text-text-muted mb-2">獎品資訊</p>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-surface-bg flex items-center justify-center text-2xl">
              {order.itemSnapshot.emoji || '🎁'}
            </div>
            <div className="flex-1">
              <p className="font-display text-text-primary">
                {order.itemSnapshot.name}
              </p>
              <div className="flex items-center gap-3 text-sm text-text-muted">
                <span>數量: {order.quantity}</span>
                <span className="flex items-center gap-1">
                  {order.itemSnapshot.currency === 'coins' ? '🪙' : '⚡'}
                  {order.totalPrice}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 兌換碼 */}
        {order.redemptionCode && (
          <div className="p-4 bg-tier-gold/5 rounded-xl border border-tier-gold/20 mb-4">
            <p className="text-xs text-text-muted mb-2">兌換碼</p>
            <div className="flex items-center justify-between">
              <code className="text-xl font-mono font-bold text-tier-gold">
                {order.redemptionCode}
              </code>
              <button
                onClick={handleCopyCode}
                className={cn(
                  'flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm transition-colors',
                  copied
                    ? 'bg-accent-mint text-white'
                    : 'bg-tier-gold/20 text-tier-gold hover:bg-tier-gold/30'
                )}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? '已複製' : '複製'}
              </button>
            </div>
            {order.expiresAt && (
              <p className="text-xs text-accent-coral mt-2">
                有效期限: {formatDateTime(order.expiresAt)}
              </p>
            )}
          </div>
        )}

        {/* 時間軸 */}
        <div className="p-4 bg-surface-elevated rounded-xl mb-4">
          <p className="text-xs text-text-muted mb-3">兌換時間軸</p>
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 rounded-full bg-tiffany-500" />
              <span className="text-text-muted">下單</span>
              <span className="ml-auto text-text-secondary">
                {formatDateTime(order.createdAt)}
              </span>
            </div>
            {order.confirmedAt && (
              <div className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 rounded-full bg-accent-mint" />
                <span className="text-text-muted">確認</span>
                <span className="ml-auto text-text-secondary">
                  {formatDateTime(order.confirmedAt)}
                </span>
              </div>
            )}
            {order.completedAt && (
              <div className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 rounded-full bg-text-muted" />
                <span className="text-text-muted">完成</span>
                <span className="ml-auto text-text-secondary">
                  {formatDateTime(order.completedAt)}
                </span>
              </div>
            )}
            {order.cancelledAt && (
              <div className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 rounded-full bg-accent-coral" />
                <span className="text-text-muted">取消</span>
                <span className="ml-auto text-text-secondary">
                  {formatDateTime(order.cancelledAt)}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* 取消原因 */}
        {order.cancelReason && (
          <div className="p-4 bg-accent-coral/5 rounded-xl border border-accent-coral/20 mb-4">
            <p className="text-xs text-text-muted mb-1">取消原因</p>
            <p className="text-sm text-accent-coral">{order.cancelReason}</p>
          </div>
        )}

        {/* 操作按鈕 */}
        <div className="flex gap-3 pt-4 border-t border-surface-border">
          {order.status === 'pending' && (
            <>
              <button
                onClick={onCancel}
                className="flex-1 py-2.5 rounded-xl border border-accent-coral text-accent-coral hover:bg-accent-coral/10 transition-colors font-display"
              >
                拒絕申請
              </button>
              <button
                onClick={onConfirm}
                className="flex-1 py-2.5 rounded-xl bg-tiffany-500 text-white hover:bg-tiffany-600 transition-colors font-display"
              >
                確認兌換
              </button>
            </>
          )}
          {order.status === 'confirmed' && (
            <>
              <button
                onClick={onCancel}
                className="flex-1 py-2.5 rounded-xl border border-accent-coral text-accent-coral hover:bg-accent-coral/10 transition-colors font-display"
              >
                取消退款
              </button>
              <button
                onClick={onReady}
                className="flex-1 py-2.5 rounded-xl bg-accent-mint text-white hover:bg-accent-mint/90 transition-colors font-display"
              >
                標記可領取
              </button>
            </>
          )}
          {order.status === 'ready' && (
            <>
              <button
                onClick={onCancel}
                className="flex-1 py-2.5 rounded-xl border border-accent-coral text-accent-coral hover:bg-accent-coral/10 transition-colors font-display"
              >
                取消退款
              </button>
              <button
                onClick={onComplete}
                className="flex-1 py-2.5 rounded-xl bg-tiffany-500 text-white hover:bg-tiffany-600 transition-colors font-display"
              >
                完成領取
              </button>
            </>
          )}
          {(order.status === 'completed' ||
            order.status === 'cancelled' ||
            order.status === 'expired') && (
            <button
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-surface-hover text-text-secondary hover:bg-surface-elevated transition-colors font-display"
            >
              關閉
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function Pagination({
  currentPage,
  totalPages,
  onPageChange,
}: {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-2 mt-4">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={cn(
          'p-2 rounded-lg transition-colors',
          currentPage === 1
            ? 'text-text-muted cursor-not-allowed'
            : 'text-text-secondary hover:bg-surface-hover'
        )}
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
        <button
          key={page}
          onClick={() => onPageChange(page)}
          className={cn(
            'w-10 h-10 rounded-lg font-display transition-colors',
            page === currentPage
              ? 'bg-tiffany-500 text-white'
              : 'text-text-secondary hover:bg-surface-hover'
          )}
        >
          {page}
        </button>
      ))}

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={cn(
          'p-2 rounded-lg transition-colors',
          currentPage === totalPages
            ? 'text-text-muted cursor-not-allowed'
            : 'text-text-secondary hover:bg-surface-hover'
        )}
      >
        <ChevronRight className="w-5 h-5" />
      </button>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

export function OrdersListPage() {
  const [orders, setOrders] = useState<AdminOrder[]>(MOCK_ADMIN_ORDERS);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState<AdminOrder | null>(null);

  // 篩選訂單
  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      // 搜尋
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        if (
          !order.studentName.toLowerCase().includes(query) &&
          !order.orderNumber.toLowerCase().includes(query) &&
          !order.itemSnapshot.name.toLowerCase().includes(query)
        ) {
          return false;
        }
      }

      // 狀態篩選
      if (statusFilter !== 'all' && order.status !== statusFilter) {
        return false;
      }

      return true;
    });
  }, [orders, searchQuery, statusFilter]);

  // 分頁
  const totalPages = Math.ceil(filteredOrders.length / PAGE_SIZE);
  const paginatedOrders = filteredOrders.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  // 訂單操作
  const handleConfirm = (orderId: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'confirmed' as OrderStatus,
              confirmedAt: new Date().toISOString(),
              confirmedBy: 'admin-001',
              updatedAt: new Date().toISOString(),
            }
          : o
      )
    );
    setSelectedOrder(null);
  };

  const handleReady = (orderId: string) => {
    const redemptionCode = `${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'ready' as OrderStatus,
              redemptionCode,
              expiresAt: expiresAt.toISOString(),
              updatedAt: new Date().toISOString(),
            }
          : o
      )
    );
    setSelectedOrder(null);
  };

  const handleComplete = (orderId: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'completed' as OrderStatus,
              completedAt: new Date().toISOString(),
              completedBy: 'admin-001',
              updatedAt: new Date().toISOString(),
            }
          : o
      )
    );
    setSelectedOrder(null);
  };

  const handleCancel = (orderId: string) => {
    if (confirm('確定要取消此兌換並退還金幣嗎？')) {
      setOrders((prev) =>
        prev.map((o) =>
          o.id === orderId
            ? {
                ...o,
                status: 'cancelled' as OrderStatus,
                cancelledAt: new Date().toISOString(),
                cancelledBy: 'admin-001',
                cancelReason: '管理員取消，已退還金幣',
                updatedAt: new Date().toISOString(),
              }
            : o
        )
      );
      setSelectedOrder(null);
    }
  };

  // 重置頁碼當篩選改變
  const handleFilterChange = (filter: OrderStatus | 'all') => {
    setStatusFilter(filter);
    setCurrentPage(1);
  };

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-display text-text-primary">兌換管理</h1>
            <p className="text-sm text-text-muted">處理學生的獎品兌換申請</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl border border-surface-border text-text-secondary hover:bg-surface-hover transition-colors">
            <RefreshCw className="w-4 h-4" />
            重新整理
          </button>
        </div>

        {/* Stats */}
        <StatsCards orders={orders} />

        {/* Filters */}
        <div className="card p-4 mb-4">
          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
            <input
              type="text"
              placeholder="搜尋學生姓名、兌換編號..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-surface-border bg-surface-bg focus:outline-none focus:border-tiffany-500 transition-colors"
            />
          </div>

          {/* Status Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {STATUS_TABS.map((tab) => {
              const count =
                tab.key === 'all'
                  ? orders.length
                  : orders.filter((o) => o.status === tab.key).length;

              return (
                <button
                  key={tab.key}
                  onClick={() => handleFilterChange(tab.key)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-xl font-display text-sm whitespace-nowrap transition-all',
                    statusFilter === tab.key
                      ? 'bg-tiffany-500 text-white'
                      : 'bg-surface-elevated text-text-secondary hover:bg-surface-hover'
                  )}
                >
                  {tab.label}
                  <span
                    className={cn(
                      'px-1.5 py-0.5 rounded-full text-xs',
                      statusFilter === tab.key ? 'bg-white/20' : 'bg-surface-hover'
                    )}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Orders Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {paginatedOrders.map((order) => (
            <OrderCard
              key={order.id}
              order={order}
              onConfirm={() => handleConfirm(order.id)}
              onReady={() => handleReady(order.id)}
              onComplete={() => handleComplete(order.id)}
              onCancel={() => handleCancel(order.id)}
              onViewDetail={() => setSelectedOrder(order)}
            />
          ))}
        </div>

        {/* Empty State */}
        {paginatedOrders.length === 0 && (
          <div className="card py-12 text-center">
            <Package className="w-12 h-12 text-text-muted mx-auto mb-3" />
            <p className="text-text-muted font-display">沒有符合條件的兌換申請</p>
          </div>
        )}

        {/* Pagination */}
        <div className="mt-4 flex items-center justify-between text-sm text-text-muted">
          <span>
            顯示 {(currentPage - 1) * PAGE_SIZE + 1} -{' '}
            {Math.min(currentPage * PAGE_SIZE, filteredOrders.length)} 共{' '}
            {filteredOrders.length} 筆
          </span>
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        </div>
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          onConfirm={() => handleConfirm(selectedOrder.id)}
          onReady={() => handleReady(selectedOrder.id)}
          onComplete={() => handleComplete(selectedOrder.id)}
          onCancel={() => handleCancel(selectedOrder.id)}
        />
      )}
    </div>
  );
}

export default OrdersListPage;
