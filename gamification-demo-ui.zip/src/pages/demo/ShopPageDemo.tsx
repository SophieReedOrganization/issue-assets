/**
 * Shop Page - 2026 Warm Cream Theme
 *
 * Design System: Warm Cream + Friendly + Playful
 * - Light backgrounds with soft shadows
 * - Colorful category badges
 * - Warm accent colors
 */

import { useState } from "react";
import {
  ShoppingBag,
  X,
  Gift,
  Star,
  Lock,
  Package,
  ChevronDown,
  Check,
  Copy,
  Sparkles,
  Tag,
  Ticket,
  Store,
  Building2,
  Zap,
  AlertCircle,
} from "lucide-react";
import { cn } from "../../lib/utils";
import type {
  Reward,
  OrganizationReward,
  ShopType,
  RedemptionState,
  PhysicalReward,
} from "../../types/gamification";
import {
  MOCK_USER_PROFILE,
  MOCK_VIRTUAL_REWARDS,
  MOCK_PHYSICAL_REWARDS,
  MOCK_ORG_REWARDS,
  MOCK_ORDERS,
  generateRedemptionCode,
  getStatusText,
} from "../../data/mockData";

// ============================================
// Types & Constants
// ============================================

type RewardCategory = "all" | "virtual" | "physical";

const SHOP_TABS: { key: ShopType; label: string; icon: typeof Store }[] = [
  { key: "platform", label: "平台商店", icon: Store },
  { key: "organization", label: "機構商店", icon: Building2 },
];

const CATEGORY_TABS: { key: RewardCategory; label: string; icon: typeof Tag }[] = [
  { key: "all", label: "全部", icon: ShoppingBag },
  { key: "virtual", label: "虛擬道具", icon: Sparkles },
  { key: "physical", label: "實體獎品", icon: Gift },
];

// ============================================
// Balance Header
// ============================================

function BalanceHeader({ coins, xp, level }: { coins: number; xp: number; level: number }) {
  return (
    <div className="card p-4 md:p-5 mb-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        {/* Currency Balances */}
        <div className="flex items-center gap-4">
          {/* Coins */}
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-tier-gold/10 border border-tier-gold/20">
            <span className="text-2xl">🪙</span>
            <div>
              <p className="text-xs text-text-secondary">金幣</p>
              <p className="text-xl font-display text-tier-gold">
                {coins.toLocaleString()}
              </p>
            </div>
          </div>

          {/* XP */}
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-tiffany-50 border border-tiffany-200">
            <Zap className="w-6 h-6 text-tiffany-600" />
            <div>
              <p className="text-xs text-text-secondary">經驗值</p>
              <p className="text-xl font-display text-tiffany-600">
                {xp.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        {/* Level Badge */}
        <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-tiffany-50 to-accent-cyan/10 rounded-xl border border-tiffany-200">
          <Sparkles className="w-4 h-4 text-tiffany-600" />
          <span className="font-display text-tiffany-600">Lv.{level}</span>
        </div>
      </div>

      {/* Currency Usage Hint */}
      <div className="mt-3 pt-3 border-t border-surface-border flex flex-wrap gap-4 text-xs text-text-muted">
        <span className="flex items-center gap-1">
          <span className="text-sm">🪙</span>
          金幣兌換實體獎品
        </span>
        <span className="flex items-center gap-1">
          <Zap className="w-3.5 h-3.5 text-tiffany-600" />
          經驗值兌換虛擬道具
        </span>
      </div>
    </div>
  );
}

// ============================================
// Pending Orders Banner
// ============================================

function PendingOrdersBanner() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const pendingOrders = MOCK_ORDERS.filter(
    (o) => o.status === "ready" || o.status === "pending"
  );

  if (pendingOrders.length === 0) return null;

  const handleCopyCode = async (code: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="card border-2 border-tier-gold/30 overflow-hidden mb-4 bg-gradient-to-br from-tier-gold-bg to-surface-elevated">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-tier-gold/5 transition-colors cursor-pointer"
      >
        <Package className="w-5 h-5 text-tier-gold" />
        <span className="flex-1 text-left font-display text-tier-gold">
          待領取訂單
        </span>
        <span className="px-2 py-1 bg-accent-pink text-white text-xs font-bold rounded-full shadow-pink">
          {pendingOrders.length}
        </span>
        <ChevronDown
          className={cn(
            "w-5 h-5 text-tier-gold transition-transform",
            isExpanded && "rotate-180"
          )}
        />
      </button>

      {isExpanded && (
        <div className="border-t border-tier-gold/20 divide-y divide-warm-border">
          {pendingOrders.map((order) => (
            <div
              key={order.id}
              className="px-4 py-3 flex items-center gap-3 bg-white/50"
            >
              <div className="w-10 h-10 rounded-xl bg-tier-gold/10 flex items-center justify-center text-xl">
                {order.rewardEmoji}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-text-primary truncate">
                  {order.rewardName}
                </p>
                <p className="text-xs text-text-muted">
                  {getStatusText(order.status)}
                </p>
              </div>
              {order.redemptionCode && (
                <button
                  onClick={(e) => handleCopyCode(order.redemptionCode!, e)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-tier-gold/10 rounded-lg text-xs font-mono text-tier-gold hover:bg-tier-gold/20 transition-colors cursor-pointer"
                >
                  {order.redemptionCode}
                  {copiedCode === order.redemptionCode ? (
                    <Check className="w-3.5 h-3.5 text-accent-mint" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================
// Shop Tabs
// ============================================

function ShopTabs({
  activeShop,
  onSelect,
}: {
  activeShop: ShopType;
  onSelect: (shop: ShopType) => void;
}) {
  return (
    <div className="flex gap-2 mb-4">
      {SHOP_TABS.map((tab) => {
        const Icon = tab.icon;
        return (
          <button
            key={tab.key}
            onClick={() => onSelect(tab.key)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-xl font-display text-sm",
              "border-2 transition-all duration-300 cursor-pointer",
              activeShop === tab.key
                ? "bg-gradient-to-r from-tiffany-500 to-accent-cyan text-white border-transparent shadow-teal"
                : "bg-white text-text-secondary border-surface-border hover:border-tiffany-500/30 hover:text-text-primary"
            )}
          >
            <Icon className="w-4 h-4" />
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}

// ============================================
// Category Tabs
// ============================================

function CategoryTabs({
  selected,
  onSelect,
}: {
  selected: RewardCategory;
  onSelect: (cat: RewardCategory) => void;
}) {
  return (
    <div className="flex gap-2 mb-4 overflow-x-auto pb-2 hide-scrollbar">
      {CATEGORY_TABS.map((tab) => {
        const Icon = tab.icon;
        return (
          <button
            key={tab.key}
            onClick={() => onSelect(tab.key)}
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-xl font-display text-sm whitespace-nowrap",
              "border transition-all duration-200 cursor-pointer",
              selected === tab.key
                ? "bg-tiffany-50 text-tiffany-600 border-tiffany-500/30"
                : "bg-white text-text-muted border-surface-border hover:text-text-secondary hover:border-tiffany-200"
            )}
          >
            <Icon className="w-4 h-4" />
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}

// ============================================
// Reward Card
// ============================================

function RewardCard({
  reward,
  userCoins,
  userXp,
  userLevel,
  onSelect,
}: {
  reward: Reward | OrganizationReward;
  userCoins: number;
  userXp: number;
  userLevel: number;
  onSelect: () => void;
}) {
  const isXpCurrency = reward.currency === "xp";
  const balance = isXpCurrency ? userXp : userCoins;
  const affordable = balance >= reward.price;
  const requiredLevel = reward.requiredLevel || 1;
  const meetsLevelReq = userLevel >= requiredLevel;
  const canPurchase = affordable && meetsLevelReq && reward.stock > 0;
  const isVirtual = reward.type === "virtual";
  const lowStock = reward.stock <= 5 && reward.stock > 0;

  const isOrgReward = "organizationId" in reward;
  const isPrivilege = isOrgReward && (reward as OrganizationReward).category === "privilege";

  // Get card accent config
  const getAccentConfig = () => {
    if (isPrivilege) return { color: "accent-pink", bg: "bg-accent-pink/10", border: "border-accent-pink/30", text: "text-accent-pink" };
    if (isOrgReward) return { color: "accent-mint", bg: "bg-accent-mint/10", border: "border-accent-mint/30", text: "text-accent-mint" };
    if (isVirtual) return { color: "tiffany", bg: "bg-tiffany-50", border: "border-tiffany-500/30", text: "text-tiffany-600" };
    return { color: "tier-gold", bg: "bg-tier-gold/10", border: "border-tier-gold/30", text: "text-tier-gold" };
  };

  const accent = getAccentConfig();

  return (
    <button
      onClick={onSelect}
      disabled={reward.stock === 0}
      className={cn(
        "relative p-4 rounded-2xl transition-all duration-300 cursor-pointer text-left w-full group",
        "border-2 hover:-translate-y-2 active:translate-y-0",
        reward.stock === 0
          ? "bg-surface-elevated border-surface-border opacity-60"
          : "card card-hover"
      )}
    >
      {/* Type Badge */}
      <div
        className={cn(
          "absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-display",
          accent.bg, accent.text, accent.border, "border"
        )}
      >
        {isPrivilege ? (
          <Ticket className="w-3 h-3" />
        ) : isOrgReward ? (
          <Building2 className="w-3 h-3" />
        ) : isVirtual ? (
          <Sparkles className="w-3 h-3" />
        ) : (
          <Gift className="w-3 h-3" />
        )}
        <span className="hidden sm:inline">
          {isPrivilege ? "特權" : isOrgReward ? "機構" : isVirtual ? "虛擬" : "實體"}
        </span>
      </div>

      {/* Level Requirement / Stock Warning */}
      {requiredLevel > 1 && (
        <div
          className={cn(
            "absolute top-2 right-2 flex items-center gap-0.5 px-2 py-1 rounded-lg text-[10px] font-display",
            meetsLevelReq
              ? "bg-accent-mint/10 text-accent-mint border border-accent-mint/30"
              : "bg-surface-hover text-text-muted border border-surface-border"
          )}
        >
          {!meetsLevelReq && <Lock className="w-3 h-3" />}
          Lv.{requiredLevel}
        </div>
      )}

      {lowStock && requiredLevel <= 1 && (
        <div className="absolute top-2 right-2 flex items-center gap-0.5 px-2 py-1 rounded-lg text-[10px] font-display bg-accent-coral/10 text-accent-coral border border-accent-coral/30">
          <AlertCircle className="w-3 h-3" />
          剩 {reward.stock}
        </div>
      )}

      {/* Item Icon/Emoji */}
      <div className="w-16 h-16 mx-auto mb-3 mt-4 rounded-xl bg-surface-elevated flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden">
        {reward.imageUrl ? (
          <img
            src={reward.imageUrl}
            alt={reward.name}
            className={cn(
              "w-full h-full object-cover",
              !meetsLevelReq && "grayscale opacity-50"
            )}
          />
        ) : reward.emoji ? (
          <span className={cn(
            "text-4xl",
            !meetsLevelReq && "grayscale opacity-50"
          )}>
            {reward.emoji}
          </span>
        ) : (
          <div className="w-12 h-12 rounded-lg bg-surface-hover flex items-center justify-center">
            {isVirtual ? (
              <Sparkles className="w-6 h-6 text-text-muted" />
            ) : (
              <Gift className="w-6 h-6 text-text-muted" />
            )}
          </div>
        )}
      </div>

      {/* Item Name */}
      <p className="text-sm font-display text-center text-text-primary line-clamp-1">
        {reward.name}
      </p>
      {reward.description && (
        <p className="text-[10px] text-text-muted text-center line-clamp-1 mt-0.5">
          {reward.description}
        </p>
      )}

      {/* Price Button */}
      <div
        className={cn(
          "mt-3 py-2 px-3 rounded-xl text-center text-sm font-display transition-all",
          reward.stock === 0
            ? "bg-surface-hover text-text-muted"
            : !meetsLevelReq
              ? "bg-surface-hover text-text-muted"
              : canPurchase
                ? cn(
                    "bg-gradient-to-r text-white shadow-sm",
                    isPrivilege
                      ? "from-accent-pink to-tiffany-500"
                      : isOrgReward
                        ? "from-accent-mint to-accent-blue"
                        : isVirtual
                          ? "from-tiffany-500 to-accent-cyan"
                          : "from-tier-gold to-accent-orange"
                  )
                : "bg-surface-hover text-text-muted"
        )}
      >
        {reward.stock === 0 ? (
          "已售完"
        ) : !meetsLevelReq ? (
          <span className="flex items-center justify-center gap-1">
            <Lock className="w-3 h-3" />
            需 Lv.{requiredLevel}
          </span>
        ) : (
          <span className="flex items-center justify-center gap-1">
            {isXpCurrency ? (
              <Zap className="w-4 h-4" />
            ) : (
              <span className="text-sm">🪙</span>
            )}
            {reward.price.toLocaleString()}
            {isXpCurrency ? " XP" : ""}
          </span>
        )}
      </div>
    </button>
  );
}

// ============================================
// Confirm Modal
// ============================================

function ConfirmModal({
  reward,
  userCoins,
  userXp,
  userLevel,
  isProcessing,
  onConfirm,
  onCancel,
}: {
  reward: Reward | OrganizationReward;
  userCoins: number;
  userXp: number;
  userLevel: number;
  isProcessing: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const isXpCurrency = reward.currency === "xp";
  const balance = isXpCurrency ? userXp : userCoins;
  const canAfford = balance >= reward.price;
  const requiredLevel = reward.requiredLevel || 1;
  const meetsLevelReq = userLevel >= requiredLevel;
  const canPurchase = canAfford && meetsLevelReq;
  const isPhysical = reward.type === "physical";
  const currencyLabel = isXpCurrency ? "經驗值" : "金幣";

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onCancel}
    >
      <div
        className="card p-6 md:p-8 max-w-sm w-full animate-scale-in relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onCancel}
          disabled={isProcessing}
          className="absolute top-4 right-4 w-10 h-10 rounded-xl bg-surface-elevated flex items-center justify-center hover:bg-surface-hover transition-colors cursor-pointer disabled:opacity-50"
        >
          <X className="w-5 h-5 text-text-secondary" />
        </button>

        <h3 className="text-xl font-display text-center text-text-primary mb-6">
          {isPhysical ? "確認兌換" : "確認購買"}
        </h3>

        {/* Item Preview */}
        <div className="w-24 h-24 mx-auto mb-4 rounded-2xl bg-surface-elevated border-2 border-tiffany-200 flex items-center justify-center text-5xl overflow-hidden">
          {reward.imageUrl ? (
            <img src={reward.imageUrl} alt={reward.name} className="w-full h-full object-cover" />
          ) : reward.emoji ? (
            reward.emoji
          ) : (
            <Gift className="w-10 h-10 text-text-muted" />
          )}
        </div>

        <p className="text-lg font-display text-center text-text-primary mb-1">
          {reward.name}
        </p>
        {reward.description && (
          <p className="text-sm text-text-secondary text-center mb-4">{reward.description}</p>
        )}

        {/* Level Warning */}
        {!meetsLevelReq && (
          <div className="bg-tiffany-50 border border-tiffany-200 rounded-xl p-3 mb-4 flex items-center gap-2">
            <Lock className="w-5 h-5 text-tiffany-600" />
            <div>
              <p className="text-sm font-medium text-tiffany-600">
                需要達到 Lv.{requiredLevel}
              </p>
              <p className="text-xs text-text-secondary">你目前是 Lv.{userLevel}</p>
            </div>
          </div>
        )}

        {/* Price Info */}
        <div className="bg-surface-elevated rounded-xl p-4 mb-4 space-y-2 border border-surface-border">
          <div className="flex justify-between text-sm text-text-secondary">
            <span>商品價格</span>
            <span className="flex items-center gap-1 font-display text-text-primary">
              {isXpCurrency ? (
                <Zap className="w-4 h-4 text-tiffany-600" />
              ) : (
                <span>🪙</span>
              )}
              {reward.price.toLocaleString()} {isXpCurrency ? "XP" : ""}
            </span>
          </div>
          <div className="flex justify-between text-sm text-text-secondary">
            <span>你的{currencyLabel}</span>
            <span className="font-display text-text-primary">{balance.toLocaleString()}</span>
          </div>
          <div className="border-t border-surface-border pt-2 flex justify-between font-display">
            <span className="text-text-secondary">兌換後餘額</span>
            <span className={canAfford ? "text-accent-mint" : "text-accent-coral"}>
              {(balance - reward.price).toLocaleString()}
            </span>
          </div>
        </div>

        {isPhysical && (
          <p className="text-xs text-text-muted text-center mb-4">
            兌換後無法退還，請確認後再兌換
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            disabled={isProcessing}
            className="flex-1 btn-teal btn-teal-secondary py-3"
          >
            取消
          </button>
          <button
            onClick={onConfirm}
            disabled={!canPurchase || isProcessing}
            className={cn(
              "flex-1 btn-teal py-3",
              (!canPurchase || isProcessing) && "opacity-50 cursor-not-allowed"
            )}
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                處理中
              </span>
            ) : !meetsLevelReq ? (
              <span className="flex items-center gap-1">
                <Lock className="w-4 h-4" />
                等級不足
              </span>
            ) : canAfford ? (
              "確認"
            ) : (
              `${currencyLabel}不足`
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Success Modal
// ============================================

function SuccessModal({
  reward,
  redemptionCode,
  onClose,
}: {
  reward: Reward | OrganizationReward;
  redemptionCode: string;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const isPhysical = reward.type === "physical";

  const handleCopy = async () => {
    await navigator.clipboard.writeText(redemptionCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="card p-6 md:p-8 max-w-sm w-full animate-bounce-in text-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Success Icon */}
        <div className="w-20 h-20 mx-auto mb-4 bg-accent-mint rounded-full flex items-center justify-center shadow-sm">
          <Check className="w-10 h-10 text-white" strokeWidth={3} />
        </div>

        <h3 className="text-2xl font-display text-text-primary mb-2">
          兌換成功！
        </h3>

        <div className="w-16 h-16 mx-auto my-4 rounded-xl bg-surface-elevated border-2 border-tiffany-200 flex items-center justify-center text-4xl overflow-hidden">
          {reward.imageUrl ? (
            <img src={reward.imageUrl} alt={reward.name} className="w-full h-full object-cover" />
          ) : reward.emoji ? (
            reward.emoji
          ) : (
            <Gift className="w-8 h-8 text-text-muted" />
          )}
        </div>

        <p className="text-lg font-display text-text-primary mb-4">
          {reward.name}
        </p>

        {isPhysical && redemptionCode && (
          <>
            <p className="text-text-secondary text-sm mb-3">請憑以下兌換碼領取獎品</p>

            <div className="bg-tier-gold-bg rounded-xl p-4 mb-4 border-2 border-tier-gold/30">
              <p className="text-xs text-text-muted mb-2">兌換碼</p>
              <div className="flex items-center justify-center gap-2">
                <code className="text-xl font-mono font-bold text-tier-gold tracking-wider">
                  {redemptionCode}
                </code>
                <button
                  onClick={handleCopy}
                  className={cn(
                    "p-2 rounded-lg transition-colors cursor-pointer",
                    copied ? "bg-accent-mint text-white" : "bg-tier-gold/20 text-tier-gold hover:bg-tier-gold/30"
                  )}
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="bg-surface-elevated rounded-xl p-3 mb-4 text-left border border-surface-border">
              <p className="text-xs text-text-muted mb-1">領取說明</p>
              <p className="text-sm text-text-secondary">
                {(reward as PhysicalReward).redemptionInstructions ||
                  "請至櫃檯出示兌換碼領取"}
              </p>
            </div>
          </>
        )}

        {!isPhysical && (
          <p className="text-text-secondary mb-6">已自動套用到你的帳號</p>
        )}

        <button onClick={onClose} className="w-full btn-teal">
          <Star className="w-4 h-4" />
          太棒了！
        </button>
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

export function ShopPageDemo() {
  const [activeShop, setActiveShop] = useState<ShopType>("platform");
  const [selectedCategory, setSelectedCategory] = useState<RewardCategory>("all");
  const [coins, setCoins] = useState(MOCK_USER_PROFILE.coins);
  const [xp, setXp] = useState(MOCK_USER_PROFILE.totalXp);
  const userLevel = MOCK_USER_PROFILE.level;

  const [redemptionState, setRedemptionState] = useState<RedemptionState>({
    isConfirming: false,
    isProcessing: false,
    isSuccess: false,
    selectedReward: null,
  });

  // Filter items
  const platformItems = [
    ...(selectedCategory === "all" || selectedCategory === "virtual"
      ? MOCK_VIRTUAL_REWARDS
      : []),
    ...(selectedCategory === "all" || selectedCategory === "physical"
      ? MOCK_PHYSICAL_REWARDS
      : []),
  ];

  const orgItems = MOCK_ORG_REWARDS;
  const displayItems = activeShop === "platform" ? platformItems : orgItems;

  const handleSelectReward = (reward: Reward | OrganizationReward) => {
    setRedemptionState({
      isConfirming: true,
      isProcessing: false,
      isSuccess: false,
      selectedReward: reward,
    });
  };

  const handleConfirm = async () => {
    if (!redemptionState.selectedReward) return;

    setRedemptionState((prev) => ({ ...prev, isProcessing: true }));
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const code = generateRedemptionCode();
    const reward = redemptionState.selectedReward;

    if (reward.currency === "xp") {
      setXp((prev) => prev - reward.price);
    } else {
      setCoins((prev) => prev - reward.price);
    }

    setRedemptionState((prev) => ({
      ...prev,
      isProcessing: false,
      isConfirming: false,
      isSuccess: true,
      redemptionCode: code,
    }));
  };

  const handleCancel = () => {
    setRedemptionState({
      isConfirming: false,
      isProcessing: false,
      isSuccess: false,
      selectedReward: null,
    });
  };

  const handleCloseSuccess = () => {
    setRedemptionState({
      isConfirming: false,
      isProcessing: false,
      isSuccess: false,
      selectedReward: null,
    });
  };

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="container-app py-4 md:py-6">
        {/* Balance Header */}
        <BalanceHeader coins={coins} xp={xp} level={userLevel} />

        {/* Pending Orders */}
        <PendingOrdersBanner />

        {/* Shop Tabs */}
        <ShopTabs activeShop={activeShop} onSelect={setActiveShop} />

        {/* Category Tabs (Platform only) */}
        {activeShop === "platform" && (
          <CategoryTabs selected={selectedCategory} onSelect={setSelectedCategory} />
        )}

        {/* Items Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4 stagger-children">
          {displayItems.map((item, index) => (
            <div
              key={item.id}
              className="animate-fade-in-up"
              style={{ animationDelay: `${index * 30}ms` }}
            >
              <RewardCard
                reward={item}
                userCoins={coins}
                userXp={xp}
                userLevel={userLevel}
                onSelect={() => handleSelectReward(item)}
              />
            </div>
          ))}
        </div>

        {/* Empty State */}
        {displayItems.length === 0 && (
          <div className="text-center py-12">
            <ShoppingBag className="w-16 h-16 text-text-muted mx-auto mb-4" />
            <p className="text-text-muted font-display">目前沒有商品</p>
          </div>
        )}
      </div>

      {/* Confirmation Modal */}
      {redemptionState.isConfirming && redemptionState.selectedReward && (
        <ConfirmModal
          reward={redemptionState.selectedReward}
          userCoins={coins}
          userXp={xp}
          userLevel={userLevel}
          isProcessing={redemptionState.isProcessing}
          onConfirm={handleConfirm}
          onCancel={handleCancel}
        />
      )}

      {/* Success Modal */}
      {redemptionState.isSuccess && redemptionState.selectedReward && (
        <SuccessModal
          reward={redemptionState.selectedReward}
          redemptionCode={redemptionState.redemptionCode || ""}
          onClose={handleCloseSuccess}
        />
      )}
    </div>
  );
}

export default ShopPageDemo;
