/**
 * Leaderboard Page - 2026 Warm Cream Theme
 *
 * Design System: Warm Cream + Friendly + Playful
 * - Light backgrounds with soft shadows
 * - Colorful podium with tier colors
 * - Warm accent colors and animations
 */

import { useState } from "react";
import {
  Trophy,
  TrendingUp,
  TrendingDown,
  Minus,
  Crown,
  Flame,
  Target,
  Zap,
  Star,
  Calendar,
  CalendarDays,
  Award,
  Sparkles,
  ChevronUp,
} from "lucide-react";
import { cn } from "../../lib/utils";

// ============================================
// Mock Data
// ============================================

const MOCK_CURRENT_STUDENT = "student_5";

interface LeaderboardStudent {
  position: number;
  student_id: string;
  student_name: string;
  value: number;
  change: number;
  avatar_emoji: string;
  streak: number;
  title: string;
  level: number;
}

const MOCK_LEADERBOARD: LeaderboardStudent[] = [
  { position: 1, student_id: "student_1", student_name: "小明", value: 2850, change: 2, avatar_emoji: "🦸", streak: 15, title: "學霸王者", level: 25 },
  { position: 2, student_id: "student_2", student_name: "小華", value: 2720, change: -1, avatar_emoji: "🧙", streak: 12, title: "知識達人", level: 23 },
  { position: 3, student_id: "student_3", student_name: "小芳", value: 2680, change: 1, avatar_emoji: "🦋", streak: 10, title: "勤學之星", level: 22 },
  { position: 4, student_id: "student_4", student_name: "小美", value: 2560, change: 0, avatar_emoji: "🌸", streak: 8, title: "學習高手", level: 21 },
  { position: 5, student_id: "student_5", student_name: "你", value: 2450, change: 3, avatar_emoji: "🚀", streak: 12, title: "知識探索家", level: 20 },
  { position: 6, student_id: "student_6", student_name: "小玲", value: 2380, change: -2, avatar_emoji: "🎀", streak: 5, title: "努力小將", level: 19 },
  { position: 7, student_id: "student_7", student_name: "小剛", value: 2250, change: 1, avatar_emoji: "⚡", streak: 7, title: "學習新星", level: 18 },
  { position: 8, student_id: "student_8", student_name: "小雲", value: 2150, change: -1, avatar_emoji: "☁️", streak: 3, title: "認真學員", level: 17 },
  { position: 9, student_id: "student_9", student_name: "小龍", value: 2050, change: 2, avatar_emoji: "🐲", streak: 6, title: "進步快手", level: 16 },
  { position: 10, student_id: "student_10", student_name: "小鳳", value: 1980, change: 0, avatar_emoji: "🦜", streak: 4, title: "學習種子", level: 15 },
];

type Period = "weekly" | "monthly" | "all_time";
type Metric = "xp" | "accuracy" | "streak";

const PERIOD_OPTIONS: { key: Period; label: string; icon: typeof Calendar }[] = [
  { key: "weekly", label: "本週", icon: Calendar },
  { key: "monthly", label: "本月", icon: CalendarDays },
  { key: "all_time", label: "全部", icon: Trophy },
];

const METRIC_OPTIONS: { key: Metric; label: string; icon: typeof Zap }[] = [
  { key: "xp", label: "經驗值", icon: Zap },
  { key: "accuracy", label: "準確率", icon: Target },
  { key: "streak", label: "連續天數", icon: Flame },
];

// ============================================
// Stats Header
// ============================================

function StatsHeader({ currentStudent }: { currentStudent: LeaderboardStudent | undefined }) {
  return (
    <div className="card p-5 md:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        {/* Title */}
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-tier-gold to-accent-orange p-[2px] shadow-gold">
            <div className="w-full h-full rounded-2xl bg-white flex items-center justify-center">
              <Trophy className="w-7 h-7 text-tier-gold" />
            </div>
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-display text-text-primary">
              排行榜
            </h1>
            <p className="text-text-secondary text-sm">
              和同學們一起努力，看看誰最厲害！
            </p>
          </div>
        </div>

        {/* Current Rank Badge */}
        {currentStudent && (
          <div className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-tiffany-50 to-accent-cyan/10 rounded-2xl border border-tiffany-200">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-tiffany-500 to-accent-cyan flex items-center justify-center shadow-teal">
              <span className="font-display font-bold text-white text-lg">#{currentStudent.position}</span>
            </div>
            <div>
              <p className="text-xs text-text-secondary">你的排名</p>
              <p className="font-display text-tiffany-600">
                {currentStudent.value.toLocaleString()} XP
              </p>
            </div>
            {currentStudent.change > 0 && (
              <div className="flex items-center gap-1 text-accent-mint">
                <ChevronUp className="w-4 h-4" />
                <span className="text-sm font-display">+{currentStudent.change}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================
// Filter Tabs
// ============================================

function FilterTabs({
  period,
  setPeriod,
  metric,
  setMetric,
}: {
  period: Period;
  setPeriod: (p: Period) => void;
  metric: Metric;
  setMetric: (m: Metric) => void;
}) {
  return (
    <div className="flex flex-wrap justify-center gap-3">
      {/* Period */}
      <div className="flex gap-1 card p-1.5">
        {PERIOD_OPTIONS.map((opt) => {
          const Icon = opt.icon;
          return (
            <button
              key={opt.key}
              onClick={() => setPeriod(opt.key)}
              className={cn(
                "flex items-center gap-1.5 px-3 md:px-4 py-2 rounded-xl text-xs md:text-sm font-display transition-all duration-300 cursor-pointer",
                period === opt.key
                  ? "bg-gradient-to-r from-tiffany-500 to-accent-cyan text-white shadow-teal"
                  : "text-text-muted hover:text-text-primary hover:bg-surface-hover"
              )}
            >
              <Icon className="w-4 h-4" />
              {opt.label}
            </button>
          );
        })}
      </div>

      {/* Metric */}
      <div className="flex gap-1 card p-1.5">
        {METRIC_OPTIONS.map((opt) => {
          const Icon = opt.icon;
          return (
            <button
              key={opt.key}
              onClick={() => setMetric(opt.key)}
              className={cn(
                "flex items-center gap-1.5 px-3 md:px-4 py-2 rounded-xl text-xs md:text-sm font-display transition-all duration-300 cursor-pointer",
                metric === opt.key
                  ? "bg-gradient-to-r from-accent-mint to-accent-blue text-white shadow-sm"
                  : "text-text-muted hover:text-text-primary hover:bg-surface-hover"
              )}
            >
              <Icon className="w-4 h-4" />
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ============================================
// Podium Component - Top 3
// ============================================

function Podium({ students }: { students: LeaderboardStudent[] }) {
  const [first, second, third] = [students[0], students[1], students[2]];
  const isMe = (id: string) => id === MOCK_CURRENT_STUDENT;

  const podiumConfig = [
    {
      student: second,
      position: 2,
      height: "h-20 md:h-28",
      delay: "0.2s",
      emojiSize: "text-4xl md:text-5xl",
      shadowClass: "shadow-[0_4px_20px_rgba(148,163,184,0.25)]",
      bgGradient: "from-tier-silver-bg to-slate-100",
      borderColor: "border-tier-silver",
      textColor: "text-tier-silver",
    },
    {
      student: first,
      position: 1,
      height: "h-28 md:h-36",
      delay: "0s",
      emojiSize: "text-5xl md:text-6xl",
      shadowClass: "shadow-[0_4px_24px_rgba(245,158,11,0.3)]",
      bgGradient: "from-tier-gold-bg to-amber-100",
      borderColor: "border-tier-gold",
      textColor: "text-tier-gold",
    },
    {
      student: third,
      position: 3,
      height: "h-16 md:h-24",
      delay: "0.4s",
      emojiSize: "text-3xl md:text-4xl",
      shadowClass: "shadow-[0_4px_16px_rgba(205,127,50,0.25)]",
      bgGradient: "from-tier-bronze-bg to-orange-100",
      borderColor: "border-tier-bronze",
      textColor: "text-tier-bronze",
    },
  ];

  return (
    <div className="flex justify-center items-end gap-3 md:gap-6 py-6 md:py-8 px-4">
      {podiumConfig.map(({ student, position, height, delay, emojiSize, shadowClass, bgGradient, borderColor, textColor }) => (
        <div
          key={student.student_id}
          className="flex flex-col items-center animate-fade-in-up"
          style={{ animationDelay: delay }}
        >
          {/* Crown for first place */}
          {position === 1 && (
            <div className="mb-2 animate-float">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-tier-gold to-accent-orange flex items-center justify-center shadow-gold">
                <Crown className="w-5 h-5 text-white" />
              </div>
            </div>
          )}

          {/* Avatar */}
          <div className={cn(
            "mb-3 w-16 md:w-20 h-16 md:h-20 rounded-2xl flex items-center justify-center",
            "bg-gradient-to-br", bgGradient,
            "border-2", borderColor,
            shadowClass,
            isMe(student.student_id) && "ring-2 ring-tiffany-500 ring-offset-2 ring-offset-white"
          )}>
            <span className={emojiSize}>{student.avatar_emoji}</span>
          </div>

          {/* Name */}
          <p className={cn(
            "font-display text-center mb-1",
            position === 1 ? "text-base md:text-lg" : "text-sm md:text-base",
            textColor,
            isMe(student.student_id) && "text-tiffany-600"
          )}>
            {student.student_name}
            {isMe(student.student_id) && (
              <Sparkles className="w-4 h-4 inline ml-1 text-tiffany-600" />
            )}
          </p>

          {/* XP */}
          <p className="text-text-secondary font-medium mb-2 text-xs md:text-sm">
            {student.value.toLocaleString()} XP
          </p>

          {/* Podium Base */}
          <div className={cn(
            "w-16 md:w-24 rounded-t-2xl flex flex-col items-center justify-end pb-3 transition-all",
            "bg-gradient-to-t border-2 border-b-0",
            bgGradient, borderColor,
            height
          )}>
            <span className={cn(
              "text-2xl md:text-3xl font-display font-bold",
              textColor
            )}>
              {position}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

// ============================================
// Rank Change Indicator
// ============================================

function RankChange({ change }: { change: number }) {
  if (change > 0) {
    return (
      <span className="flex items-center gap-1 px-2.5 py-1.5 bg-accent-mint/10 text-accent-mint rounded-xl text-xs font-display border border-accent-mint/30">
        <TrendingUp className="w-3.5 h-3.5" />
        +{change}
      </span>
    );
  } else if (change < 0) {
    return (
      <span className="flex items-center gap-1 px-2.5 py-1.5 bg-accent-coral/10 text-accent-coral rounded-xl text-xs font-display border border-accent-coral/30">
        <TrendingDown className="w-3.5 h-3.5" />
        {change}
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1 px-2.5 py-1.5 bg-surface-elevated text-text-muted rounded-xl text-xs font-display border border-surface-border">
      <Minus className="w-3.5 h-3.5" />
    </span>
  );
}

// ============================================
// Leaderboard Row
// ============================================

function LeaderboardRow({
  student,
  index,
}: {
  student: LeaderboardStudent;
  index: number;
}) {
  const isMe = student.student_id === MOCK_CURRENT_STUDENT;

  return (
    <div
      className={cn(
        "flex items-center justify-between p-3 md:p-4 rounded-2xl transition-all duration-300 cursor-pointer",
        "animate-fade-in-up hover:-translate-y-1 active:translate-y-0",
        "border-2",
        isMe
          ? "card border-tiffany-500/30 shadow-teal"
          : "card card-hover border-transparent"
      )}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="flex items-center gap-3 md:gap-4">
        {/* Rank */}
        <div className={cn(
          "w-9 h-9 md:w-11 md:h-11 rounded-xl flex items-center justify-center font-display font-bold text-sm md:text-base flex-shrink-0",
          isMe
            ? "bg-gradient-to-br from-tiffany-500 to-accent-cyan text-white shadow-teal"
            : "bg-surface-elevated text-text-secondary border border-surface-border"
        )}>
          {student.position}
        </div>

        {/* Avatar */}
        <div className={cn(
          "w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-2xl md:text-3xl",
          "bg-surface-elevated border border-surface-border",
          isMe && "border-tiffany-500/30"
        )}>
          {student.avatar_emoji}
        </div>

        {/* Info */}
        <div className="min-w-0">
          <p className={cn(
            "font-display text-sm md:text-base truncate flex items-center gap-1",
            isMe ? "text-tiffany-600" : "text-text-primary"
          )}>
            {student.student_name}
            {isMe && <Sparkles className="w-4 h-4 text-tiffany-600" />}
          </p>
          <div className="flex items-center gap-2 flex-wrap mt-0.5">
            <span className="px-2 py-0.5 bg-tiffany-50 text-tiffany-600 rounded-lg text-[10px] md:text-xs font-display border border-tiffany-200">
              {student.title}
            </span>
            <span className="flex items-center gap-1 text-accent-orange text-[10px] md:text-xs font-display">
              <Flame className="w-3 h-3" />
              {student.streak}天
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-4 flex-shrink-0">
        {/* XP */}
        <div className="text-right">
          <p className="font-display font-bold text-base md:text-lg text-text-primary">
            {student.value.toLocaleString()}
          </p>
          <p className="text-[10px] md:text-xs text-text-muted font-medium">XP</p>
        </div>

        {/* Change */}
        <RankChange change={student.change} />
      </div>
    </div>
  );
}

// ============================================
// Current Student Highlight
// ============================================

function CurrentStudentHighlight({ student }: { student: LeaderboardStudent }) {
  return (
    <div className="card p-4 border-2 border-tiffany-500/30 shadow-teal">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-tiffany-500 to-accent-cyan flex items-center justify-center font-display font-bold text-white shadow-teal">
            #{student.position}
          </div>
          <div className="w-11 h-11 rounded-xl bg-surface-elevated flex items-center justify-center text-2xl border border-tiffany-200">
            {student.avatar_emoji}
          </div>
          <div>
            <p className="font-display text-sm text-tiffany-600 flex items-center gap-1">
              {student.student_name}
              <Sparkles className="w-4 h-4" />
            </p>
            <span className="px-2 py-0.5 bg-tiffany-50 text-tiffany-600 rounded-lg text-[10px] font-display border border-tiffany-200">
              {student.title}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          <div className="text-right">
            <p className="text-lg font-display font-bold text-text-primary">
              {student.value.toLocaleString()}
            </p>
            <p className="text-[10px] text-text-muted font-medium">XP</p>
          </div>
          <RankChange change={student.change} />
        </div>
      </div>
    </div>
  );
}

// ============================================
// Motivational Footer
// ============================================

function MotivationalFooter() {
  const tips = [
    { icon: Target, label: "設定目標", color: "from-accent-mint to-accent-blue" },
    { icon: Flame, label: "保持連勝", color: "from-accent-orange to-tier-gold" },
    { icon: Zap, label: "持續學習", color: "from-tiffany-500 to-accent-cyan" },
  ];

  return (
    <div className="text-center py-4">
      <div className="inline-flex flex-col items-center gap-3 px-6 py-4 card">
        <div className="flex items-center gap-2">
          <Award className="w-5 h-5 text-tiffany-600" />
          <Sparkles className="w-5 h-5 text-accent-pink" />
          <Star className="w-5 h-5 text-tier-gold" />
        </div>
        <p className="text-text-secondary text-sm max-w-md">
          重要的不是名次，而是每天比昨天更好！
        </p>
        <div className="flex gap-2 flex-wrap justify-center">
          {tips.map((tip) => {
            const Icon = tip.icon;
            return (
              <span
                key={tip.label}
                className={cn(
                  "px-3 py-1.5 bg-gradient-to-r text-white rounded-xl text-xs font-display flex items-center gap-1.5 shadow-sm",
                  tip.color
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                {tip.label}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

export function LeaderboardPageDemo() {
  const [period, setPeriod] = useState<Period>("weekly");
  const [metric, setMetric] = useState<Metric>("xp");

  const remaining = MOCK_LEADERBOARD.slice(3);
  const currentStudent = MOCK_LEADERBOARD.find(
    (s) => s.student_id === MOCK_CURRENT_STUDENT
  );

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="container-app py-4 md:py-6 space-y-4">
        {/* Stats Header */}
        <StatsHeader currentStudent={currentStudent} />

        {/* Filters */}
        <FilterTabs
          period={period}
          setPeriod={setPeriod}
          metric={metric}
          setMetric={setMetric}
        />

        {/* Top 3 Podium */}
        <div className="card p-2 md:p-4">
          <Podium students={MOCK_LEADERBOARD} />
        </div>

        {/* Current Student Highlight (if not in top 3) */}
        {currentStudent && currentStudent.position > 3 && (
          <CurrentStudentHighlight student={currentStudent} />
        )}

        {/* Remaining List */}
        <div className="space-y-2 md:space-y-3 stagger-children">
          {remaining.map((student, idx) => (
            <LeaderboardRow key={student.student_id} student={student} index={idx} />
          ))}
        </div>

        {/* Motivational Footer */}
        <MotivationalFooter />
      </div>
    </div>
  );
}

export default LeaderboardPageDemo;
