/**
 * Badges Page - 2026 EduBaania Tiffany/Teal Theme
 *
 * Design System: Tiffany/Teal + Clean + Modern
 * - Light backgrounds with clean surfaces
 * - Colorful badge cards with tier colors
 * - Animated progress indicators
 * - Pagination for better UX
 */

import { useState, useMemo } from "react";
import {
  Award,
  Lock,
  X,
  Check,
  Star,
  Heart,
  Trophy,
  Sparkles,
  Filter,
  Zap,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { MOCK_BADGES, getBadgeStats } from "../../data/mockData";
import type { Badge, BadgeTier } from "../../types/gamification";

// ============================================
// Constants
// ============================================

const ITEMS_PER_PAGE = 12; // 每頁顯示 12 個徽章 (2 行 x 6 列 或 3 行 x 4 列)

// ============================================
// Tier Configurations - Warm Style
// ============================================

const TIER_CONFIG: Record<BadgeTier, {
  label: string;
  color: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  shadowClass: string;
}> = {
  bronze: {
    label: "銅牌",
    color: "#CD7F32",
    bgClass: "bg-tier-bronze-bg",
    textClass: "text-tier-bronze",
    borderClass: "border-tier-bronze",
    shadowClass: "shadow-[0_4px_16px_rgba(205,127,50,0.2)]",
  },
  silver: {
    label: "銀牌",
    color: "#94A3B8",
    bgClass: "bg-tier-silver-bg",
    textClass: "text-tier-silver",
    borderClass: "border-tier-silver",
    shadowClass: "shadow-[0_4px_16px_rgba(148,163,184,0.2)]",
  },
  gold: {
    label: "金牌",
    color: "#F59E0B",
    bgClass: "bg-tier-gold-bg",
    textClass: "text-tier-gold",
    borderClass: "border-tier-gold",
    shadowClass: "shadow-[0_4px_20px_rgba(245,158,11,0.25)]",
  },
  diamond: {
    label: "鑽石",
    color: "#8B5CF6",
    bgClass: "bg-tier-diamond-bg",
    textClass: "text-tier-diamond",
    borderClass: "border-tier-diamond",
    shadowClass: "shadow-[0_4px_20px_rgba(139,92,246,0.25)]",
  },
};

// ============================================
// Stats Header Component
// ============================================

function StatsHeader() {
  const stats = getBadgeStats();
  const progressPercent = (stats.earned / stats.total) * 100;

  return (
    <div className="card p-5 md:p-6 mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        {/* Title */}
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-tiffany-500 to-accent-cyan p-[2px] shadow-teal">
            <div className="w-full h-full rounded-2xl bg-white flex items-center justify-center">
              <Award className="w-7 h-7 text-tiffany-600" />
            </div>
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-display text-text-primary">
              成就徽章
            </h1>
            <p className="text-text-secondary text-sm">
              已收集 <span className="font-bold text-tiffany-600">{stats.earned}</span> / {stats.total} 個
            </p>
          </div>
        </div>

        {/* Tier Stats */}
        <div className="flex gap-2 flex-wrap">
          {(Object.entries(TIER_CONFIG) as [BadgeTier, typeof TIER_CONFIG[BadgeTier]][]).map(([tier, config]) => {
            const tierStats = stats.byTier[tier];
            return (
              <div
                key={tier}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded-xl",
                  config.bgClass,
                  "border",
                  config.borderClass,
                  "border-opacity-50"
                )}
              >
                <Star className={cn("w-4 h-4", config.textClass)} />
                <span className={cn("font-display text-sm", config.textClass)}>
                  {tierStats.earned}/{tierStats.total}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mt-5">
        <div className="progress-bar h-3">
          <div
            className="progress-fill"
            style={{ width: `${progressPercent}%` }}
          />
          <div className="progress-shimmer" />
        </div>
        <div className="flex justify-between mt-2 text-xs">
          <span className="text-text-muted">收集進度</span>
          <span className="text-tiffany-600 font-medium">{Math.round(progressPercent)}%</span>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Filter Tabs Component
// ============================================

function FilterTabs({
  selectedTier,
  onSelect,
}: {
  selectedTier: BadgeTier | null;
  onSelect: (tier: BadgeTier | null) => void;
}) {
  const filters: { key: BadgeTier | null; label: string }[] = [
    { key: null, label: "全部" },
    { key: "bronze", label: "銅牌" },
    { key: "silver", label: "銀牌" },
    { key: "gold", label: "金牌" },
    { key: "diamond", label: "鑽石" },
  ];

  return (
    <div className="flex gap-2 mb-6 overflow-x-auto pb-2 hide-scrollbar">
      {filters.map((filter) => {
        const isActive = selectedTier === filter.key;
        const tierConfig = filter.key ? TIER_CONFIG[filter.key] : null;

        return (
          <button
            key={filter.key || "all"}
            onClick={() => onSelect(filter.key)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-xl font-display text-sm whitespace-nowrap",
              "border-2 transition-all duration-300 cursor-pointer",
              isActive
                ? tierConfig
                  ? cn("bg-white", tierConfig.borderClass, tierConfig.shadowClass, tierConfig.textClass)
                  : "bg-gradient-to-r from-tiffany-500 to-accent-cyan text-white border-transparent shadow-teal"
                : "bg-white text-text-secondary border-surface-border hover:border-tiffany-500/30 hover:text-text-primary"
            )}
          >
            {filter.key ? (
              <Star className={cn("w-4 h-4", isActive ? tierConfig?.textClass : "text-text-muted")} />
            ) : (
              <Filter className="w-4 h-4" />
            )}
            {filter.label}
          </button>
        );
      })}
    </div>
  );
}

// ============================================
// Pagination Component
// ============================================

function Pagination({
  currentPage,
  totalPages,
  onPageChange,
}: {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;

  // Generate page numbers to show
  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisible = 5;

    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (currentPage <= 3) {
        pages.push(1, 2, 3, 4, '...', totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1, '...', totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages);
      }
    }
    return pages;
  };

  return (
    <div className="flex items-center justify-center gap-2 mt-6">
      {/* Previous Button */}
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={cn(
          "w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer",
          currentPage === 1
            ? "bg-surface-elevated text-text-muted cursor-not-allowed"
            : "bg-white border border-surface-border text-text-secondary hover:border-tiffany-500/30 hover:text-tiffany-600"
        )}
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      {/* Page Numbers */}
      <div className="flex items-center gap-1">
        {getPageNumbers().map((page, idx) => (
          <button
            key={idx}
            onClick={() => typeof page === 'number' && onPageChange(page)}
            disabled={typeof page === 'string'}
            className={cn(
              "w-10 h-10 rounded-xl font-display text-sm transition-all",
              typeof page === 'string'
                ? "text-text-muted cursor-default"
                : page === currentPage
                  ? "bg-gradient-to-r from-tiffany-500 to-accent-cyan text-white shadow-teal"
                  : "bg-white border border-surface-border text-text-secondary hover:border-tiffany-500/30 hover:text-tiffany-600 cursor-pointer"
            )}
          >
            {page}
          </button>
        ))}
      </div>

      {/* Next Button */}
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={cn(
          "w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer",
          currentPage === totalPages
            ? "bg-surface-elevated text-text-muted cursor-not-allowed"
            : "bg-white border border-surface-border text-text-secondary hover:border-tiffany-500/30 hover:text-tiffany-600"
        )}
      >
        <ChevronRight className="w-5 h-5" />
      </button>
    </div>
  );
}

// ============================================
// Badge Card Component
// ============================================

function BadgeCard({
  badge,
  onClick,
  index,
}: {
  badge: Badge;
  onClick: () => void;
  index: number;
}) {
  const tier = TIER_CONFIG[badge.tier];
  const isEarned = !!badge.earnedAt;
  const progress = badge.progress ? Math.round(badge.progress.percentage) : 0;

  return (
    <button
      onClick={onClick}
      className={cn(
        "relative p-4 rounded-2xl transition-all duration-300 cursor-pointer",
        "border-2 text-left w-full group",
        "hover:-translate-y-2 active:translate-y-0",
        isEarned
          ? cn(
              `badge-tier-${badge.tier}`,
              "hover:scale-105"
            )
          : "bg-white border-surface-border opacity-70 hover:opacity-100 hover:border-tiffany-500/30 hover:shadow-card-hover"
      )}
      style={{ animationDelay: `${index * 30}ms` }}
    >
      {/* Earned Indicator */}
      {isEarned && (
        <div className="absolute -top-2 -right-2 w-7 h-7 bg-accent-mint rounded-full flex items-center justify-center shadow-sm border-2 border-white">
          <Check className="w-4 h-4 text-white" strokeWidth={3} />
        </div>
      )}

      {/* Badge Image/Emoji */}
      <div className="relative w-16 h-16 mx-auto mb-3">
        {isEarned ? (
          <div className={cn(
            "w-full h-full rounded-xl flex items-center justify-center overflow-hidden",
            "bg-gradient-to-br from-white/50 to-white/20",
            "group-hover:animate-float"
          )}>
            {badge.imageUrl ? (
              <img
                src={badge.imageUrl}
                alt={badge.name}
                className="w-full h-full object-contain rounded-xl"
                onError={(e) => {
                  // Fallback to emoji if image fails to load
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.nextElementSibling?.classList.remove('hidden');
                }}
              />
            ) : null}
            <span className={cn("text-4xl", badge.imageUrl ? "hidden" : "")}>{badge.emoji}</span>
          </div>
        ) : badge.isHidden ? (
          <div className="w-full h-full rounded-xl bg-surface-elevated flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-text-muted" />
          </div>
        ) : (
          <div className="relative w-full h-full">
            <div className="w-full h-full rounded-xl bg-surface-elevated flex items-center justify-center overflow-hidden opacity-40 grayscale">
              {badge.imageUrl ? (
                <img
                  src={badge.imageUrl}
                  alt={badge.name}
                  className="w-full h-full object-contain rounded-xl"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling?.classList.remove('hidden');
                  }}
                />
              ) : null}
              <span className={cn("text-3xl", badge.imageUrl ? "hidden" : "")}>{badge.emoji}</span>
            </div>
            <div className="absolute inset-0 flex items-center justify-center bg-white/50 rounded-xl backdrop-blur-[2px]">
              <Lock className="w-6 h-6 text-text-muted" />
            </div>
          </div>
        )}
      </div>

      {/* Badge Name */}
      <p className={cn(
        "text-sm font-display text-center line-clamp-1",
        isEarned ? "text-text-primary" : "text-text-muted"
      )}>
        {badge.isHidden && !isEarned ? "???" : badge.name}
      </p>

      {/* Tier Label */}
      <p className={cn(
        "text-xs text-center mt-0.5 font-medium",
        isEarned ? tier.textClass : "text-text-muted"
      )}>
        {tier.label}
      </p>

      {/* Progress Bar (for unearned badges with progress) */}
      {!isEarned && !badge.isHidden && badge.progress && (
        <div className="mt-3">
          <div className="h-1.5 bg-surface-elevated rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-tiffany-500 to-accent-cyan rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-[10px] text-text-muted text-center mt-1 font-medium">
            {badge.progress.current}/{badge.progress.target}
          </p>
        </div>
      )}
    </button>
  );
}

// ============================================
// Badge Modal Component
// ============================================

function BadgeModal({
  badge,
  onClose,
}: {
  badge: Badge;
  onClose: () => void;
}) {
  const tier = TIER_CONFIG[badge.tier];
  const isEarned = !!badge.earnedAt;

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className={cn(
          "card p-6 md:p-8 max-w-md w-full relative overflow-hidden",
          "animate-scale-in"
        )}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Background Glow */}
        {isEarned && (
          <div
            className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full blur-3xl opacity-20"
            style={{ backgroundColor: tier.color }}
          />
        )}

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-xl bg-surface-elevated flex items-center justify-center hover:bg-surface-hover transition-colors cursor-pointer"
        >
          <X className="w-5 h-5 text-text-secondary" />
        </button>

        {/* Badge Display */}
        <div className="relative z-10">
          {/* Badge Image/Emoji */}
          <div className={cn(
            "relative w-32 h-32 mx-auto mb-6 rounded-2xl flex items-center justify-center overflow-hidden",
            isEarned
              ? cn(`badge-tier-${badge.tier}`, "animate-float")
              : "bg-surface-elevated opacity-50"
          )}>
            {badge.isHidden && !isEarned ? (
              <Sparkles className="w-16 h-16 text-text-muted" />
            ) : badge.imageUrl ? (
              <img
                src={badge.imageUrl}
                alt={badge.name}
                className="w-full h-full object-contain"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.nextElementSibling?.classList.remove('hidden');
                }}
              />
            ) : null}
            <span className={cn("text-7xl", badge.imageUrl ? "hidden" : "")}>{badge.emoji}</span>

            {/* Earned Badge */}
            {isEarned && (
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-accent-mint rounded-xl flex items-center justify-center shadow-sm border-2 border-white">
                <Check className="w-5 h-5 text-white" strokeWidth={3} />
              </div>
            )}
          </div>

          {/* Tier Badge */}
          <div className="flex justify-center mb-4">
            <span className={cn(
              "inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-display",
              "border-2",
              tier.textClass,
              tier.borderClass,
              tier.bgClass
            )}>
              <Star className="w-4 h-4" />
              {tier.label}
            </span>
          </div>

          {/* Info */}
          <div className="text-center mb-6">
            <h3 className="text-2xl font-display text-text-primary mb-2">
              {badge.isHidden && !isEarned ? "???" : badge.name}
            </h3>
            <p className="text-text-secondary">
              {badge.isHidden && !isEarned
                ? "完成神秘任務才能發現"
                : badge.description}
            </p>
          </div>

          {/* Rewards */}
          <div className="flex justify-center gap-4 mb-6">
            <div className="flex items-center gap-2 px-4 py-2 bg-tiffany-50 rounded-xl border border-tiffany-200">
              <Zap className="w-5 h-5 text-tiffany-600" />
              <span className="font-display text-tiffany-600">
                +{badge.xpReward} XP
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-tier-gold/10 rounded-xl border border-tier-gold/20">
              <span className="text-lg">🪙</span>
              <span className="font-display text-tier-gold">
                +{badge.coinReward}
              </span>
            </div>
          </div>

          {/* Status / Progress */}
          {isEarned ? (
            <div className="space-y-4">
              <p className="text-center text-text-muted text-sm">
                獲得於 {new Date(badge.earnedAt!).toLocaleDateString('zh-TW')}
              </p>
              <div className="flex gap-3">
                <button className="flex-1 btn-teal btn-teal-secondary py-3">
                  <Heart className="w-4 h-4" />
                  收藏
                </button>
                <button className="flex-1 btn-teal py-3">
                  <Trophy className="w-4 h-4" />
                  展示
                </button>
              </div>
            </div>
          ) : badge.progress ? (
            <div className="space-y-3">
              <div className="progress-bar h-3">
                <div
                  className="progress-fill"
                  style={{ width: `${badge.progress.percentage}%` }}
                />
                <div className="progress-shimmer" />
              </div>
              <p className="text-center text-text-secondary font-medium">
                進度: {badge.progress.current}/{badge.progress.target}
              </p>
            </div>
          ) : (
            <p className="text-center text-text-muted">
              完成條件以解鎖此徽章
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

export function BadgesPageDemo() {
  const [selectedTier, setSelectedTier] = useState<BadgeTier | null>(null);
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  // Filter and sort badges
  const filteredBadges = useMemo(() => {
    const filtered = selectedTier
      ? MOCK_BADGES.filter((b) => b.tier === selectedTier)
      : MOCK_BADGES;

    // Sort: earned first, then by tier importance
    return [...filtered].sort((a, b) => {
      if (a.earnedAt && !b.earnedAt) return -1;
      if (!a.earnedAt && b.earnedAt) return 1;
      return 0;
    });
  }, [selectedTier]);

  // Pagination
  const totalPages = Math.ceil(filteredBadges.length / ITEMS_PER_PAGE);
  const paginatedBadges = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredBadges.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredBadges, currentPage]);

  // Reset to page 1 when filter changes
  const handleFilterChange = (tier: BadgeTier | null) => {
    setSelectedTier(tier);
    setCurrentPage(1);
  };

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="container-app py-4 md:py-6">
        {/* Stats Header */}
        <StatsHeader />

        {/* Filter Tabs */}
        <FilterTabs selectedTier={selectedTier} onSelect={handleFilterChange} />

        {/* Page Info */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-text-muted">
            顯示 {(currentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, filteredBadges.length)} / {filteredBadges.length} 個徽章
          </p>
        </div>

        {/* Badge Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3 md:gap-4 stagger-children">
          {paginatedBadges.map((badge, index) => (
            <div
              key={badge.id}
              className="animate-fade-in-up"
              style={{ animationDelay: `${index * 30}ms` }}
            >
              <BadgeCard
                badge={badge}
                index={index}
                onClick={() => setSelectedBadge(badge)}
              />
            </div>
          ))}
        </div>

        {/* Empty State */}
        {paginatedBadges.length === 0 && (
          <div className="text-center py-12">
            <Award className="w-16 h-16 text-text-muted mx-auto mb-4" />
            <p className="text-text-muted font-display">
              沒有找到符合條件的徽章
            </p>
          </div>
        )}

        {/* Pagination */}
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />

        {/* Footer Stats */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-3 px-6 py-3 card">
            <Trophy className="w-5 h-5 text-tier-gold" />
            <span className="text-text-secondary text-sm">
              共有 <span className="font-bold text-tiffany-600">{MOCK_BADGES.length}</span> 個徽章等你收集
            </span>
          </div>
        </div>
      </div>

      {/* Badge Modal */}
      {selectedBadge && (
        <BadgeModal badge={selectedBadge} onClose={() => setSelectedBadge(null)} />
      )}
    </div>
  );
}

export default BadgesPageDemo;
