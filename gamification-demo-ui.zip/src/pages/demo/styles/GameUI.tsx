/**
 * Style: GameUI - 精緻手遊風格
 *
 * 參考：生圖模型產出的高品質遊戲 UI
 * - 深藍紫漸層背景 + 金色點綴
 * - 發光效果、光暈裝飾
 * - 卡片式設計，圓角金邊
 * - 動物頭像系統
 * - 清晰的資訊層級
 */

import { useState } from "react";
import { cn } from "../../../lib/utils";

// ============================================
// 配色系統
// ============================================
const COLORS = {
  // 背景
  bgGradient: "linear-gradient(180deg, #1a1a4e 0%, #0d1033 50%, #0a0a20 100%)",
  cardBg: "rgba(20, 30, 80, 0.6)",
  cardBorder: "#4a5090",

  // 金色系
  gold: "#FFD700",
  goldLight: "#FFEC8B",
  goldDark: "#DAA520",
  goldGradient: "linear-gradient(180deg, #FFD700 0%, #FFA500 100%)",

  // 狀態色
  positive: "#4ADE80",
  negative: "#F87171",
  neutral: "#9CA3AF",

  // 文字
  text: "#FFFFFF",
  textMuted: "#A0A0C0",
};

// ============================================
// 數據
// ============================================
const LEADERBOARD = [
  { rank: 1, name: "小明", title: "學霸王者", xp: 2850, streak: 15, change: 2, avatar: "🦁", avatarBg: "#FFE4B5" },
  { rank: 2, name: "小華", title: "知識達人", xp: 2720, streak: 12, change: -1, avatar: "🐰", avatarBg: "#E8E8E8" },
  { rank: 3, name: "小芳", title: "勤學之星", xp: 2680, streak: 10, change: 1, avatar: "🐼", avatarBg: "#E0E0E0" },
  { rank: 4, name: "小剛", title: "進擊的學子", xp: 2550, streak: 8, change: 0, avatar: "🐵", avatarBg: "#DEB887" },
  { rank: 5, name: "你", title: "知識探索家", xp: 2450, streak: 12, change: 3, avatar: "🐱", avatarBg: "#B0E0E6", isMe: true },
];

const BADGES = [
  { id: 1, name: "七日勇士", desc: "連續登入 7 天", earned: true, tier: "gold", icon: "🔥", xp: 50 },
  { id: 2, name: "雙週達人", desc: "連續登入 14 天", earned: false, progress: 50, tier: "silver", icon: "🔥", xp: 100 },
  { id: 3, name: "知識超人", desc: "完成 100 任務", earned: true, tier: "silver", icon: "🎯", xp: 75 },
  { id: 4, name: "滿分王者", desc: "考試滿分", earned: true, tier: "gold", icon: "👑", xp: 150 },
  { id: 5, name: "誠實天使", desc: "20 次認真作答", earned: false, progress: 60, tier: "silver", icon: "💖", xp: 75 },
  { id: 6, name: "連勝霸主", desc: "連續 50 題正確", earned: false, progress: 64, tier: "gold", icon: "⚡", xp: 150 },
  { id: 7, name: "神秘寶藏", desc: "???", earned: false, secret: true, tier: "legendary", icon: "❓", xp: 300 },
  { id: 8, name: "冒險家", desc: "達到等級 15", earned: false, progress: 53, tier: "gold", icon: "🗡️", xp: 150 },
];

const SHOP_ITEMS = [
  { id: 1, name: "經驗加倍卡", desc: "24小時內經驗 x2", price: 100, icon: "⚡", type: "boost", stock: 5 },
  { id: 2, name: "神秘寶箱", desc: "開啟獲得隨機獎勵", price: 200, icon: "🎁", type: "box", stock: 3 },
  { id: 3, name: "復活卷軸", desc: "連勝中斷時保護一次", price: 150, icon: "💫", type: "protect", stock: 10 },
  { id: 4, name: "稀有頭像框", desc: "金色發光頭像框", price: 500, icon: "✨", type: "cosmetic", stock: 1 },
  { id: 5, name: "稱號：傳說勇者", desc: "專屬稱號顯示", price: 800, icon: "🏆", type: "title", stock: 1 },
  { id: 6, name: "幸運星", desc: "答題提示次數 +3", price: 80, icon: "⭐", type: "hint", stock: 99 },
];

const TIERS = {
  bronze: { color: "#CD7F32", glow: "0 0 20px #CD7F3260" },
  silver: { color: "#C0C0C0", glow: "0 0 20px #C0C0C060" },
  gold: { color: "#FFD700", glow: "0 0 25px #FFD70080" },
  legendary: { color: "#9932CC", glow: "0 0 30px #9932CC80" },
};

// ============================================
// 共用元件
// ============================================

// 金邊卡片
function GoldCard({
  children,
  className,
  highlight = false,
  glow = false,
}: {
  children: React.ReactNode;
  className?: string;
  highlight?: boolean;
  glow?: boolean;
}) {
  return (
    <div
      className={cn(
        "relative rounded-2xl p-4 border-2 transition-all",
        highlight ? "border-amber-400" : "border-amber-600/50",
        className
      )}
      style={{
        background: highlight
          ? "linear-gradient(180deg, rgba(255,215,0,0.15) 0%, rgba(255,165,0,0.1) 100%)"
          : COLORS.cardBg,
        boxShadow: glow
          ? "0 0 30px rgba(255,215,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)"
          : "inset 0 1px 0 rgba(255,255,255,0.1)",
      }}
    >
      {/* 角落裝飾 */}
      <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-amber-400 rounded-tl-lg" />
      <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-amber-400 rounded-tr-lg" />
      <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-amber-400 rounded-bl-lg" />
      <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-amber-400 rounded-br-lg" />
      {children}
    </div>
  );
}

// 金色按鈕
function GoldButton({
  children,
  active = false,
  onClick,
  className,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "px-4 py-2 rounded-full font-bold transition-all border-2",
        active
          ? "text-amber-900 border-amber-300 shadow-lg"
          : "text-amber-200 border-amber-600/50 hover:border-amber-500",
        className
      )}
      style={{
        background: active
          ? "linear-gradient(180deg, #FFD700 0%, #FFA500 100%)"
          : "rgba(255,215,0,0.1)",
      }}
    >
      {children}
    </button>
  );
}

// 頭像元件
function Avatar({
  emoji,
  bg,
  size = "md",
  rank,
  showCrown = false,
  highlight = false,
}: {
  emoji: string;
  bg: string;
  size?: "sm" | "md" | "lg" | "xl";
  rank?: number;
  showCrown?: boolean;
  highlight?: boolean;
}) {
  const sizes = {
    sm: "w-10 h-10 text-xl",
    md: "w-12 h-12 text-2xl",
    lg: "w-16 h-16 text-3xl",
    xl: "w-20 h-20 text-4xl",
  };

  const rankColors: Record<number, string> = {
    1: "#FFD700",
    2: "#C0C0C0",
    3: "#CD7F32",
  };

  return (
    <div className="relative">
      {showCrown && (
        <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-2xl z-10">
          👑
        </div>
      )}
      <div
        className={cn(
          "rounded-full flex items-center justify-center border-4 shadow-lg",
          sizes[size],
          highlight && "ring-4 ring-cyan-400 ring-offset-2 ring-offset-transparent"
        )}
        style={{
          backgroundColor: bg,
          borderColor: rank ? rankColors[rank] || "#4a5090" : highlight ? "#FFD700" : "#4a5090",
          boxShadow: rank && rank <= 3 ? `0 0 20px ${rankColors[rank]}60` : undefined,
        }}
      >
        {emoji}
      </div>
      {rank && (
        <div
          className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-xs font-black border-2 border-white"
          style={{ backgroundColor: rankColors[rank] || "#4a5090", color: rank <= 3 ? "#000" : "#fff" }}
        >
          {rank}
        </div>
      )}
    </div>
  );
}

// 排名變化指示器
function RankChange({ change }: { change: number }) {
  if (change > 0) {
    return (
      <span className="px-2 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: "rgba(74,222,128,0.2)", color: COLORS.positive }}>
        +{change}↑
      </span>
    );
  } else if (change < 0) {
    return (
      <span className="px-2 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: "rgba(248,113,113,0.2)", color: COLORS.negative }}>
        {change}↓
      </span>
    );
  }
  return (
    <span className="px-2 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: "rgba(156,163,175,0.2)", color: COLORS.neutral }}>
      —
    </span>
  );
}

// ============================================
// 排行榜元件
// ============================================

// 頒獎台 - 卡片框架頭像設計
function Podium() {
  const top3 = LEADERBOARD.slice(0, 3);
  const [first, second, third] = [top3[0], top3[1], top3[2]];

  // 順序：2, 1, 3（左到右）
  const podiumData = [
    { player: second, position: 2, medalColor: "#C0C0C0", cardW: "w-[88px]", cardH: "h-[120px]", avatarSize: "w-12 h-12 text-2xl" },
    { player: first, position: 1, medalColor: "#FFD700", cardW: "w-[100px]", cardH: "h-[140px]", avatarSize: "w-14 h-14 text-3xl" },
    { player: third, position: 3, medalColor: "#CD7F32", cardW: "w-[80px]", cardH: "h-[110px]", avatarSize: "w-11 h-11 text-xl" },
  ];

  return (
    <div className="relative py-6">
      {/* 藍色光暈背景 */}
      <div
        className="absolute inset-0 rounded-2xl"
        style={{
          background: "radial-gradient(ellipse at center, rgba(65,105,225,0.35) 0%, transparent 70%)",
        }}
      />

      <div className="relative flex justify-center items-end gap-4">
        {podiumData.map(({ player, position, medalColor, cardW, cardH, avatarSize }) => (
          <div key={position} className={cn("flex flex-col items-center", position === 1 && "-mt-6")}>
            {/* 皇冠 - 只有第一名 */}
            {position === 1 && (
              <div className="text-3xl mb-2 drop-shadow-lg">👑</div>
            )}

            {/* 卡片框架頭像 */}
            <div
              className={cn("relative rounded-xl p-2 flex flex-col items-center", cardW, cardH)}
              style={{
                background: "linear-gradient(180deg, #2a3a6a 0%, #1a2a4a 100%)",
                border: `3px solid ${medalColor}`,
                boxShadow: `0 0 20px ${medalColor}50, inset 0 1px 0 rgba(255,255,255,0.1)`,
              }}
            >
              {/* 排名獎牌 */}
              <div
                className="absolute -top-2.5 -right-2.5 w-7 h-7 rounded-full flex items-center justify-center text-xs font-black border-2 border-white/30"
                style={{
                  backgroundColor: medalColor,
                  color: position === 1 ? "#92400E" : "#374151",
                  boxShadow: `0 2px 8px ${medalColor}80`,
                }}
              >
                {position}
              </div>

              {/* 頭像 */}
              <div
                className={cn("rounded-lg flex items-center justify-center", avatarSize)}
                style={{ backgroundColor: player.avatarBg }}
              >
                {player.avatar}
              </div>

              {/* 名稱 */}
              <p className={cn(
                "font-bold text-center mt-1.5 truncate w-full px-1",
                position === 1 ? "text-sm text-amber-400" : "text-xs text-white"
              )}>
                {player.name}
              </p>
              <p className="text-[10px] text-amber-200/50 text-center truncate w-full px-1">{player.title}</p>
            </div>

            {/* 資訊區 */}
            <div className="flex items-center gap-1 mt-2.5">
              <span className="text-orange-400 text-sm">🔥</span>
              <span className="text-orange-300 text-xs">{player.streak}天</span>
            </div>
            <p className={cn(
              "font-bold mt-0.5",
              position === 1 ? "text-base text-amber-400" : "text-sm text-amber-300"
            )}>
              {player.xp.toLocaleString()} XP
            </p>
            <div className="mt-1">
              <RankChange change={player.change} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 排行列表行 - 緊湊的表格式設計
function LeaderboardRow({ player }: { player: typeof LEADERBOARD[0] }) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-xl mb-2 border-2 transition-all",
        player.isMe
          ? "border-amber-400 bg-gradient-to-r from-amber-500/20 to-orange-500/10"
          : "border-amber-600/30 bg-gradient-to-r from-slate-800/60 to-slate-900/40"
      )}
      style={{
        boxShadow: player.isMe ? "0 0 20px rgba(255,215,0,0.3)" : "0 2px 4px rgba(0,0,0,0.2)",
      }}
    >
      {/* 排名數字 */}
      <div
        className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm flex-shrink-0"
        style={{
          background: player.rank <= 3
            ? "linear-gradient(180deg, #FFD700 0%, #FFA500 100%)"
            : "linear-gradient(180deg, #4a5090 0%, #3a4080 100%)",
          color: player.rank <= 3 ? "#92400E" : "#FFD700",
          boxShadow: player.rank <= 3 ? "0 2px 6px rgba(255,215,0,0.4)" : undefined,
        }}
      >
        {player.rank}
      </div>

      {/* 頭像 - 小圓形 */}
      <div
        className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0 border-2"
        style={{
          backgroundColor: player.avatarBg,
          borderColor: player.isMe ? "#FFD700" : "#4a5090",
          boxShadow: player.isMe ? "0 0 10px rgba(255,215,0,0.4)" : undefined,
        }}
      >
        {player.avatar}
      </div>

      {/* 名稱 + 稱號 */}
      <div className="flex-1 min-w-0">
        <p className={cn(
          "font-bold text-sm flex items-center gap-1",
          player.isMe ? "text-amber-400" : "text-white"
        )}>
          {player.name}
          {player.isMe && <span className="text-cyan-400 text-xs">⭐</span>}
        </p>
        <p className="text-xs text-amber-200/50 truncate">{player.title}</p>
      </div>

      {/* 連勝 - 小螢幕隱藏 */}
      <div className="hidden sm:flex items-center gap-0.5 flex-shrink-0 min-w-[50px]">
        <span className="text-orange-400 text-sm">🔥</span>
        <span className="text-orange-300 text-xs font-medium">{player.streak}天</span>
      </div>

      {/* XP */}
      <div className="flex items-center gap-1 flex-shrink-0 min-w-[70px] sm:min-w-[80px] justify-end">
        <span className="text-amber-400 font-bold text-sm">{player.xp.toLocaleString()}</span>
        <span className="text-amber-200/40 text-xs hidden sm:inline">XP</span>
      </div>

      {/* 排名變化 */}
      <div className="flex-shrink-0 min-w-[40px] sm:min-w-[48px] flex justify-end">
        <RankChange change={player.change} />
      </div>
    </div>
  );
}

// 我的排名卡片 - 符合參考圖設計
function MyRankCard() {
  const me = LEADERBOARD.find(p => p.isMe);
  if (!me || me.rank <= 3) return null;

  return (
    <div>
      <h3 className="text-amber-400 font-bold mb-2 text-center tracking-wider">
        MY RANK CARD
      </h3>
      <div
        className="rounded-xl p-3 border-2 border-amber-400"
        style={{
          background: "linear-gradient(180deg, rgba(255,215,0,0.15) 0%, rgba(255,165,0,0.08) 100%)",
          boxShadow: "0 0 25px rgba(255,215,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1)",
        }}
      >
        <div className="flex items-center gap-3">
          {/* 排名框 */}
          <div
            className="flex flex-col items-center justify-center px-3 py-2 rounded-lg"
            style={{
              background: "linear-gradient(180deg, #2a3a6a 0%, #1a2a4a 100%)",
              border: "2px solid #4a5090",
            }}
          >
            <p className="text-[10px] text-amber-200/60">第</p>
            <p className="text-2xl font-black text-amber-400">{me.rank}</p>
            <p className="text-[10px] text-amber-200/60">位</p>
          </div>

          {/* 頭像 */}
          <div
            className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl border-2 border-amber-400"
            style={{ backgroundColor: me.avatarBg }}
          >
            {me.avatar}
          </div>

          {/* 資訊 */}
          <div className="flex-1 min-w-0">
            <p className="font-bold text-amber-400 flex items-center gap-1">
              {me.name} <span className="text-cyan-400">⭐</span>
            </p>
            <p className="text-xs text-amber-200/60">{me.title}</p>
            <div className="flex items-center gap-1 mt-0.5">
              <span className="text-orange-400 text-sm">🔥</span>
              <span className="text-orange-300 text-xs">{me.streak}天</span>
            </div>
          </div>

          {/* XP 區 */}
          <div className="text-right flex-shrink-0">
            <div className="text-amber-400 text-sm mb-0.5">👑</div>
            <p className="text-xl font-black text-amber-400">{me.xp.toLocaleString()}</p>
            <p className="text-[10px] text-amber-200/40">XP</p>
            <RankChange change={me.change} />
          </div>
        </div>
      </div>
    </div>
  );
}

// 排行榜頁面 - 雙欄佈局：左邊篩選+列表，右邊頒獎台+我的卡片
function LeaderboardPage() {
  const [period, setPeriod] = useState<"weekly" | "monthly" | "all">("weekly");
  const [metric, setMetric] = useState<"xp" | "accuracy" | "streak">("xp");

  return (
    <div className="p-4 max-w-5xl mx-auto">
      {/* 雙欄佈局 - 桌面：左列表右頒獎台，手機：頒獎台在上 */}
      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">

        {/* 右欄（手機時在上）：頒獎台 + 我的排名卡 */}
        <div className="lg:w-[380px] lg:flex-shrink-0 lg:order-2 order-1 space-y-4">
          <Podium />
          <MyRankCard />
        </div>

        {/* 左欄（手機時在下）：篩選器 + 列表 */}
        <div className="flex-1 lg:order-1 order-2">
          {/* 篩選器 - 時間 */}
          <div className="flex flex-wrap gap-2 mb-2">
            <GoldButton active={period === "weekly"} onClick={() => setPeriod("weekly")} className="text-sm px-3 py-1.5">
              📅 本週
            </GoldButton>
            <GoldButton active={period === "monthly"} onClick={() => setPeriod("monthly")} className="text-sm px-3 py-1.5">
              📆 本月
            </GoldButton>
            <GoldButton active={period === "all"} onClick={() => setPeriod("all")} className="text-sm px-3 py-1.5">
              🏆 全部
            </GoldButton>
          </div>

          {/* 篩選器 - 指標 */}
          <div className="flex flex-wrap gap-2 mb-3">
            <GoldButton active={metric === "xp"} onClick={() => setMetric("xp")} className="text-sm px-3 py-1.5">
              ⚡ 經驗值
            </GoldButton>
            <GoldButton active={metric === "accuracy"} onClick={() => setMetric("accuracy")} className="text-sm px-3 py-1.5">
              🎯 準確率
            </GoldButton>
            <GoldButton active={metric === "streak"} onClick={() => setMetric("streak")} className="text-sm px-3 py-1.5">
              🔥 連續天數
            </GoldButton>
          </div>

          {/* 排行列表 */}
          <div>
            {LEADERBOARD.map((player) => (
              <LeaderboardRow key={player.rank} player={player} />
            ))}
          </div>
        </div>
      </div>

      {/* 底部激勵 */}
      <p className="text-center text-amber-200/50 text-xs mt-4">
        重要的不是名次，而是每天比昨天更好！
      </p>
    </div>
  );
}

// ============================================
// 商店元件
// ============================================

function ShopItem({ item }: { item: typeof SHOP_ITEMS[0] }) {
  return (
    <GoldCard className="relative overflow-hidden">
      {/* 庫存標記 */}
      {item.stock <= 3 && (
        <div className="absolute top-2 right-2 px-2 py-0.5 bg-red-500 rounded-full text-xs font-bold text-white">
          剩 {item.stock}
        </div>
      )}

      <div className="flex items-center gap-4">
        {/* 圖示 */}
        <div
          className="w-16 h-16 rounded-xl flex items-center justify-center text-3xl"
          style={{
            background: "linear-gradient(135deg, rgba(255,215,0,0.2) 0%, rgba(255,165,0,0.1) 100%)",
            border: "2px solid rgba(255,215,0,0.3)",
          }}
        >
          {item.icon}
        </div>

        {/* 資訊 */}
        <div className="flex-1">
          <h3 className="font-bold text-white">{item.name}</h3>
          <p className="text-sm text-amber-200/60">{item.desc}</p>
        </div>

        {/* 價格 & 購買 */}
        <button
          className="px-4 py-2 rounded-xl font-bold transition-all"
          style={{
            background: "linear-gradient(180deg, #FFD700 0%, #FFA500 100%)",
            color: "#92400E",
          }}
        >
          <div className="flex items-center gap-1">
            <span>🪙</span>
            <span>{item.price}</span>
          </div>
        </button>
      </div>
    </GoldCard>
  );
}

function ShopPage() {
  return (
    <div className="p-4">
      {/* 商店標題 */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-black text-amber-400 flex items-center gap-2">
          🛒 神秘商店
        </h2>
        <div
          className="px-4 py-2 rounded-full flex items-center gap-2 font-bold"
          style={{
            background: "linear-gradient(180deg, rgba(255,215,0,0.2) 0%, rgba(255,165,0,0.1) 100%)",
            border: "2px solid rgba(255,215,0,0.3)",
          }}
        >
          <span>🪙</span>
          <span className="text-amber-400">340</span>
        </div>
      </div>

      {/* 商品列表 */}
      <div className="space-y-3">
        {SHOP_ITEMS.map((item) => (
          <ShopItem key={item.id} item={item} />
        ))}
      </div>

      {/* 底部提示 */}
      <p className="text-center text-amber-200/60 text-sm mt-6">
        金幣可透過完成任務和每日簽到獲得！
      </p>
    </div>
  );
}

// ============================================
// 徽章元件
// ============================================

function BadgeCard({ badge }: { badge: typeof BADGES[0] }) {
  const tier = TIERS[badge.tier as keyof typeof TIERS];
  const isEarned = badge.earned;

  return (
    <GoldCard
      className={cn(!isEarned && "opacity-60")}
      highlight={isEarned}
      glow={isEarned && badge.tier === "legendary"}
    >
      <div className="flex items-center gap-4">
        {/* 圖示 */}
        <div
          className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl relative"
          style={{
            background: isEarned
              ? `linear-gradient(135deg, ${tier.color}30 0%, ${tier.color}10 100%)`
              : "rgba(74,80,144,0.3)",
            border: `2px solid ${isEarned ? tier.color : "#4a5090"}`,
            boxShadow: isEarned ? tier.glow : "none",
          }}
        >
          {badge.secret && !isEarned ? "❓" : badge.icon}
          {isEarned && (
            <div
              className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs"
              style={{ backgroundColor: tier.color }}
            >
              ✓
            </div>
          )}
        </div>

        {/* 資訊 */}
        <div className="flex-1">
          <h3 className={cn(
            "font-bold",
            isEarned ? "text-white" : "text-gray-400"
          )}>
            {badge.secret && !isEarned ? "???" : badge.name}
          </h3>
          <p className="text-sm text-amber-200/60">{badge.desc}</p>

          {/* 進度條 */}
          {!isEarned && !badge.secret && badge.progress !== undefined && (
            <div className="mt-2">
              <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${badge.progress}%`,
                    background: "linear-gradient(90deg, #FFD700 0%, #FFA500 100%)",
                  }}
                />
              </div>
              <p className="text-xs text-amber-200/40 mt-1">{badge.progress}%</p>
            </div>
          )}
        </div>

        {/* XP 獎勵 */}
        <div
          className="px-3 py-1 rounded-full text-sm font-bold"
          style={{
            background: "rgba(255,215,0,0.15)",
            color: COLORS.gold,
          }}
        >
          +{badge.xp} XP
        </div>
      </div>
    </GoldCard>
  );
}

function BadgesPage() {
  const earned = BADGES.filter(b => b.earned).length;

  return (
    <div className="p-4">
      {/* 標題 */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-black text-amber-400 flex items-center gap-2">
          🏅 成就收藏
        </h2>
        <div
          className="px-4 py-2 rounded-full font-bold"
          style={{
            background: "linear-gradient(180deg, rgba(255,215,0,0.2) 0%, rgba(255,165,0,0.1) 100%)",
            border: "2px solid rgba(255,215,0,0.3)",
            color: COLORS.gold,
          }}
        >
          {earned}/{BADGES.length}
        </div>
      </div>

      {/* 稀有度統計 */}
      <div className="flex gap-2 mb-6">
        {Object.entries(TIERS).map(([key, tier]) => {
          const count = BADGES.filter(b => b.tier === key && b.earned).length;
          return (
            <div
              key={key}
              className="flex-1 py-2 rounded-xl text-center text-sm"
              style={{
                background: `${tier.color}15`,
                border: `1px solid ${tier.color}40`,
              }}
            >
              <span style={{ color: tier.color }}>{count}</span>
            </div>
          );
        })}
      </div>

      {/* 徽章列表 */}
      <div className="space-y-3">
        {BADGES.map((badge) => (
          <BadgeCard key={badge.id} badge={badge} />
        ))}
      </div>
    </div>
  );
}

// ============================================
// 主元件
// ============================================

export function GameUI() {
  const [tab, setTab] = useState<"leaderboard" | "shop" | "badges">("leaderboard");
  const me = LEADERBOARD.find(p => p.isMe);

  return (
    <div
      className="min-h-screen"
      style={{ background: COLORS.bgGradient }}
    >
      {/* 背景裝飾 */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-20 left-10 w-40 h-40 rounded-full opacity-20" style={{ background: "radial-gradient(circle, #4169E1 0%, transparent 70%)" }} />
        <div className="absolute bottom-40 right-10 w-60 h-60 rounded-full opacity-15" style={{ background: "radial-gradient(circle, #9932CC 0%, transparent 70%)" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full opacity-10" style={{ background: "radial-gradient(circle, #FFD700 0%, transparent 70%)" }} />
      </div>

      {/* Header */}
      <header className="relative z-10 p-4">
        <GoldCard>
          <div className="flex items-center justify-between">
            {/* 玩家資訊 */}
            <div className="flex items-center gap-3">
              <Avatar emoji={me?.avatar || "🐱"} bg={me?.avatarBg || "#B0E0E6"} size="lg" highlight />
              <div>
                <h1 className="text-xl font-black text-white">{me?.name || "冒險者"}</h1>
                <p className="text-sm text-amber-200/60">{me?.title || "知識探索家"}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-amber-400 text-sm font-bold">Lv.5</span>
                  <span className="text-amber-200/40">•</span>
                  <span className="text-amber-300 text-sm">{me?.xp.toLocaleString() || "2,450"} XP</span>
                </div>
              </div>
            </div>

            {/* 資源 */}
            <div className="flex items-center gap-2">
              <div
                className="px-3 py-2 rounded-xl flex items-center gap-1.5"
                style={{
                  background: "linear-gradient(180deg, rgba(255,215,0,0.2) 0%, rgba(255,165,0,0.1) 100%)",
                  border: "2px solid rgba(255,215,0,0.3)",
                }}
              >
                <span className="text-xl">🪙</span>
                <span className="font-bold text-amber-400">340</span>
              </div>
              <div
                className="px-3 py-2 rounded-xl flex items-center gap-1.5"
                style={{
                  background: "linear-gradient(180deg, rgba(147,51,234,0.2) 0%, rgba(139,92,246,0.1) 100%)",
                  border: "2px solid rgba(147,51,234,0.3)",
                }}
              >
                <span className="text-xl">💎</span>
                <span className="font-bold text-purple-400">12</span>
              </div>
            </div>
          </div>
        </GoldCard>
      </header>

      {/* Tab 導航 */}
      <nav className="relative z-10 px-4 mb-4">
        <div className="flex gap-2">
          {[
            { key: "leaderboard" as const, label: "🏆 排行榜" },
            { key: "shop" as const, label: "🛒 商店" },
            { key: "badges" as const, label: "🏅 徽章" },
          ].map((t) => (
            <GoldButton
              key={t.key}
              active={tab === t.key}
              onClick={() => setTab(t.key)}
              className="flex-1"
            >
              {t.label}
            </GoldButton>
          ))}
        </div>
      </nav>

      {/* 內容區 */}
      <main className="relative z-10 pb-8">
        {tab === "leaderboard" && <LeaderboardPage />}
        {tab === "shop" && <ShopPage />}
        {tab === "badges" && <BadgesPage />}
      </main>
    </div>
  );
}

export default GameUI;
