/**
 * Demo Pages Index
 *
 * 這些頁面用於展示遊戲化系統的 UI 設計
 * 使用 Mock Data，不需要後端 API
 *
 * 路由配置範例:
 * { path: "demo/badges", element: <BadgesPageDemo /> }
 * { path: "demo/shop", element: <ShopPageDemo /> }
 * { path: "demo/leaderboard", element: <LeaderboardPageDemo /> }
 */

// 新的童趣版頁面
export { BadgesPageDemo } from "./BadgesPageDemo";
export { ShopPageDemo } from "./ShopPageDemo";
export { LeaderboardPageDemo } from "./LeaderboardPageDemo";

// 舊版頁面（保留供參考）
export { GamificationDemoPage } from "./GamificationDemoPage";
export { GamificationShowcase } from "./GamificationShowcase";
