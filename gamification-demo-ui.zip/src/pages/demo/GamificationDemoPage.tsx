/**
 * Gamification Demo Page
 *
 * 遊戲化系統展示頁面，包含：
 * - 徽章展示
 * - 金幣商店
 * - 排行榜
 *
 * 路由: /:orgSlug/demo/gamification
 */

import { useState } from "react";
import {
  Award,
  ShoppingBag,
  Trophy,
  Lock,
  Check,
  Coins,
  TrendingUp,
  TrendingDown,
  Minus,
  User,
  Flame,
  Target,
  Star,
  Heart,
  Zap,
  Sparkles,
} from "lucide-react";
import { cn } from "../../lib/utils";

// ============================================
// Mock Data
// ============================================

const MOCK_PROFILE = {
  student_id: "demo_student",
  total_xp: 1250,
  current_coins: 340,
  level: 5,
  level_title_key: "explorer",
  current_xp: 50,
  xp_to_next_level: 300,
  current_streak: 7,
};

const MOCK_BADGES = [
  {
    badge_id: "badge_streak_7",
    name: "七日勇士",
    description: "連續登入 7 天",
    tier: "bronze" as const,
    is_earned: true,
    earned_at: "2025-12-05T10:00:00Z",
    xp_reward: 50,
    coin_reward: 20,
    is_secret: false,
    progress: null,
    icon: "flame",
  },
  {
    badge_id: "badge_streak_14",
    name: "雙週達人",
    description: "連續登入 14 天",
    tier: "silver" as const,
    is_earned: false,
    earned_at: null,
    xp_reward: 100,
    coin_reward: 50,
    is_secret: false,
    progress: { current: 7, target: 14, percentage: 50 },
    icon: "flame",
  },
  {
    badge_id: "badge_tasks_100",
    name: "學習達人",
    description: "完成 100 個任務",
    tier: "silver" as const,
    is_earned: true,
    earned_at: "2025-11-20T14:30:00Z",
    xp_reward: 75,
    coin_reward: 30,
    is_secret: false,
    progress: null,
    icon: "target",
  },
  {
    badge_id: "badge_perfect_score",
    name: "滿分達人",
    description: "首次考試滿分",
    tier: "gold" as const,
    is_earned: true,
    earned_at: "2025-12-01T09:15:00Z",
    xp_reward: 150,
    coin_reward: 75,
    is_secret: false,
    progress: null,
    icon: "star",
  },
  {
    badge_id: "badge_honest_20",
    name: "誠實達人",
    description: "20 次無猜題考試",
    tier: "silver" as const,
    is_earned: false,
    earned_at: null,
    xp_reward: 75,
    coin_reward: 30,
    is_secret: false,
    progress: { current: 12, target: 20, percentage: 60 },
    icon: "heart",
  },
  {
    badge_id: "badge_combo_50",
    name: "傳說連勝",
    description: "連續 50 題正確",
    tier: "gold" as const,
    is_earned: false,
    earned_at: null,
    xp_reward: 150,
    coin_reward: 75,
    is_secret: false,
    progress: { current: 23, target: 50, percentage: 46 },
    icon: "zap",
  },
];

const MOCK_SHOP_ITEMS = [
  {
    item_id: "frame_starter",
    name: "基礎框",
    category: "avatar_frame",
    preview_color: "#E8E8E8",
    coin_price: 0,
    unlock_level: 1,
    is_owned: true,
    is_equipped: false,
  },
  {
    item_id: "frame_bronze_star",
    name: "銅星框",
    category: "avatar_frame",
    preview_color: "#CD7F32",
    coin_price: 50,
    unlock_level: 3,
    is_owned: true,
    is_equipped: true,
  },
  {
    item_id: "frame_silver_wave",
    name: "銀波框",
    category: "avatar_frame",
    preview_color: "#C0C0C0",
    coin_price: 150,
    unlock_level: 5,
    is_owned: false,
    is_equipped: false,
  },
  {
    item_id: "frame_gold_crown",
    name: "金冠框",
    category: "avatar_frame",
    preview_color: "#FFD700",
    coin_price: 300,
    unlock_level: 8,
    is_owned: false,
    is_equipped: false,
  },
];

const MOCK_LEADERBOARD = [
  { position: 1, name: "小明", value: 850, change: 2, color: "#FFB6C1" },
  { position: 2, name: "小華", value: 720, change: -1, color: "#87CEEB" },
  { position: 3, name: "小芳", value: 680, change: 1, color: "#98FB98" },
  { position: 4, name: "小美", value: 560, change: 0, color: "#DDA0DD" },
  { position: 5, name: "你", value: 520, change: 3, color: "#F0E68C", isCurrentUser: true },
  { position: 6, name: "小玲", value: 480, change: -2, color: "#E6E6FA" },
];

// ============================================
// Style Constants
// ============================================

const TIER_COLORS = {
  bronze: "from-[#CD7F32] to-[#B87333]",
  silver: "from-[#C0C0C0] to-[#A8A8A8]",
  gold: "from-[#FFD700] to-[#FFC107]",
  diamond: "from-[#B9F2FF] via-[#FFB6C1] to-[#DDA0DD]",
};

const TIER_BG = {
  bronze: "bg-gradient-to-br from-[#FDF5E6] to-[#FFE4B5]",
  silver: "bg-gradient-to-br from-[#F5F5F5] to-[#E8E8E8]",
  gold: "bg-gradient-to-br from-[#FFFAF0] to-[#FFF8DC]",
  diamond: "bg-gradient-to-br from-[#F0FFFF] to-[#E6E6FA]",
};

// ============================================
// Component
// ============================================

type Tab = "badges" | "shop" | "leaderboard";

export function GamificationDemoPage() {
  const [activeTab, setActiveTab] = useState<Tab>("badges");
  const [selectedBadge, setSelectedBadge] = useState<typeof MOCK_BADGES[0] | null>(null);

  const tabs = [
    { key: "badges" as Tab, label: "徽章", icon: Award },
    { key: "shop" as Tab, label: "商店", icon: ShoppingBag },
    { key: "leaderboard" as Tab, label: "排行榜", icon: Trophy },
  ];

  const earnedBadges = MOCK_BADGES.filter((b) => b.is_earned).length;

  const getBadgeIcon = (iconName: string) => {
    const icons: Record<string, React.ReactNode> = {
      flame: <Flame className="w-full h-full text-white p-3" />,
      target: <Target className="w-full h-full text-white p-3" />,
      star: <Star className="w-full h-full text-white p-3" />,
      heart: <Heart className="w-full h-full text-white p-3" />,
      zap: <Zap className="w-full h-full text-white p-3" />,
    };
    return icons[iconName] || <Award className="w-full h-full text-white p-3" />;
  };

  const renderChangeIndicator = (change: number) => {
    if (change > 0) {
      return (
        <span className="flex items-center gap-0.5 text-[oklch(0.55_0.15_145)] text-sm">
          <TrendingUp className="w-4 h-4" />
          {change}
        </span>
      );
    } else if (change < 0) {
      return (
        <span className="flex items-center gap-0.5 text-[oklch(0.60_0.18_25)] text-sm">
          <TrendingDown className="w-4 h-4" />
          {Math.abs(change)}
        </span>
      );
    }
    return (
      <span className="flex items-center gap-0.5 text-[oklch(0.60_0.02_60)] text-sm">
        <Minus className="w-4 h-4" />
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[oklch(0.99_0.005_65)] to-[oklch(0.97_0.01_60)]">
      {/* Header */}
      <div className="bg-white border-b border-[oklch(0.94_0.01_65)] sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          {/* Profile Summary */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[oklch(0.70_0.12_185)] to-[oklch(0.62_0.14_180)] flex items-center justify-center border-3 border-[oklch(0.60_0.14_180)]">
                <User className="w-7 h-7 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-lg text-[oklch(0.30_0.02_30)]">
                    Lv.{MOCK_PROFILE.level}
                  </span>
                  <span className="text-[oklch(0.50_0.02_30)]">知識探索家</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-[oklch(0.90_0.02_180)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[oklch(0.70_0.14_180)] to-[oklch(0.60_0.16_175)] rounded-full"
                      style={{ width: `${(MOCK_PROFILE.current_xp / MOCK_PROFILE.xp_to_next_level) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs text-[oklch(0.50_0.02_30)]">
                    {MOCK_PROFILE.current_xp}/{MOCK_PROFILE.xp_to_next_level} XP
                  </span>
                </div>
              </div>
            </div>

            {/* Coins */}
            <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[oklch(0.94_0.06_45)] to-[oklch(0.92_0.08_40)] rounded-full">
              <Coins className="w-5 h-5 text-[oklch(0.60_0.15_45)]" />
              <span className="font-bold text-[oklch(0.50_0.12_45)]">
                {MOCK_PROFILE.current_coins}
              </span>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={cn(
                  "flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold transition-all",
                  activeTab === tab.key
                    ? "bg-gradient-to-r from-[oklch(0.70_0.12_185)] to-[oklch(0.62_0.14_180)] text-white shadow-lg"
                    : "bg-[oklch(0.95_0.01_60)] text-[oklch(0.40_0.02_30)] hover:bg-[oklch(0.90_0.02_60)]"
                )}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Badges Tab */}
        {activeTab === "badges" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-[oklch(0.25_0.03_25)]">
                我的徽章
              </h2>
              <span className="text-[oklch(0.50_0.03_35)]">
                已獲得 {earnedBadges}/{MOCK_BADGES.length}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {MOCK_BADGES.map((badge) => (
                <button
                  key={badge.badge_id}
                  onClick={() => setSelectedBadge(badge)}
                  className={cn(
                    "relative p-4 rounded-2xl transition-all hover:scale-105",
                    badge.is_earned
                      ? cn(TIER_BG[badge.tier], "shadow-lg")
                      : "bg-white/80 opacity-70 shadow-md"
                  )}
                >
                  <div
                    className={cn(
                      "absolute top-2 right-2 w-3 h-3 rounded-full bg-gradient-to-br",
                      TIER_COLORS[badge.tier]
                    )}
                  />

                  <div className="relative w-16 h-16 mx-auto mb-3">
                    {badge.is_earned ? (
                      <div className={cn(
                        "w-full h-full rounded-full flex items-center justify-center bg-gradient-to-br",
                        TIER_COLORS[badge.tier]
                      )}>
                        {getBadgeIcon(badge.icon)}
                      </div>
                    ) : (
                      <div className="relative w-full h-full">
                        <div className={cn(
                          "w-full h-full rounded-full flex items-center justify-center bg-gradient-to-br opacity-30",
                          TIER_COLORS[badge.tier]
                        )}>
                          {getBadgeIcon(badge.icon)}
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Lock className="w-6 h-6 text-[oklch(0.50_0.02_30)]" />
                        </div>
                      </div>
                    )}
                  </div>

                  <p className={cn(
                    "text-sm font-semibold text-center truncate",
                    badge.is_earned ? "text-[oklch(0.30_0.02_30)]" : "text-[oklch(0.50_0.02_30)]"
                  )}>
                    {badge.name}
                  </p>

                  {!badge.is_earned && badge.progress && (
                    <div className="mt-2">
                      <div className="w-full h-1.5 bg-white/50 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[oklch(0.70_0.12_185)] rounded-full"
                          style={{ width: `${badge.progress.percentage}%` }}
                        />
                      </div>
                      <p className="text-xs text-[oklch(0.50_0.02_30)] text-center mt-1">
                        {badge.progress.current}/{badge.progress.target}
                      </p>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Shop Tab */}
        {activeTab === "shop" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-[oklch(0.25_0.03_25)]">
              頭像框商店
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {MOCK_SHOP_ITEMS.map((item) => {
                const isUnlocked = MOCK_PROFILE.level >= item.unlock_level;
                const canAfford = MOCK_PROFILE.current_coins >= item.coin_price;

                return (
                  <div
                    key={item.item_id}
                    className={cn(
                      "relative p-4 rounded-2xl transition-all",
                      item.is_owned
                        ? "bg-gradient-to-br from-[oklch(0.98_0.01_180)] to-[oklch(0.96_0.02_175)] border-2 border-[oklch(0.70_0.12_185)]"
                        : isUnlocked
                        ? "bg-white shadow-lg hover:shadow-xl hover:scale-105"
                        : "bg-white/60 opacity-60"
                    )}
                  >
                    {item.is_equipped && (
                      <div className="absolute top-2 right-2 w-5 h-5 bg-[oklch(0.70_0.12_185)] rounded-full flex items-center justify-center">
                        <Check className="w-3 h-3 text-white" />
                      </div>
                    )}

                    <div
                      className="w-16 h-16 mx-auto mb-3 rounded-xl flex items-center justify-center"
                      style={{ background: item.preview_color }}
                    >
                      <div className="w-10 h-10 rounded-full border-3 border-white/50 bg-white/30" />
                    </div>

                    <p className="text-sm font-semibold text-center text-[oklch(0.30_0.02_30)] mb-2">
                      {item.name}
                    </p>

                    {item.is_owned ? (
                      <div className="text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-[oklch(0.70_0.12_185)] text-white rounded-full text-xs">
                          <Check className="w-3 h-3" />
                          已擁有
                        </span>
                      </div>
                    ) : !isUnlocked ? (
                      <div className="text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-[oklch(0.90_0.01_60)] text-[oklch(0.50_0.02_30)] rounded-full text-xs">
                          <Lock className="w-3 h-3" />
                          Lv.{item.unlock_level}
                        </span>
                      </div>
                    ) : (
                      <button
                        disabled={!canAfford}
                        className={cn(
                          "w-full py-2 rounded-full text-xs font-semibold transition-all",
                          canAfford
                            ? "bg-gradient-to-r from-[oklch(0.80_0.10_70)] to-[oklch(0.70_0.12_60)] text-white"
                            : "bg-[oklch(0.92_0.01_60)] text-[oklch(0.50_0.02_30)] cursor-not-allowed"
                        )}
                      >
                        <span className="flex items-center justify-center gap-1">
                          <Coins className="w-3 h-3" />
                          {item.coin_price}
                        </span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Leaderboard Tab */}
        {activeTab === "leaderboard" && (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-xl font-bold text-[oklch(0.25_0.03_25)] mb-1">
                本週排行榜
              </h2>
              <p className="text-sm text-[oklch(0.50_0.03_35)]">
                2025/12/09 - 2025/12/15
              </p>
            </div>

            {/* Top 3 */}
            <div className="flex justify-center items-end gap-3">
              {/* 2nd */}
              <div className="text-center">
                <div
                  className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-1"
                  style={{ background: MOCK_LEADERBOARD[1].color }}
                >
                  <User className="w-6 h-6 text-white" />
                </div>
                <p className="text-sm font-medium">{MOCK_LEADERBOARD[1].name}</p>
                <p className="text-xs text-[oklch(0.50_0.03_35)]">{MOCK_LEADERBOARD[1].value} XP</p>
                <div className="w-14 h-16 mx-auto mt-1 bg-gradient-to-t from-[#C0C0C0] to-[#E8E8E8] rounded-t-lg flex items-end justify-center pb-1">
                  <span className="text-lg">🥈</span>
                </div>
              </div>

              {/* 1st */}
              <div className="text-center -mt-4">
                <div
                  className="w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-1"
                  style={{ background: MOCK_LEADERBOARD[0].color }}
                >
                  <User className="w-7 h-7 text-white" />
                </div>
                <p className="text-sm font-bold">{MOCK_LEADERBOARD[0].name}</p>
                <p className="text-xs text-[oklch(0.50_0.03_35)]">{MOCK_LEADERBOARD[0].value} XP</p>
                <div className="w-16 h-20 mx-auto mt-1 bg-gradient-to-t from-[#FFD700] to-[#FFF8DC] rounded-t-lg flex items-end justify-center pb-1">
                  <span className="text-xl">🥇</span>
                </div>
              </div>

              {/* 3rd */}
              <div className="text-center">
                <div
                  className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-1"
                  style={{ background: MOCK_LEADERBOARD[2].color }}
                >
                  <User className="w-6 h-6 text-white" />
                </div>
                <p className="text-sm font-medium">{MOCK_LEADERBOARD[2].name}</p>
                <p className="text-xs text-[oklch(0.50_0.03_35)]">{MOCK_LEADERBOARD[2].value} XP</p>
                <div className="w-14 h-12 mx-auto mt-1 bg-gradient-to-t from-[#CD7F32] to-[#DEB887] rounded-t-lg flex items-end justify-center pb-1">
                  <span className="text-lg">🥉</span>
                </div>
              </div>
            </div>

            {/* Rest of list */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              {MOCK_LEADERBOARD.slice(3).map((entry, idx) => (
                <div
                  key={entry.position}
                  className={cn(
                    "flex items-center justify-between p-3",
                    idx < MOCK_LEADERBOARD.slice(3).length - 1 && "border-b border-[oklch(0.95_0.01_60)]",
                    entry.isCurrentUser && "bg-[oklch(0.98_0.01_180)]"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-center font-bold text-[oklch(0.50_0.02_30)]">
                      {entry.position}
                    </span>
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center"
                      style={{ background: entry.color }}
                    >
                      <User className="w-4 h-4 text-white" />
                    </div>
                    <span className={cn(
                      "font-medium text-sm",
                      entry.isCurrentUser ? "text-[oklch(0.70_0.12_185)] font-bold" : "text-[oklch(0.30_0.02_30)]"
                    )}>
                      {entry.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-sm text-[oklch(0.35_0.02_30)]">
                      {entry.value} XP
                    </span>
                    {renderChangeIndicator(entry.change)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Badge Detail Modal */}
      {selectedBadge && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedBadge(null)}
        >
          <div
            className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className={cn(
              "w-24 h-24 mx-auto mb-4 rounded-full flex items-center justify-center bg-gradient-to-br",
              selectedBadge.is_earned ? TIER_COLORS[selectedBadge.tier] : "from-gray-300 to-gray-400"
            )}>
              {getBadgeIcon(selectedBadge.icon)}
            </div>

            <div className="text-center mb-4">
              <span className={cn(
                "inline-block px-2 py-0.5 rounded-full text-xs font-semibold mb-2 bg-gradient-to-r text-white",
                TIER_COLORS[selectedBadge.tier]
              )}>
                {selectedBadge.tier.charAt(0).toUpperCase() + selectedBadge.tier.slice(1)}
              </span>
              <h3 className="text-xl font-bold text-[oklch(0.25_0.03_25)]">
                {selectedBadge.name}
              </h3>
              <p className="text-sm text-[oklch(0.50_0.03_35)]">
                {selectedBadge.description}
              </p>
            </div>

            <div className="flex justify-center gap-3 mb-4">
              <div className="flex items-center gap-1 px-3 py-1.5 bg-[oklch(0.94_0.06_55)] rounded-full">
                <Sparkles className="w-4 h-4 text-[oklch(0.60_0.15_50)]" />
                <span className="text-sm font-bold text-[oklch(0.50_0.12_50)]">
                  +{selectedBadge.xp_reward} XP
                </span>
              </div>
              <div className="flex items-center gap-1 px-3 py-1.5 bg-[oklch(0.94_0.06_45)] rounded-full">
                <Coins className="w-4 h-4 text-[oklch(0.60_0.15_45)]" />
                <span className="text-sm font-bold text-[oklch(0.50_0.12_45)]">
                  +{selectedBadge.coin_reward}
                </span>
              </div>
            </div>

            {selectedBadge.is_earned ? (
              <p className="text-center text-sm text-[oklch(0.50_0.03_35)]">
                獲得於 {new Date(selectedBadge.earned_at!).toLocaleDateString("zh-TW")}
              </p>
            ) : selectedBadge.progress ? (
              <div>
                <div className="w-full h-2 bg-[oklch(0.92_0.01_60)] rounded-full overflow-hidden mb-1">
                  <div
                    className="h-full bg-gradient-to-r from-[oklch(0.70_0.12_185)] to-[oklch(0.62_0.14_180)] rounded-full"
                    style={{ width: `${selectedBadge.progress.percentage}%` }}
                  />
                </div>
                <p className="text-center text-sm text-[oklch(0.50_0.03_35)]">
                  進度: {selectedBadge.progress.current}/{selectedBadge.progress.target}
                </p>
              </div>
            ) : null}

            <button
              onClick={() => setSelectedBadge(null)}
              className="w-full mt-4 py-2.5 rounded-full font-semibold text-[oklch(0.40_0.02_30)] bg-[oklch(0.95_0.01_60)] hover:bg-[oklch(0.90_0.02_60)]"
            >
              關閉
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default GamificationDemoPage;
