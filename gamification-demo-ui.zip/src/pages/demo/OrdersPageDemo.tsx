/**
 * 訂單頁面 - Tiffany/Teal Theme
 * 顯示學生的兌換訂單和兌換碼
 */

import { useState } from "react";
import { Package, Clock, Check, Copy, ChevronRight, Gift, AlertCircle, Zap } from "lucide-react";
import { cn } from "../../lib/utils";
import type { Order } from "../../types/gamification";
import { MOCK_ORDERS, formatDateTime, getStatusText, getStatusColor } from "../../data/mockData";

// ============================================
// Order Card Component
// ============================================

function OrderCard({ order }: { order: Order }) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (order.redemptionCode) {
      await navigator.clipboard.writeText(order.redemptionCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const isPending = order.status === "ready";
  const isPhysical = order.rewardType === "physical";

  return (
    <div
      className={cn(
        "card transition-all duration-300 border-2",
        isPending ? "border-tier-gold/30" : "border-transparent",
        expanded && "shadow-lg"
      )}
    >
      {/* Header */}
      <div
        className="flex items-center gap-3 p-4 cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        {/* Emoji */}
        <div
          className={cn(
            "w-14 h-14 rounded-xl flex items-center justify-center text-2xl",
            isPending
              ? "bg-tier-gold/10 border border-tier-gold/20"
              : "bg-surface-elevated"
          )}
        >
          {order.rewardEmoji}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <p className="font-display text-text-primary truncate">{order.rewardName}</p>
            <span
              className={cn(
                "px-2 py-0.5 rounded-full text-[10px] font-display",
                getStatusColor(order.status)
              )}
            >
              {getStatusText(order.status)}
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs text-text-muted">
            <span>{formatDateTime(order.createdAt)}</span>
            {order.shopType === "organization" && (
              <span className="px-1.5 py-0.5 bg-tiffany-50 text-tiffany-600 rounded text-[10px]">
                {order.organizationName}
              </span>
            )}
          </div>
        </div>

        {/* Expand Icon */}
        <ChevronRight
          className={cn(
            "w-5 h-5 text-text-muted transition-transform",
            expanded && "rotate-90"
          )}
        />
      </div>

      {/* Expanded Content */}
      {expanded && (
        <div className="px-4 pb-4 pt-0 border-t border-surface-border space-y-3 animate-fade-in">
          <div className="pt-3">
            {/* Price */}
            <div className="flex justify-between text-sm">
              <span className="text-text-secondary">消費{order.currencyType === 'xp' ? '經驗值' : '金幣'}</span>
              <span className={cn(
                "font-display flex items-center gap-1",
                order.currencyType === 'xp' ? "text-tiffany-600" : "text-tier-gold"
              )}>
                {order.currencyType === 'xp' ? <Zap className="w-4 h-4" /> : '🪙'} {order.currencySpent.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Redemption Code */}
          {isPhysical && order.redemptionCode && (
            <div className="bg-tier-gold-bg rounded-xl p-3 border border-tier-gold/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-text-muted mb-1">兌換碼</p>
                  <code className="text-lg font-mono font-bold text-tier-gold">
                    {order.redemptionCode}
                  </code>
                </div>
                <button
                  onClick={handleCopy}
                  className={cn(
                    "flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-display transition-all cursor-pointer",
                    copied
                      ? "bg-accent-mint text-white"
                      : "bg-tier-gold/20 text-tier-gold hover:bg-tier-gold/30"
                  )}
                >
                  <Copy className="w-3 h-3" />
                  {copied ? "已複製" : "複製"}
                </button>
              </div>
            </div>
          )}

          {/* Instructions */}
          {isPhysical && order.redemptionInstructions && (
            <div className="bg-surface-elevated rounded-xl p-3 border border-surface-border">
              <p className="text-xs text-text-muted mb-1">領取說明</p>
              <p className="text-sm text-text-secondary">{order.redemptionInstructions}</p>
            </div>
          )}

          {/* Expiry */}
          {isPending && order.expiresAt && (
            <div className="flex items-center gap-2 text-xs text-accent-coral">
              <AlertCircle className="w-3 h-3" />
              <span>
                請於 {formatDateTime(order.expiresAt)} 前領取
              </span>
            </div>
          )}

          {/* Completed Info */}
          {order.status === "completed" && order.completedAt && (
            <div className="flex items-center gap-2 text-xs text-accent-mint">
              <Check className="w-3 h-3" />
              <span>已於 {formatDateTime(order.completedAt)} 領取</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ============================================
// Empty State
// ============================================

function EmptyState() {
  return (
    <div className="text-center py-12">
      <div className="w-24 h-24 mx-auto mb-4 bg-surface-elevated rounded-full flex items-center justify-center">
        <Package className="w-12 h-12 text-text-muted" />
      </div>
      <h3 className="text-lg font-display text-text-primary mb-2">還沒有訂單</h3>
      <p className="text-text-muted text-sm">
        去商店逛逛，用金幣兌換酷炫道具吧！
      </p>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

export function OrdersPageDemo() {
  const [orders] = useState<Order[]>(MOCK_ORDERS);
  const [filter, setFilter] = useState<"all" | "pending" | "completed">("all");

  const pendingOrders = orders.filter((o) => o.status === "ready" || o.status === "pending");
  const completedOrders = orders.filter((o) => o.status === "completed");

  const filteredOrders =
    filter === "all"
      ? orders
      : filter === "pending"
        ? pendingOrders
        : completedOrders;

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="container-app py-4 md:py-6 space-y-4">
        {/* Header */}
        <div className="card p-4 md:p-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-gradient-to-br from-tiffany-500 to-accent-cyan flex items-center justify-center shadow-teal">
              <Package className="w-6 h-6 md:w-7 md:h-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-display text-text-primary">
                我的訂單
              </h1>
              <p className="text-text-muted text-xs md:text-sm">
                查看兌換記錄和兌換碼
              </p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="card p-3 border-2 border-tier-gold/20">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-tier-gold" />
              <span className="text-xs text-text-muted">待領取</span>
            </div>
            <p className="text-2xl font-display text-tier-gold">{pendingOrders.length}</p>
          </div>
          <div className="card p-3 border-2 border-accent-mint/20">
            <div className="flex items-center gap-2 mb-1">
              <Check className="w-4 h-4 text-accent-mint" />
              <span className="text-xs text-text-muted">已完成</span>
            </div>
            <p className="text-2xl font-display text-accent-mint">{completedOrders.length}</p>
          </div>
        </div>

        {/* Alert for pending orders */}
        {pendingOrders.length > 0 && (
          <div className="card p-3 border-2 border-tier-gold/30 bg-tier-gold-bg flex items-center gap-3">
            <div className="w-10 h-10 bg-tier-gold/20 rounded-full flex items-center justify-center flex-shrink-0">
              <Gift className="w-5 h-5 text-tier-gold" />
            </div>
            <div>
              <p className="font-display text-tier-gold text-sm">
                你有 {pendingOrders.length} 個獎品待領取！
              </p>
              <p className="text-text-secondary text-xs">
                記得去補習班櫃檯領取喔～
              </p>
            </div>
          </div>
        )}

        {/* Filter Tabs */}
        <div className="flex gap-2 justify-center">
          {[
            { key: "all" as const, label: "全部", count: orders.length },
            { key: "pending" as const, label: "待領取", count: pendingOrders.length },
            { key: "completed" as const, label: "已完成", count: completedOrders.length },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-display transition-all cursor-pointer border-2",
                filter === tab.key
                  ? "bg-gradient-to-r from-tiffany-500 to-accent-cyan text-white border-transparent shadow-teal"
                  : "bg-white text-text-secondary border-surface-border hover:border-tiffany-500/30"
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className={cn(
                  "ml-1.5 px-1.5 py-0.5 rounded-full text-[10px]",
                  filter === tab.key ? "bg-white/30" : "bg-surface-elevated"
                )}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Orders List */}
        <div className="space-y-3">
          {filteredOrders.length > 0 ? (
            filteredOrders.map((order, index) => (
              <div
                key={order.id}
                className="animate-fade-in-up"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <OrderCard order={order} />
              </div>
            ))
          ) : (
            <EmptyState />
          )}
        </div>

        {/* Tips */}
        <div className="text-center py-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 card">
            <span className="text-xl">💡</span>
            <p className="text-text-secondary text-xs md:text-sm">
              點擊訂單可展開查看兌換碼和領取說明
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrdersPageDemo;
