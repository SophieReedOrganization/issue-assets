/**
 * GamificationShowcase - 首頁 (2026 EduBaania Tiffany/Teal Theme)
 * Clean bento grid with teal aesthetics for Taiwan youth
 */

import { useState } from "react";
import {
  Award,
  Trophy,
  Flame,
  Gift,
  Calendar,
  Package,
  TrendingUp,
  TrendingDown,
  Check,
  Zap,
  Target,
  Star,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { MOCK_USER_PROFILE, MOCK_ORDERS, MOCK_BADGES, MOCK_LEADERBOARD } from "../../data/mockData";

// ============================================
// Hero Profile Card - Large Bento Item
// ============================================

function HeroProfileCard() {
  const xpPercent = (MOCK_USER_PROFILE.currentXp / MOCK_USER_PROFILE.xpToNextLevel) * 100;
  const earnedBadges = MOCK_BADGES.filter(b => b.earnedAt).length;

  return (
    <div className="card card-hover p-6 h-full relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-tiffany-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-accent-cyan/5 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10">
        {/* Avatar Section */}
        <div className="flex items-start gap-5 mb-6">
          <div className="relative">
            {/* Avatar with gradient border */}
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-tiffany-500 to-accent-cyan p-[3px] shadow-teal">
              <div className="w-full h-full rounded-2xl bg-white flex items-center justify-center">
                <span className="text-5xl">{MOCK_USER_PROFILE.avatarEmoji}</span>
              </div>
            </div>
            {/* Level Badge */}
            <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-xl bg-gradient-to-br from-tier-gold to-accent-orange flex items-center justify-center shadow-gold">
              <span className="text-sm font-display font-bold text-white">
                {MOCK_USER_PROFILE.level}
              </span>
            </div>
          </div>

          <div className="flex-1 pt-1">
            <h2 className="text-2xl font-display text-text-primary mb-1">
              {MOCK_USER_PROFILE.displayName}
            </h2>
            <p className="text-text-secondary text-sm mb-3">學習探險家</p>

            {/* XP Progress Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-text-secondary">經驗值進度</span>
                <span className="text-tiffany-600 font-medium">
                  {MOCK_USER_PROFILE.currentXp} / {MOCK_USER_PROFILE.xpToNextLevel} XP
                </span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${xpPercent}%` }} />
                <div className="progress-shimmer" />
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <StatBox
            icon={<Flame className="w-5 h-5" />}
            value={MOCK_USER_PROFILE.currentStreak || 0}
            label="連續登入"
            color="orange"
          />
          <StatBox
            icon={<Award className="w-5 h-5" />}
            value={earnedBadges}
            label="已獲徽章"
            color="teal"
          />
          <StatBox
            icon={<Target className="w-5 h-5" />}
            value={MOCK_USER_PROFILE.totalTasksCompleted}
            label="完成任務"
            color="purple"
          />
        </div>
      </div>
    </div>
  );
}

function StatBox({ icon, value, label, color }: {
  icon: React.ReactNode;
  value: number;
  label: string;
  color: "orange" | "purple" | "pink" | "gold" | "mint" | "teal";
}) {
  const colorClasses = {
    orange: "text-accent-orange bg-accent-orange/10 border-accent-orange/20",
    purple: "text-accent-purple bg-accent-purple/10 border-accent-purple/20",
    pink: "text-accent-pink bg-accent-pink/10 border-accent-pink/20",
    gold: "text-tier-gold bg-tier-gold/10 border-tier-gold/20",
    mint: "text-accent-mint bg-accent-mint/10 border-accent-mint/20",
    teal: "text-tiffany-600 bg-tiffany-50 border-tiffany-200",
  };

  return (
    <div className={cn(
      "rounded-xl p-3 border transition-all hover:scale-105 cursor-default",
      colorClasses[color]
    )}>
      <div className="flex items-center gap-2 mb-1">
        {icon}
        <span className="text-xl font-display font-bold">{value}</span>
      </div>
      <p className="text-xs text-text-secondary">{label}</p>
    </div>
  );
}

// ============================================
// Daily Check-in Card
// ============================================

const WEEKLY_REWARDS = [
  { day: "一", coins: 10, claimed: true },
  { day: "二", coins: 15, claimed: true },
  { day: "三", coins: 20, claimed: true },
  { day: "四", coins: 25, claimed: false, isToday: true },
  { day: "五", coins: 30, claimed: false },
  { day: "六", coins: 40, claimed: false },
  { day: "日", coins: 50, claimed: false },
];

function DailyCheckInCard() {
  const [claimed, setClaimed] = useState(WEEKLY_REWARDS.map(r => r.claimed));
  const todayIndex = WEEKLY_REWARDS.findIndex(r => r.isToday);
  const isTodayClaimed = claimed[todayIndex];
  const todayReward = WEEKLY_REWARDS[todayIndex];

  const handleClaim = (index: number) => {
    if (WEEKLY_REWARDS[index].isToday && !claimed[index]) {
      const newClaimed = [...claimed];
      newClaimed[index] = true;
      setClaimed(newClaimed);
    }
  };

  return (
    <div className="card card-hover p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-tiffany-50 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-tiffany-600" />
          </div>
          <div>
            <h3 className="font-display text-text-primary">每日簽到</h3>
            <p className="text-xs text-text-secondary">
              {isTodayClaimed ? "已完成今日簽到" : `今日可領 +${todayReward?.coins || 0} 金幣`}
            </p>
          </div>
        </div>
        {!isTodayClaimed && (
          <button
            onClick={() => handleClaim(todayIndex)}
            className="btn-teal text-sm py-2 px-4"
          >
            簽到領獎
          </button>
        )}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {WEEKLY_REWARDS.map((reward, idx) => {
          const isClaimed = claimed[idx];
          const isToday = reward.isToday;

          return (
            <button
              key={reward.day}
              onClick={() => handleClaim(idx)}
              disabled={!isToday || isClaimed}
              className={cn(
                "flex flex-col items-center p-2 rounded-xl transition-all cursor-pointer",
                isClaimed
                  ? "bg-accent-mint/10 border border-accent-mint/30"
                  : isToday
                    ? "bg-gradient-to-br from-tiffany-50 to-accent-cyan/10 border-2 border-tiffany-500 shadow-teal animate-pulse-soft"
                    : "bg-surface-elevated border border-surface-border"
              )}
            >
              <span className={cn(
                "text-xs font-medium mb-1",
                isClaimed ? "text-accent-mint" : isToday ? "text-tiffany-600" : "text-text-muted"
              )}>
                {reward.day}
              </span>
              {isClaimed ? (
                <Check className="w-5 h-5 text-accent-mint" />
              ) : (
                <Gift className={cn(
                  "w-5 h-5",
                  isToday ? "text-tiffany-500" : "text-text-muted"
                )} />
              )}
              <span className={cn(
                "text-[10px] mt-1 font-medium",
                isClaimed ? "text-accent-mint" : isToday ? "text-tiffany-600" : "text-text-muted"
              )}>
                +{reward.coins}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ============================================
// Pending Orders Alert
// ============================================

function PendingOrdersCard() {
  const pendingOrders = MOCK_ORDERS.filter(o => o.status === 'ready' || o.status === 'pending');

  if (pendingOrders.length === 0) return null;

  return (
    <div className="card p-5 border-2 border-tier-gold/30 relative overflow-hidden bg-gradient-to-br from-tier-gold-bg to-surface-elevated">
      <div className="relative z-10 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-tier-gold/20 flex items-center justify-center animate-float">
          <Package className="w-6 h-6 text-tier-gold" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-display text-tier-gold">待領取獎品</h3>
            <span className="px-2 py-0.5 bg-tier-gold/20 text-tier-gold text-xs font-bold rounded-full border border-tier-gold/30">
              {pendingOrders.length}
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm text-text-secondary">
            {pendingOrders.slice(0, 2).map(order => (
              <span key={order.id} className="flex items-center gap-1">
                <span>{order.rewardEmoji}</span>
                <span className="text-xs">{order.rewardName}</span>
              </span>
            ))}
            {pendingOrders.length > 2 && (
              <span className="text-xs text-tier-gold">+{pendingOrders.length - 2}</span>
            )}
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-tier-gold" />
      </div>
    </div>
  );
}

// ============================================
// Quick Rank Card
// ============================================

function QuickRankCard() {
  const currentUser = MOCK_LEADERBOARD.find(e => e.isCurrentUser);
  const rank = currentUser?.rank || 0;
  const change = currentUser?.change || 0;

  return (
    <div className="card card-hover p-5 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-tiffany-500/5 rounded-full blur-2xl" />

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-tiffany-50 flex items-center justify-center">
            <Trophy className="w-5 h-5 text-tiffany-600" />
          </div>
          <span className="text-sm text-text-secondary">本週排名</span>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-4xl font-display text-gradient-teal">#{rank}</span>
          {change !== 0 && (
            <span className={cn(
              "flex items-center text-sm font-medium",
              change > 0 ? "text-accent-mint" : "text-accent-coral"
            )}>
              {change > 0 ? (
                <TrendingUp className="w-4 h-4 mr-1" />
              ) : (
                <TrendingDown className="w-4 h-4 mr-1" />
              )}
              {Math.abs(change)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================
// Recent Badges Card
// ============================================

function RecentBadgesCard() {
  const earnedBadges = MOCK_BADGES.filter(b => b.earnedAt).slice(0, 4);

  return (
    <div className="card card-hover p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-orange/10 flex items-center justify-center">
            <Star className="w-5 h-5 text-accent-orange" />
          </div>
          <h3 className="font-display text-text-primary">最近獲得</h3>
        </div>
        <span className="text-xs text-text-secondary">{earnedBadges.length} 個</span>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {earnedBadges.map((badge) => (
          <div
            key={badge.id}
            className={cn(
              "aspect-square rounded-xl flex items-center justify-center overflow-hidden",
              "transition-all hover:scale-110 cursor-pointer",
              `badge-tier-${badge.tier}`
            )}
            title={badge.name}
          >
            {badge.imageUrl ? (
              <img src={badge.imageUrl} alt={badge.name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-2xl">{badge.emoji}</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================
// Total XP Card
// ============================================

function TotalXPCard() {
  return (
    <div className="card card-hover p-5 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-tiffany-50/50 to-accent-cyan/5" />

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-tiffany-50 flex items-center justify-center">
            <Zap className="w-5 h-5 text-tiffany-600" />
          </div>
          <span className="text-sm text-text-secondary">總經驗值</span>
        </div>

        <div className="flex items-baseline gap-1">
          <span className="text-3xl font-display text-gradient-teal">
            {MOCK_USER_PROFILE.totalXp.toLocaleString()}
          </span>
          <span className="text-lg text-tiffany-600">XP</span>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Coins Card
// ============================================

function CoinsCard() {
  return (
    <div className="card card-hover p-5 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-tier-gold/5 to-accent-orange/5" />

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-tier-gold/10 flex items-center justify-center">
            <span className="text-xl">🪙</span>
          </div>
          <span className="text-sm text-text-secondary">金幣餘額</span>
        </div>

        <div className="flex items-baseline gap-1">
          <span className="text-3xl font-display text-gradient-gold">
            {MOCK_USER_PROFILE.coins.toLocaleString()}
          </span>
          <span className="text-lg text-tier-gold">枚</span>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Streak Highlight Card
// ============================================

function StreakCard() {
  const streak = MOCK_USER_PROFILE.currentStreak || 0;
  const longestStreak = MOCK_USER_PROFILE.longestStreak || 0;

  return (
    <div className="card card-hover p-5 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-accent-orange/10 rounded-full blur-2xl" />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent-orange/10 flex items-center justify-center">
              <Flame className="w-5 h-5 text-accent-orange" />
            </div>
            <span className="text-sm text-text-secondary">學習火焰</span>
          </div>
          <Sparkles className="w-4 h-4 text-accent-orange animate-pulse" />
        </div>

        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-4xl font-display text-accent-orange">{streak}</span>
          <span className="text-lg text-accent-orange/70">天</span>
        </div>

        <div className="text-xs text-text-secondary">
          最高紀錄: <span className="text-accent-orange font-medium">{longestStreak}</span> 天
        </div>
      </div>
    </div>
  );
}

// ============================================
// Mini Leaderboard Preview
// ============================================

function MiniLeaderboardCard() {
  const topThree = MOCK_LEADERBOARD.slice(0, 3);

  return (
    <div className="card card-hover p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-tier-gold/10 flex items-center justify-center">
            <Trophy className="w-5 h-5 text-tier-gold" />
          </div>
          <h3 className="font-display text-text-primary">排行榜 TOP 3</h3>
        </div>
        <span className="text-xs text-text-secondary flex items-center gap-1 cursor-pointer hover:text-tiffany-600 transition-colors">
          查看全部 <ChevronRight className="w-4 h-4" />
        </span>
      </div>

      <div className="space-y-2">
        {topThree.map((entry, index) => {
          const medalColors = [
            "from-tier-gold to-amber-400",
            "from-tier-silver to-slate-300",
            "from-tier-bronze to-orange-400",
          ];
          const bgColors = [
            "bg-tier-gold-bg",
            "bg-tier-silver-bg",
            "bg-tier-bronze-bg",
          ];

          return (
            <div
              key={entry.userId}
              className={cn(
                "flex items-center gap-3 p-2 rounded-xl border border-surface-border hover:shadow-card-hover transition-all cursor-pointer",
                bgColors[index]
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-lg bg-gradient-to-br flex items-center justify-center font-display text-sm text-white font-bold shadow-sm",
                medalColors[index]
              )}>
                {entry.rank}
              </div>
              <span className="text-xl">{entry.avatarEmoji}</span>
              <div className="flex-1">
                <p className="text-sm text-text-primary font-medium">{entry.displayName}</p>
                <p className="text-xs text-text-secondary">Lv.{entry.level}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-tiffany-600">{entry.value.toLocaleString()}</p>
                <p className="text-xs text-text-muted">XP</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

export function GamificationShowcase() {
  return (
    <div className="min-h-screen p-4 md:p-6 bg-teal-mesh">
      <div className="max-w-6xl mx-auto space-y-4 md:space-y-5">
        {/* Section 1: Hero Profile + Stats Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-5">
          {/* Hero Profile - Full width on mobile, 2/3 on desktop */}
          <div className="lg:col-span-2">
            <HeroProfileCard />
          </div>
          {/* Quick Stats - Stack on mobile, single column on desktop */}
          <div className="grid grid-cols-2 lg:grid-cols-1 gap-4 md:gap-5">
            <StreakCard />
            <QuickRankCard />
          </div>
        </div>

        {/* Section 2: Daily Check-in (full width on mobile for better UX) */}
        <DailyCheckInCard />

        {/* Section 3: Currency & Pending Orders */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
          <TotalXPCard />
          <CoinsCard />
          <div className="col-span-2">
            <PendingOrdersCard />
          </div>
        </div>

        {/* Section 4: Badges & Leaderboard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-5">
          <RecentBadgesCard />
          <div className="lg:col-span-2">
            <MiniLeaderboardCard />
          </div>
        </div>
      </div>
    </div>
  );
}

export default GamificationShowcase;
