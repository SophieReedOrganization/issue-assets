/**
 * Platform Admin - 平台管理儀表板
 *
 * 功能：
 * - 平台總覽統計（機構、學生、道具、兌換）
 * - 跨機構兌換趨勢圖表
 * - 機構排行榜
 * - 最新全平台兌換
 */

import {
  Building2,
  Users,
  Package,
  ShoppingCart,
  TrendingUp,
  TrendingDown,
  Globe,
  BarChart3,
  ChevronRight,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import {
  MOCK_PLATFORM_STATS,
  MOCK_PLATFORM_SALES_DATA,
  MOCK_ORGANIZATION_RANKINGS,
  MOCK_PLATFORM_ORDERS,
  formatDateTime,
} from '../../data/mockData';

// ============================================
// Components
// ============================================

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendValue,
  variant = 'default',
}: {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: typeof Building2;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  variant?: 'default' | 'primary' | 'secondary' | 'warning';
}) {
  const variantStyles = {
    default: 'bg-white border-surface-border',
    primary: 'bg-gradient-to-br from-tiffany-50 to-accent-cyan/10 border-tiffany-200',
    secondary: 'bg-gradient-to-br from-accent-pink/5 to-purple-50 border-accent-pink/30',
    warning: 'bg-tier-gold/5 border-tier-gold/30',
  };

  const iconStyles = {
    default: 'bg-surface-elevated text-text-muted',
    primary: 'bg-tiffany-500 text-white',
    secondary: 'bg-accent-pink text-white',
    warning: 'bg-tier-gold text-white',
  };

  return (
    <div className={cn('card p-5 border-2', variantStyles[variant])}>
      <div className="flex items-start justify-between">
        <div
          className={cn(
            'w-12 h-12 rounded-xl flex items-center justify-center',
            iconStyles[variant]
          )}
        >
          <Icon className="w-6 h-6" />
        </div>
        {trend && trendValue && (
          <div
            className={cn(
              'flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-display',
              trend === 'up'
                ? 'bg-accent-mint/10 text-accent-mint'
                : trend === 'down'
                  ? 'bg-accent-coral/10 text-accent-coral'
                  : 'bg-surface-elevated text-text-muted'
            )}
          >
            {trend === 'up' ? (
              <TrendingUp className="w-3 h-3" />
            ) : trend === 'down' ? (
              <TrendingDown className="w-3 h-3" />
            ) : null}
            {trendValue}
          </div>
        )}
      </div>
      <div className="mt-4">
        <p className="text-2xl font-display text-text-primary">{value}</p>
        <p className="text-sm text-text-muted">{title}</p>
        {subtitle && <p className="text-xs text-text-muted mt-1">{subtitle}</p>}
      </div>
    </div>
  );
}

function PlatformSalesChart() {
  const maxRevenue = Math.max(
    ...MOCK_PLATFORM_SALES_DATA.map((d) => d.platformRevenue + d.orgRevenue)
  );

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-display text-text-primary">平台兌換趨勢</h3>
          <p className="text-sm text-text-muted">過去 14 天</p>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-tiffany-500" />
            <span className="text-text-muted">平台道具</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-accent-pink" />
            <span className="text-text-muted">機構獎品</span>
          </div>
        </div>
      </div>

      {/* Stacked Bar Chart */}
      <div className="h-48 flex items-end gap-2">
        {MOCK_PLATFORM_SALES_DATA.map((data, index) => {
          const totalRevenue = data.platformRevenue + data.orgRevenue;
          const totalHeight = (totalRevenue / maxRevenue) * 140;
          const platformHeight = (data.platformRevenue / totalRevenue) * totalHeight;
          const orgHeight = (data.orgRevenue / totalRevenue) * totalHeight;

          return (
            <div key={data.date} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full flex flex-col items-center">
                {/* Stacked bars */}
                <div
                  className="w-full bg-gradient-to-t from-accent-pink to-pink-400 rounded-t transition-all hover:opacity-80"
                  style={{ height: `${orgHeight}px` }}
                />
                <div
                  className="w-full bg-gradient-to-t from-tiffany-500 to-tiffany-400 transition-all hover:opacity-80"
                  style={{ height: `${platformHeight}px` }}
                />
              </div>
              {/* Date Label (show every other) */}
              {index % 2 === 0 && (
                <span className="text-[10px] text-text-muted mt-1">
                  {new Date(data.date).getDate()}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-4 pt-4 border-t border-surface-border grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-text-muted">平台道具兌換</p>
          <p className="font-display text-tiffany-600">
            🪙 {MOCK_PLATFORM_STATS.weekRevenue.toLocaleString()}
          </p>
        </div>
        <div>
          <p className="text-xs text-text-muted">機構獎品兌換</p>
          <p className="font-display text-accent-pink">
            🪙 {(MOCK_PLATFORM_STATS.monthRevenue - MOCK_PLATFORM_STATS.weekRevenue).toLocaleString()}
          </p>
        </div>
      </div>
    </div>
  );
}

function OrganizationRankingList({ onViewAll }: { onViewAll: () => void }) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-text-primary">機構排行</h3>
        <button
          onClick={onViewAll}
          className="flex items-center gap-1 text-sm text-tiffany-600 hover:text-tiffany-700"
        >
          查看全部
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {MOCK_ORGANIZATION_RANKINGS.slice(0, 5).map((item) => (
          <div
            key={item.organization.id}
            className="flex items-center gap-3 p-3 rounded-xl bg-surface-elevated"
          >
            {/* Rank */}
            <div
              className={cn(
                'w-8 h-8 rounded-lg flex items-center justify-center font-display text-sm',
                item.rank === 1
                  ? 'bg-tier-gold/20 text-tier-gold'
                  : item.rank === 2
                    ? 'bg-gray-200 text-gray-600'
                    : item.rank === 3
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-surface-hover text-text-muted'
              )}
            >
              {item.rank}
            </div>

            {/* Org Info */}
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-tiffany-100 to-accent-cyan/20 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-tiffany-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-display text-text-primary text-sm truncate">
                {item.organization.name}
              </p>
              <p className="text-xs text-text-muted">
                {item.organization.activeStudents} 活躍學生 • {item.orderCount} 兌換
              </p>
            </div>

            {/* Revenue & Growth */}
            <div className="text-right">
              <p className="font-display text-tier-gold flex items-center gap-1">
                🪙 {item.revenue.toLocaleString()}
              </p>
              <div
                className={cn(
                  'text-xs flex items-center gap-0.5 justify-end',
                  item.growth >= 0 ? 'text-accent-mint' : 'text-accent-coral'
                )}
              >
                {item.growth >= 0 ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                {item.growth >= 0 ? '+' : ''}{item.growth.toFixed(1)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RecentPlatformOrders({ onViewAll }: { onViewAll: () => void }) {
  const recentOrders = MOCK_PLATFORM_ORDERS.slice(0, 5);

  const statusColors: Record<string, string> = {
    pending: 'bg-tier-gold/10 text-tier-gold border-tier-gold/30',
    confirmed: 'bg-tiffany-50 text-tiffany-600 border-tiffany-200',
    ready: 'bg-accent-mint/10 text-accent-mint border-accent-mint/30',
    completed: 'bg-surface-elevated text-text-muted border-surface-border',
    cancelled: 'bg-accent-coral/10 text-accent-coral border-accent-coral/30',
    expired: 'bg-surface-hover text-text-muted border-surface-border',
  };

  const statusLabels: Record<string, string> = {
    pending: '待處理',
    confirmed: '已確認',
    ready: '可領取',
    completed: '已領取',
    cancelled: '已取消',
    expired: '已過期',
  };

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-text-primary">最新兌換</h3>
        <button
          onClick={onViewAll}
          className="flex items-center gap-1 text-sm text-tiffany-600 hover:text-tiffany-700"
        >
          查看全部
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {recentOrders.map((order) => (
          <div
            key={order.id}
            className="flex items-center gap-3 p-3 rounded-xl bg-surface-elevated"
          >
            {/* Student Avatar */}
            <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
              {order.studentAvatar || '👤'}
            </div>

            {/* Order Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-display text-text-primary text-sm">
                  {order.studentName}
                </p>
                <span className="px-1.5 py-0.5 rounded text-[9px] bg-surface-hover text-text-muted">
                  {order.organizationName}
                </span>
                <span
                  className={cn(
                    'px-2 py-0.5 rounded text-[10px] font-display border',
                    statusColors[order.status]
                  )}
                >
                  {statusLabels[order.status]}
                </span>
              </div>
              <p className="text-xs text-text-muted truncate">
                {order.itemSnapshot.name} × {order.quantity}
              </p>
            </div>

            {/* Time */}
            <div className="text-right">
              <p className="text-xs text-text-muted">
                {formatDateTime(order.createdAt).split(' ')[1]}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function QuickStats() {
  const stats = MOCK_PLATFORM_STATS;

  return (
    <div className="card p-5">
      <h3 className="font-display text-text-primary mb-4">快速統計</h3>

      <div className="space-y-4">
        {/* Organizations */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-tiffany-50 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-tiffany-600" />
            </div>
            <span className="text-sm text-text-secondary">活躍機構</span>
          </div>
          <span className="font-display text-text-primary">
            {stats.activeOrganizations} / {stats.totalOrganizations}
          </span>
        </div>

        {/* Students */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-accent-pink/10 flex items-center justify-center">
              <Users className="w-4 h-4 text-accent-pink" />
            </div>
            <span className="text-sm text-text-secondary">活躍學生</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-display text-text-primary">
              {stats.activeStudents.toLocaleString()}
            </span>
            <span
              className={cn(
                'text-xs flex items-center gap-0.5',
                stats.studentGrowth >= 0 ? 'text-accent-mint' : 'text-accent-coral'
              )}
            >
              {stats.studentGrowth >= 0 ? '+' : ''}{stats.studentGrowth}%
            </span>
          </div>
        </div>

        {/* Products */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center">
              <Package className="w-4 h-4 text-purple-600" />
            </div>
            <span className="text-sm text-text-secondary">道具/獎品總數</span>
          </div>
          <div className="text-right">
            <span className="font-display text-text-primary">{stats.totalProducts}</span>
            <p className="text-[10px] text-text-muted">
              平台 {stats.platformProducts} / 機構 {stats.orgProducts}
            </p>
          </div>
        </div>

        {/* Pending Orders */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-tier-gold/10 flex items-center justify-center">
              <ShoppingCart className="w-4 h-4 text-tier-gold" />
            </div>
            <span className="text-sm text-text-secondary">待處理兌換</span>
          </div>
          <span className="font-display text-tier-gold">{stats.pendingOrders}</span>
        </div>

        {/* Today Orders */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-accent-mint/10 flex items-center justify-center">
              <Zap className="w-4 h-4 text-accent-mint" />
            </div>
            <span className="text-sm text-text-secondary">今日兌換</span>
          </div>
          <span className="font-display text-text-primary">{stats.todayOrders}</span>
        </div>
      </div>
    </div>
  );
}

function AlertsPanel() {
  const alerts = [
    {
      type: 'warning',
      message: '科學實驗室 商店已停用超過 30 天',
      time: '2 天前',
    },
    {
      type: 'info',
      message: '全科補習中心 有 8 筆待處理兌換',
      time: '1 小時前',
    },
    {
      type: 'success',
      message: '明星英語 本月兌換成長 25%',
      time: '今天',
    },
  ];

  const typeStyles = {
    warning: 'border-l-tier-gold bg-tier-gold/5',
    info: 'border-l-tiffany-500 bg-tiffany-50',
    success: 'border-l-accent-mint bg-accent-mint/5',
  };

  return (
    <div className="card p-5">
      <div className="flex items-center gap-2 mb-4">
        <AlertCircle className="w-5 h-5 text-text-muted" />
        <h3 className="font-display text-text-primary">通知</h3>
      </div>

      <div className="space-y-2">
        {alerts.map((alert, index) => (
          <div
            key={index}
            className={cn(
              'p-3 rounded-lg border-l-4',
              typeStyles[alert.type as keyof typeof typeStyles]
            )}
          >
            <p className="text-sm text-text-primary">{alert.message}</p>
            <p className="text-xs text-text-muted mt-1">{alert.time}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

interface PlatformDashboardProps {
  onNavigate: (page: string) => void;
}

export function PlatformDashboard({ onNavigate }: PlatformDashboardProps) {
  const stats = MOCK_PLATFORM_STATS;

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-accent-pink flex items-center justify-center shadow-lg">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-display text-text-primary">
                平台管理
              </h1>
              <p className="text-sm text-text-muted">
                EduBaania 遊戲化系統總覽
              </p>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            title="本月金幣消耗"
            value={`🪙 ${stats.monthRevenue.toLocaleString()}`}
            icon={BarChart3}
            trend={stats.revenueGrowth > 0 ? 'up' : 'down'}
            trendValue={`${stats.revenueGrowth > 0 ? '+' : ''}${stats.revenueGrowth}%`}
            variant="primary"
          />
          <StatCard
            title="總兌換數"
            value={stats.totalOrders.toLocaleString()}
            subtitle={`今日 ${stats.todayOrders} 筆`}
            icon={ShoppingCart}
            trend={stats.orderGrowth > 0 ? 'up' : 'down'}
            trendValue={`${stats.orderGrowth > 0 ? '+' : ''}${stats.orderGrowth}%`}
            variant="secondary"
          />
          <StatCard
            title="活躍機構"
            value={stats.activeOrganizations}
            subtitle={`共 ${stats.totalOrganizations} 個機構`}
            icon={Building2}
            variant="default"
          />
          <StatCard
            title="待處理兌換"
            value={stats.pendingOrders}
            subtitle="需要關注"
            icon={AlertCircle}
            variant={stats.pendingOrders > 10 ? 'warning' : 'default'}
          />
        </div>

        {/* Charts and Rankings */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <PlatformSalesChart />
          <OrganizationRankingList onViewAll={() => onNavigate('organizations')} />
        </div>

        {/* Orders and Quick Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <RecentPlatformOrders onViewAll={() => onNavigate('orders')} />
          </div>
          <div className="space-y-6">
            <QuickStats />
            <AlertsPanel />
          </div>
        </div>
      </div>
    </div>
  );
}

export default PlatformDashboard;
