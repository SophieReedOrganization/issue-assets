/**
 * Platform Admin - 機構管理頁面
 *
 * 功能：
 * - 機構列表和搜尋
 * - 機構狀態管理
 * - 機構商店設定
 * - 機構統計概覽
 */

import { useState, useMemo } from 'react';
import {
  Building2,
  Search,
  ChevronDown,
  Users,
  Package,
  ShoppingCart,
  TrendingUp,
  TrendingDown,
  Settings,
  Eye,
  ToggleLeft,
  ToggleRight,
  AlertCircle,
  CheckCircle,
  XCircle,
  X,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { MOCK_MANAGED_ORGANIZATIONS, formatDateTime } from '../../data/mockData';
import type { ManagedOrganization } from '../../types/platform-admin';

// ============================================
// Types
// ============================================

type FilterStatus = 'all' | 'active' | 'inactive' | 'suspended';
type SortBy = 'name' | 'students' | 'revenue' | 'orders';

// ============================================
// Components
// ============================================

function StatsOverview() {
  const stats = useMemo(() => {
    const total = MOCK_MANAGED_ORGANIZATIONS.length;
    const active = MOCK_MANAGED_ORGANIZATIONS.filter((o) => o.status === 'active').length;
    const inactive = MOCK_MANAGED_ORGANIZATIONS.filter((o) => o.status === 'inactive').length;
    const totalStudents = MOCK_MANAGED_ORGANIZATIONS.reduce((sum, o) => sum + o.studentCount, 0);
    const activeStudents = MOCK_MANAGED_ORGANIZATIONS.reduce((sum, o) => sum + o.activeStudents, 0);
    const totalRevenue = MOCK_MANAGED_ORGANIZATIONS.reduce((sum, o) => sum + o.totalRevenue, 0);
    const totalOrders = MOCK_MANAGED_ORGANIZATIONS.reduce((sum, o) => sum + o.totalOrders, 0);
    const pendingOrders = MOCK_MANAGED_ORGANIZATIONS.reduce((sum, o) => sum + o.pendingOrders, 0);

    return { total, active, inactive, totalStudents, activeStudents, totalRevenue, totalOrders, pendingOrders };
  }, []);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      <div className="card p-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-tiffany-50 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-tiffany-600" />
          </div>
          <div>
            <p className="text-2xl font-display text-text-primary">{stats.total}</p>
            <p className="text-xs text-text-muted">總機構數</p>
          </div>
        </div>
        <p className="text-xs text-text-muted">
          活躍 <span className="text-accent-mint">{stats.active}</span> / 停用 <span className="text-text-muted">{stats.inactive}</span>
        </p>
      </div>

      <div className="card p-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-accent-pink/10 flex items-center justify-center">
            <Users className="w-5 h-5 text-accent-pink" />
          </div>
          <div>
            <p className="text-2xl font-display text-text-primary">{stats.totalStudents.toLocaleString()}</p>
            <p className="text-xs text-text-muted">總學生數</p>
          </div>
        </div>
        <p className="text-xs text-text-muted">
          活躍 <span className="text-accent-mint">{stats.activeStudents.toLocaleString()}</span>
        </p>
      </div>

      <div className="card p-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-tier-gold/10 flex items-center justify-center">
            <ShoppingCart className="w-5 h-5 text-tier-gold" />
          </div>
          <div>
            <p className="text-2xl font-display text-text-primary">{stats.totalOrders.toLocaleString()}</p>
            <p className="text-xs text-text-muted">總訂單數</p>
          </div>
        </div>
        <p className="text-xs text-text-muted">
          待處理 <span className="text-tier-gold">{stats.pendingOrders}</span>
        </p>
      </div>

      <div className="card p-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <p className="text-2xl font-display text-text-primary">🪙 {stats.totalRevenue.toLocaleString()}</p>
            <p className="text-xs text-text-muted">總營收</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function OrgCard({
  org,
  onViewDetail,
  onToggleShop,
}: {
  org: ManagedOrganization;
  onViewDetail: () => void;
  onToggleShop: () => void;
}) {
  const statusConfig = {
    active: { label: '活躍', color: 'bg-accent-mint/10 text-accent-mint border-accent-mint/30', icon: CheckCircle },
    inactive: { label: '停用', color: 'bg-surface-hover text-text-muted border-surface-border', icon: XCircle },
    suspended: { label: '暫停', color: 'bg-accent-coral/10 text-accent-coral border-accent-coral/30', icon: AlertCircle },
  };

  const config = statusConfig[org.status];
  const StatusIcon = config.icon;

  return (
    <div className="card p-5 hover:shadow-md transition-all">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-tiffany-100 to-accent-cyan/20 flex items-center justify-center">
            <Building2 className="w-7 h-7 text-tiffany-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display text-text-primary text-lg">{org.name}</h3>
              <span className={cn('px-2 py-0.5 rounded text-[10px] font-display border', config.color)}>
                <StatusIcon className="w-3 h-3 inline mr-1" />
                {config.label}
              </span>
            </div>
            <p className="text-sm text-text-muted">/{org.slug}</p>
          </div>
        </div>

        {/* Shop Toggle */}
        <button
          onClick={onToggleShop}
          className={cn(
            'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors',
            org.shopEnabled
              ? 'bg-accent-mint/10 text-accent-mint hover:bg-accent-mint/20'
              : 'bg-surface-hover text-text-muted hover:bg-surface-elevated'
          )}
        >
          {org.shopEnabled ? (
            <>
              <ToggleRight className="w-4 h-4" />
              商店啟用
            </>
          ) : (
            <>
              <ToggleLeft className="w-4 h-4" />
              商店停用
            </>
          )}
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <div className="p-3 rounded-xl bg-surface-elevated">
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-4 h-4 text-text-muted" />
            <span className="text-xs text-text-muted">學生</span>
          </div>
          <p className="font-display text-text-primary">
            {org.activeStudents} <span className="text-xs text-text-muted">/ {org.studentCount}</span>
          </p>
        </div>

        <div className="p-3 rounded-xl bg-surface-elevated">
          <div className="flex items-center gap-2 mb-1">
            <Package className="w-4 h-4 text-text-muted" />
            <span className="text-xs text-text-muted">商品</span>
          </div>
          <p className="font-display text-text-primary">{org.productCount}</p>
        </div>

        <div className="p-3 rounded-xl bg-surface-elevated">
          <div className="flex items-center gap-2 mb-1">
            <ShoppingCart className="w-4 h-4 text-text-muted" />
            <span className="text-xs text-text-muted">訂單</span>
          </div>
          <p className="font-display text-text-primary">
            {org.totalOrders}
            {org.pendingOrders > 0 && (
              <span className="text-xs text-tier-gold ml-1">({org.pendingOrders} 待處理)</span>
            )}
          </p>
        </div>

        <div className="p-3 rounded-xl bg-surface-elevated">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-text-muted" />
            <span className="text-xs text-text-muted">營收</span>
          </div>
          <p className="font-display text-tier-gold">🪙 {org.totalRevenue.toLocaleString()}</p>
        </div>
      </div>

      {/* Shop Settings Summary */}
      {org.shopEnabled && (
        <div className="flex flex-wrap gap-2 mb-4">
          {org.shopSettings.allowPhysicalRewards && (
            <span className="px-2 py-1 bg-surface-elevated rounded-lg text-xs text-text-muted">
              實體獎品
            </span>
          )}
          {org.shopSettings.allowPrivileges && (
            <span className="px-2 py-1 bg-surface-elevated rounded-lg text-xs text-text-muted">
              特權兌換
            </span>
          )}
          <span className="px-2 py-1 bg-surface-elevated rounded-lg text-xs text-text-muted">
            每日上限 {org.shopSettings.maxDailyOrders}
          </span>
          <span className="px-2 py-1 bg-surface-elevated rounded-lg text-xs text-text-muted">
            有效期 {org.shopSettings.orderExpiryDays} 天
          </span>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-surface-border">
        <div className="text-xs text-text-muted">
          {org.lastActivityAt ? (
            <>最後活動: {formatDateTime(org.lastActivityAt)}</>
          ) : (
            <>建立於: {formatDateTime(org.createdAt)}</>
          )}
        </div>
        <button
          onClick={onViewDetail}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm text-tiffany-600 hover:bg-tiffany-50 transition-colors"
        >
          <Eye className="w-4 h-4" />
          查看詳情
        </button>
      </div>
    </div>
  );
}

function OrgDetailModal({
  org,
  onClose,
}: {
  org: ManagedOrganization;
  onClose: () => void;
}) {
  const statusConfig = {
    active: { label: '活躍', color: 'bg-accent-mint/10 text-accent-mint' },
    inactive: { label: '停用', color: 'bg-surface-hover text-text-muted' },
    suspended: { label: '暫停', color: 'bg-accent-coral/10 text-accent-coral' },
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div className="w-full max-w-2xl card p-0 max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-surface-border">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-tiffany-100 to-accent-cyan/20 flex items-center justify-center">
              <Building2 className="w-6 h-6 text-tiffany-600" />
            </div>
            <div>
              <h2 className="font-display text-text-primary">{org.name}</h2>
              <p className="text-sm text-text-muted">/{org.slug}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-surface-hover transition-colors"
          >
            <X className="w-5 h-5 text-text-muted" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Status & Shop */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="p-4 rounded-xl bg-surface-elevated">
              <p className="text-xs text-text-muted mb-2">機構狀態</p>
              <span className={cn('px-3 py-1 rounded-lg text-sm font-display', statusConfig[org.status].color)}>
                {statusConfig[org.status].label}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-surface-elevated">
              <p className="text-xs text-text-muted mb-2">商店狀態</p>
              <span className={cn(
                'px-3 py-1 rounded-lg text-sm font-display',
                org.shopEnabled
                  ? 'bg-accent-mint/10 text-accent-mint'
                  : 'bg-surface-hover text-text-muted'
              )}>
                {org.shopEnabled ? '已啟用' : '已停用'}
              </span>
            </div>
          </div>

          {/* Statistics */}
          <div className="mb-6">
            <h3 className="font-display text-text-primary mb-3">統計數據</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-surface-elevated text-center">
                <p className="text-2xl font-display text-text-primary">{org.studentCount}</p>
                <p className="text-xs text-text-muted">總學生</p>
              </div>
              <div className="p-3 rounded-xl bg-surface-elevated text-center">
                <p className="text-2xl font-display text-accent-mint">{org.activeStudents}</p>
                <p className="text-xs text-text-muted">活躍學生</p>
              </div>
              <div className="p-3 rounded-xl bg-surface-elevated text-center">
                <p className="text-2xl font-display text-text-primary">{org.productCount}</p>
                <p className="text-xs text-text-muted">上架商品</p>
              </div>
              <div className="p-3 rounded-xl bg-surface-elevated text-center">
                <p className="text-2xl font-display text-text-primary">{org.totalOrders}</p>
                <p className="text-xs text-text-muted">總訂單</p>
              </div>
            </div>
          </div>

          {/* Revenue */}
          <div className="mb-6">
            <h3 className="font-display text-text-primary mb-3">營收資訊</h3>
            <div className="p-4 rounded-xl bg-gradient-to-br from-tier-gold/10 to-tier-gold/5 border border-tier-gold/20">
              <p className="text-sm text-tier-gold mb-1">總營收</p>
              <p className="text-3xl font-display text-tier-gold">
                🪙 {org.totalRevenue.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Shop Settings */}
          {org.shopEnabled && (
            <div className="mb-6">
              <h3 className="font-display text-text-primary mb-3">商店設定</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-xl bg-surface-elevated">
                  <span className="text-sm text-text-secondary">實體獎品</span>
                  <span className={cn(
                    'text-sm font-display',
                    org.shopSettings.allowPhysicalRewards ? 'text-accent-mint' : 'text-text-muted'
                  )}>
                    {org.shopSettings.allowPhysicalRewards ? '允許' : '禁用'}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-surface-elevated">
                  <span className="text-sm text-text-secondary">特權兌換</span>
                  <span className={cn(
                    'text-sm font-display',
                    org.shopSettings.allowPrivileges ? 'text-accent-mint' : 'text-text-muted'
                  )}>
                    {org.shopSettings.allowPrivileges ? '允許' : '禁用'}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-surface-elevated">
                  <span className="text-sm text-text-secondary">每日訂單上限</span>
                  <span className="text-sm font-display text-text-primary">
                    {org.shopSettings.maxDailyOrders} 筆
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-surface-elevated">
                  <span className="text-sm text-text-secondary">兌換碼有效期</span>
                  <span className="text-sm font-display text-text-primary">
                    {org.shopSettings.orderExpiryDays} 天
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Timestamps */}
          <div>
            <h3 className="font-display text-text-primary mb-3">時間資訊</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-text-muted">建立時間</span>
                <span className="text-text-secondary">{formatDateTime(org.createdAt)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-text-muted">更新時間</span>
                <span className="text-text-secondary">{formatDateTime(org.updatedAt)}</span>
              </div>
              {org.lastActivityAt && (
                <div className="flex items-center justify-between">
                  <span className="text-text-muted">最後活動</span>
                  <span className="text-text-secondary">{formatDateTime(org.lastActivityAt)}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-4 border-t border-surface-border">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-text-secondary hover:bg-surface-hover transition-colors"
          >
            關閉
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-tiffany-500 text-white rounded-xl font-display hover:bg-tiffany-600 transition-colors">
            <Settings className="w-4 h-4" />
            編輯設定
          </button>
        </div>
      </div>
    </div>
  );
}

function FilterBar({
  status,
  sortBy,
  searchQuery,
  onStatusChange,
  onSortChange,
  onSearchChange,
}: {
  status: FilterStatus;
  sortBy: SortBy;
  searchQuery: string;
  onStatusChange: (status: FilterStatus) => void;
  onSortChange: (sort: SortBy) => void;
  onSearchChange: (query: string) => void;
}) {
  return (
    <div className="card p-4 mb-6">
      <div className="flex flex-col md:flex-row md:items-center gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          <input
            type="text"
            placeholder="搜尋機構名稱..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 focus:border-tiffany-500"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3">
          {/* Status Filter */}
          <div className="relative">
            <select
              value={status}
              onChange={(e) => onStatusChange(e.target.value as FilterStatus)}
              className="appearance-none pl-3 pr-8 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 cursor-pointer"
            >
              <option value="all">全部狀態</option>
              <option value="active">活躍</option>
              <option value="inactive">停用</option>
              <option value="suspended">暫停</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted pointer-events-none" />
          </div>

          {/* Sort */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value as SortBy)}
              className="appearance-none pl-3 pr-8 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 cursor-pointer"
            >
              <option value="name">名稱排序</option>
              <option value="students">學生數排序</option>
              <option value="revenue">營收排序</option>
              <option value="orders">訂單數排序</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

interface OrganizationsPageProps {
  onNavigate?: (page: string) => void;
}

export function OrganizationsPage({ onNavigate }: OrganizationsPageProps) {
  const [status, setStatus] = useState<FilterStatus>('all');
  const [sortBy, setSortBy] = useState<SortBy>('revenue');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrg, setSelectedOrg] = useState<ManagedOrganization | null>(null);

  // Filter and sort organizations
  const filteredOrgs = useMemo(() => {
    let result = [...MOCK_MANAGED_ORGANIZATIONS];

    // Filter by status
    if (status !== 'all') {
      result = result.filter((o) => o.status === status);
    }

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (o) =>
          o.name.toLowerCase().includes(query) ||
          o.slug.toLowerCase().includes(query)
      );
    }

    // Sort
    switch (sortBy) {
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'students':
        result.sort((a, b) => b.activeStudents - a.activeStudents);
        break;
      case 'revenue':
        result.sort((a, b) => b.totalRevenue - a.totalRevenue);
        break;
      case 'orders':
        result.sort((a, b) => b.totalOrders - a.totalOrders);
        break;
    }

    return result;
  }, [status, sortBy, searchQuery]);

  const handleToggleShop = (org: ManagedOrganization) => {
    // TODO: Implement shop toggle
    console.log('Toggle shop for:', org.id);
  };

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-tiffany-500 to-accent-cyan flex items-center justify-center shadow-lg">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-display text-text-primary">
              機構管理
            </h1>
            <p className="text-sm text-text-muted">
              管理平台所有機構和商店設定
            </p>
          </div>
        </div>

        {/* Stats Overview */}
        <StatsOverview />

        {/* Filter Bar */}
        <FilterBar
          status={status}
          sortBy={sortBy}
          searchQuery={searchQuery}
          onStatusChange={setStatus}
          onSortChange={setSortBy}
          onSearchChange={setSearchQuery}
        />

        {/* Organizations Grid */}
        {filteredOrgs.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredOrgs.map((org) => (
              <OrgCard
                key={org.id}
                org={org}
                onViewDetail={() => setSelectedOrg(org)}
                onToggleShop={() => handleToggleShop(org)}
              />
            ))}
          </div>
        ) : (
          <div className="card p-12 text-center">
            <Building2 className="w-12 h-12 text-text-muted mx-auto mb-4" />
            <p className="text-text-muted">沒有符合條件的機構</p>
          </div>
        )}

        {/* Organization Detail Modal */}
        {selectedOrg && (
          <OrgDetailModal
            org={selectedOrg}
            onClose={() => setSelectedOrg(null)}
          />
        )}
      </div>
    </div>
  );
}

export default OrganizationsPage;
