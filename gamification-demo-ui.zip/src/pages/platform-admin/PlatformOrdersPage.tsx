/**
 * Platform Admin - 全平台兌換管理頁面
 *
 * 功能：
 * - 跨機構兌換列表
 * - 按機構/狀態篩選
 * - 兌換搜尋
 * - 兌換詳情查看
 */

import { useState, useMemo } from 'react';
import {
  ShoppingCart,
  Search,
  Filter,
  ChevronDown,
  Building2,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Eye,
  X,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import {
  MOCK_PLATFORM_ORDERS,
  MOCK_MANAGED_ORGANIZATIONS,
  formatDateTime,
  getPlatformOrderStats,
} from '../../data/mockData';
import type { PlatformOrder } from '../../types/platform-admin';
import type { OrderStatus } from '../../types/org-admin';

// ============================================
// Types
// ============================================

type FilterOrg = string | 'all';

// ============================================
// Components
// ============================================

function StatusTabs({
  activeStatus,
  onStatusChange,
  stats,
}: {
  activeStatus: OrderStatus | 'all';
  onStatusChange: (status: OrderStatus | 'all') => void;
  stats: ReturnType<typeof getPlatformOrderStats>;
}) {
  const tabs: { key: OrderStatus | 'all'; label: string; count: number; color: string }[] = [
    { key: 'all', label: '全部', count: stats.total, color: 'text-text-primary' },
    { key: 'pending', label: '待處理', count: stats.pending, color: 'text-tier-gold' },
    { key: 'confirmed', label: '已確認', count: stats.confirmed, color: 'text-tiffany-600' },
    { key: 'ready', label: '可領取', count: stats.ready, color: 'text-accent-mint' },
    { key: 'completed', label: '已領取', count: stats.completed, color: 'text-text-muted' },
    { key: 'cancelled', label: '已取消', count: stats.cancelled, color: 'text-accent-coral' },
  ];

  return (
    <div className="flex gap-1 p-1 rounded-xl bg-surface-elevated overflow-x-auto">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => onStatusChange(tab.key)}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-lg font-display text-sm whitespace-nowrap transition-all',
            activeStatus === tab.key
              ? 'bg-white shadow-sm text-text-primary'
              : 'text-text-muted hover:text-text-secondary'
          )}
        >
          {tab.label}
          {tab.count > 0 && (
            <span
              className={cn(
                'px-1.5 py-0.5 rounded text-[10px] font-bold',
                activeStatus === tab.key
                  ? tab.key === 'pending'
                    ? 'bg-tier-gold/20 text-tier-gold'
                    : 'bg-surface-elevated text-text-muted'
                  : 'bg-surface-hover text-text-muted'
              )}
            >
              {tab.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

function OrderCard({
  order,
  onViewDetail,
}: {
  order: PlatformOrder;
  onViewDetail: () => void;
}) {
  const statusConfig: Record<
    OrderStatus,
    { label: string; color: string; icon: typeof Clock }
  > = {
    pending: { label: '待處理', color: 'bg-tier-gold/10 text-tier-gold border-tier-gold/30', icon: Clock },
    confirmed: { label: '已確認', color: 'bg-tiffany-50 text-tiffany-600 border-tiffany-200', icon: CheckCircle },
    ready: { label: '可領取', color: 'bg-accent-mint/10 text-accent-mint border-accent-mint/30', icon: CheckCircle },
    completed: { label: '已領取', color: 'bg-surface-elevated text-text-muted border-surface-border', icon: CheckCircle },
    cancelled: { label: '已取消', color: 'bg-accent-coral/10 text-accent-coral border-accent-coral/30', icon: XCircle },
    expired: { label: '已過期', color: 'bg-surface-hover text-text-muted border-surface-border', icon: AlertCircle },
  };

  const config = statusConfig[order.status];
  const StatusIcon = config.icon;

  return (
    <div className="card p-4 hover:shadow-md transition-all">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          {/* Student Avatar */}
          <div className="w-12 h-12 rounded-xl bg-surface-elevated flex items-center justify-center text-2xl">
            {order.studentAvatar || '👤'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display text-text-primary">{order.studentName}</h3>
              <span className={cn('px-2 py-0.5 rounded text-[10px] font-display border', config.color)}>
                <StatusIcon className="w-3 h-3 inline mr-1" />
                {config.label}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-text-muted">
              <span>{order.className}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Building2 className="w-3 h-3" />
                {order.organizationName}
              </span>
            </div>
          </div>
        </div>

        {/* Order Number */}
        <div className="text-right">
          <p className="text-xs text-text-muted">{order.orderNumber}</p>
          <p className="text-xs text-text-muted">
            {formatDateTime(order.createdAt).split(' ')[0]}
          </p>
        </div>
      </div>

      {/* Product Info */}
      <div className="flex items-center gap-3 p-3 rounded-xl bg-surface-elevated mb-3">
        <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
          {order.itemSnapshot.emoji || '🎁'}
        </div>
        <div className="flex-1">
          <p className="font-display text-text-primary text-sm">{order.itemSnapshot.name}</p>
          <p className="text-xs text-text-muted">
            {order.itemSnapshot.type === 'physical' ? '實體獎品' : order.itemSnapshot.type === 'privilege' ? '特權' : '虛擬道具'}
            {' × '}{order.quantity}
          </p>
        </div>
        <div className="text-right">
          <p className="font-display text-tier-gold">
            🪙 {order.totalPrice}
          </p>
        </div>
      </div>

      {/* Redemption Code (if ready) */}
      {order.status === 'ready' && order.redemptionCode && (
        <div className="p-3 rounded-xl bg-accent-mint/10 border border-accent-mint/30 mb-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-accent-mint">兌換碼</span>
            <span className="font-mono font-bold text-accent-mint">{order.redemptionCode}</span>
          </div>
          {order.expiresAt && (
            <p className="text-[10px] text-accent-mint/70 mt-1">
              有效期限: {formatDateTime(order.expiresAt)}
            </p>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between pt-3 border-t border-surface-border">
        <p className="text-xs text-text-muted">
          {formatDateTime(order.createdAt)}
        </p>
        <button
          onClick={onViewDetail}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm text-tiffany-600 hover:bg-tiffany-50 transition-colors"
        >
          <Eye className="w-4 h-4" />
          查看詳情
        </button>
      </div>
    </div>
  );
}

function OrderDetailModal({
  order,
  onClose,
}: {
  order: PlatformOrder;
  onClose: () => void;
}) {
  const statusConfig: Record<OrderStatus, { label: string; color: string }> = {
    pending: { label: '待處理', color: 'bg-tier-gold/10 text-tier-gold' },
    confirmed: { label: '已確認', color: 'bg-tiffany-50 text-tiffany-600' },
    ready: { label: '可領取', color: 'bg-accent-mint/10 text-accent-mint' },
    completed: { label: '已領取', color: 'bg-surface-elevated text-text-muted' },
    cancelled: { label: '已取消', color: 'bg-accent-coral/10 text-accent-coral' },
    expired: { label: '已過期', color: 'bg-surface-hover text-text-muted' },
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div className="w-full max-w-lg card p-0 max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-surface-border">
          <div>
            <h2 className="font-display text-text-primary">兌換詳情</h2>
            <p className="text-sm text-text-muted">{order.orderNumber}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-surface-hover transition-colors"
          >
            <X className="w-5 h-5 text-text-muted" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto max-h-[calc(90vh-120px)]">
          {/* Status */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-text-muted">兌換狀態</span>
            <span className={cn('px-3 py-1 rounded-lg text-sm font-display', statusConfig[order.status].color)}>
              {statusConfig[order.status].label}
            </span>
          </div>

          {/* Organization */}
          <div className="p-3 rounded-xl bg-surface-elevated mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-tiffany-100 to-accent-cyan/20 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-tiffany-600" />
              </div>
              <div>
                <p className="font-display text-text-primary">{order.organizationName}</p>
                <p className="text-xs text-text-muted">機構</p>
              </div>
            </div>
          </div>

          {/* Student */}
          <div className="p-3 rounded-xl bg-surface-elevated mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
                {order.studentAvatar || '👤'}
              </div>
              <div>
                <p className="font-display text-text-primary">{order.studentName}</p>
                <p className="text-xs text-text-muted">{order.className}</p>
              </div>
            </div>
          </div>

          {/* Product */}
          <div className="p-3 rounded-xl bg-surface-elevated mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-surface-bg flex items-center justify-center text-xl">
                {order.itemSnapshot.emoji || '🎁'}
              </div>
              <div className="flex-1">
                <p className="font-display text-text-primary">{order.itemSnapshot.name}</p>
                <p className="text-xs text-text-muted">
                  {order.itemSnapshot.type === 'physical' ? '實體獎品' : order.itemSnapshot.type === 'privilege' ? '特權' : '虛擬道具'}
                </p>
              </div>
              <div className="text-right">
                <p className="font-display text-tier-gold">🪙 {order.totalPrice}</p>
                <p className="text-xs text-text-muted">× {order.quantity}</p>
              </div>
            </div>
          </div>

          {/* Redemption Code */}
          {order.redemptionCode && (
            <div className="p-3 rounded-xl bg-accent-mint/10 border border-accent-mint/30 mb-4">
              <p className="text-xs text-accent-mint mb-1">兌換碼</p>
              <p className="font-mono font-bold text-lg text-accent-mint">{order.redemptionCode}</p>
              {order.expiresAt && (
                <p className="text-xs text-accent-mint/70 mt-1">
                  有效期限: {formatDateTime(order.expiresAt)}
                </p>
              )}
            </div>
          )}

          {/* Timeline */}
          <div className="space-y-3">
            <p className="text-sm text-text-muted font-display">時間軸</p>
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-tiffany-500" />
                <span className="text-sm text-text-secondary">
                  {formatDateTime(order.createdAt)} - 下單
                </span>
              </div>
              {order.confirmedAt && (
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-tiffany-500" />
                  <span className="text-sm text-text-secondary">
                    {formatDateTime(order.confirmedAt)} - 已確認
                  </span>
                </div>
              )}
              {order.completedAt && (
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-accent-mint" />
                  <span className="text-sm text-text-secondary">
                    {formatDateTime(order.completedAt)} - 已領取
                  </span>
                </div>
              )}
              {order.cancelledAt && (
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-accent-coral" />
                  <span className="text-sm text-text-secondary">
                    {formatDateTime(order.cancelledAt)} - 已取消
                    {order.cancelReason && ` (${order.cancelReason})`}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterBar({
  selectedOrg,
  searchQuery,
  onOrgChange,
  onSearchChange,
}: {
  selectedOrg: FilterOrg;
  searchQuery: string;
  onOrgChange: (org: FilterOrg) => void;
  onSearchChange: (query: string) => void;
}) {
  const organizations = MOCK_MANAGED_ORGANIZATIONS.filter((org) => org.status === 'active');

  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-4">
      {/* Search */}
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
        <input
          type="text"
          placeholder="搜尋學生姓名、兌換編號..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full pl-10 pr-4 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 focus:border-tiffany-500"
        />
      </div>

      {/* Org Filter */}
      <div className="relative">
        <select
          value={selectedOrg}
          onChange={(e) => onOrgChange(e.target.value)}
          className="appearance-none pl-3 pr-8 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 cursor-pointer min-w-[160px]"
        >
          <option value="all">全部機構</option>
          {organizations.map((org) => (
            <option key={org.id} value={org.id}>
              {org.name}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted pointer-events-none" />
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

interface PlatformOrdersPageProps {
  onNavigate?: (page: string) => void;
}

export function PlatformOrdersPage({ onNavigate }: PlatformOrdersPageProps) {
  const [activeStatus, setActiveStatus] = useState<OrderStatus | 'all'>('all');
  const [selectedOrg, setSelectedOrg] = useState<FilterOrg>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<PlatformOrder | null>(null);

  const stats = useMemo(() => getPlatformOrderStats(MOCK_PLATFORM_ORDERS), []);

  // Filter orders
  const filteredOrders = useMemo(() => {
    let result = [...MOCK_PLATFORM_ORDERS];

    // Filter by status
    if (activeStatus !== 'all') {
      result = result.filter((o) => o.status === activeStatus);
    }

    // Filter by organization
    if (selectedOrg !== 'all') {
      result = result.filter((o) => o.organizationId === selectedOrg);
    }

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (o) =>
          o.studentName.toLowerCase().includes(query) ||
          o.orderNumber.toLowerCase().includes(query) ||
          o.itemSnapshot.name.toLowerCase().includes(query)
      );
    }

    // Sort by date (newest first)
    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return result;
  }, [activeStatus, selectedOrg, searchQuery]);

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent-pink to-purple-500 flex items-center justify-center shadow-lg">
            <ShoppingCart className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-display text-text-primary">
              全平台兌換
            </h1>
            <p className="text-sm text-text-muted">
              查看所有機構的兌換記錄
            </p>
          </div>
        </div>

        {/* Status Tabs */}
        <div className="mb-4">
          <StatusTabs
            activeStatus={activeStatus}
            onStatusChange={setActiveStatus}
            stats={stats}
          />
        </div>

        {/* Filter Bar */}
        <FilterBar
          selectedOrg={selectedOrg}
          searchQuery={searchQuery}
          onOrgChange={setSelectedOrg}
          onSearchChange={setSearchQuery}
        />

        {/* Orders Grid */}
        {filteredOrders.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                onViewDetail={() => setSelectedOrder(order)}
              />
            ))}
          </div>
        ) : (
          <div className="card p-12 text-center">
            <ShoppingCart className="w-12 h-12 text-text-muted mx-auto mb-4" />
            <p className="text-text-muted">沒有符合條件的兌換記錄</p>
          </div>
        )}

        {/* Order Detail Modal */}
        {selectedOrder && (
          <OrderDetailModal
            order={selectedOrder}
            onClose={() => setSelectedOrder(null)}
          />
        )}
      </div>
    </div>
  );
}

export default PlatformOrdersPage;
