/**
 * Platform Admin - 平台道具管理頁面
 *
 * 功能：
 * - 平台虛擬道具列表（頭像框、稱號等）
 * - 道具搜尋和篩選
 * - 道具狀態管理
 * - 精選道具排序
 */

import { useState, useMemo } from 'react';
import {
  Package,
  Search,
  Filter,
  Plus,
  Eye,
  Edit3,
  Star,
  StarOff,
  ChevronDown,
  Globe,
  Zap,
  Tag,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { MOCK_PLATFORM_PRODUCTS } from '../../data/mockData';
import type { PlatformProduct } from '../../types/platform-admin';

// ============================================
// Types
// ============================================

type FilterStatus = 'all' | 'active' | 'inactive' | 'featured';
type FilterCategory = 'all' | 'avatar_frame' | 'title';
type SortBy = 'name' | 'price' | 'sold' | 'featured';

// ============================================
// Components
// ============================================

function ProductCard({
  product,
  onView,
  onEdit,
  onToggleFeatured,
}: {
  product: PlatformProduct;
  onView: () => void;
  onEdit: () => void;
  onToggleFeatured: () => void;
}) {
  const isFeatured = product.featuredOrder !== undefined;

  return (
    <div className="card p-4 hover:shadow-md transition-all group">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          {/* Product Image/Emoji */}
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-tiffany-50 to-purple-50 flex items-center justify-center text-2xl border-2 border-surface-border">
            {product.emoji || '🎁'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display text-text-primary">{product.name}</h3>
              {isFeatured && (
                <Star className="w-4 h-4 text-tier-gold fill-tier-gold" />
              )}
            </div>
            <p className="text-xs text-text-muted">
              {product.category === 'avatar_frame' ? '頭像框' : '稱號'}
            </p>
          </div>
        </div>

        {/* Status Badge */}
        <span
          className={cn(
            'px-2 py-1 rounded-lg text-xs font-display',
            product.isActive
              ? 'bg-accent-mint/10 text-accent-mint'
              : 'bg-surface-hover text-text-muted'
          )}
        >
          {product.isActive ? '上架中' : '已下架'}
        </span>
      </div>

      {/* Description */}
      <p className="text-sm text-text-secondary mb-3 line-clamp-2">
        {product.description}
      </p>

      {/* Tags */}
      {product.tags && product.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {product.tags.map((tag) => (
            <span
              key={tag}
              className="px-2 py-0.5 bg-surface-elevated rounded text-[10px] text-text-muted"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}

      {/* Stats */}
      <div className="flex items-center justify-between pt-3 border-t border-surface-border">
        <div className="flex items-center gap-4">
          {/* Price */}
          <div className="flex items-center gap-1">
            <Zap className="w-4 h-4 text-tiffany-500" />
            <span className="font-display text-tiffany-600">{product.price}</span>
          </div>

          {/* Level Requirement */}
          <div className="text-xs text-text-muted">
            Lv.{product.requiredLevel}+
          </div>

          {/* Sold Count */}
          <div className="text-xs text-text-muted">
            已售 {product.totalSold?.toLocaleString() || 0}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={onToggleFeatured}
            className={cn(
              'p-2 rounded-lg transition-colors',
              isFeatured
                ? 'text-tier-gold hover:bg-tier-gold/10'
                : 'text-text-muted hover:bg-surface-hover'
            )}
            title={isFeatured ? '取消精選' : '設為精選'}
          >
            {isFeatured ? (
              <StarOff className="w-4 h-4" />
            ) : (
              <Star className="w-4 h-4" />
            )}
          </button>
          <button
            onClick={onView}
            className="p-2 rounded-lg text-text-muted hover:bg-surface-hover transition-colors"
            title="預覽"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={onEdit}
            className="p-2 rounded-lg text-text-muted hover:bg-surface-hover transition-colors"
            title="編輯"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

function FilterBar({
  status,
  category,
  sortBy,
  searchQuery,
  onStatusChange,
  onCategoryChange,
  onSortChange,
  onSearchChange,
}: {
  status: FilterStatus;
  category: FilterCategory;
  sortBy: SortBy;
  searchQuery: string;
  onStatusChange: (status: FilterStatus) => void;
  onCategoryChange: (category: FilterCategory) => void;
  onSortChange: (sort: SortBy) => void;
  onSearchChange: (query: string) => void;
}) {
  return (
    <div className="card p-4 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          <input
            type="text"
            placeholder="搜尋道具名稱..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 focus:border-tiffany-500"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Status Filter */}
          <div className="relative">
            <select
              value={status}
              onChange={(e) => onStatusChange(e.target.value as FilterStatus)}
              className="appearance-none pl-3 pr-8 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 cursor-pointer"
            >
              <option value="all">全部狀態</option>
              <option value="active">上架中</option>
              <option value="inactive">已下架</option>
              <option value="featured">精選道具</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted pointer-events-none" />
          </div>

          {/* Category Filter */}
          <div className="relative">
            <select
              value={category}
              onChange={(e) => onCategoryChange(e.target.value as FilterCategory)}
              className="appearance-none pl-3 pr-8 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 cursor-pointer"
            >
              <option value="all">全部類型</option>
              <option value="avatar_frame">頭像框</option>
              <option value="title">稱號</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted pointer-events-none" />
          </div>

          {/* Sort */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value as SortBy)}
              className="appearance-none pl-3 pr-8 py-2 rounded-xl bg-surface-elevated border border-surface-border text-sm focus:outline-none focus:ring-2 focus:ring-tiffany-500/20 cursor-pointer"
            >
              <option value="featured">精選優先</option>
              <option value="name">名稱排序</option>
              <option value="price">價格排序</option>
              <option value="sold">兌換量排序</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function StatsBar({ products }: { products: PlatformProduct[] }) {
  const stats = useMemo(() => {
    const active = products.filter((p) => p.isActive).length;
    const featured = products.filter((p) => p.featuredOrder !== undefined).length;
    const frames = products.filter((p) => p.category === 'avatar_frame').length;
    const titles = products.filter((p) => p.category === 'title').length;
    const totalSold = products.reduce((sum, p) => sum + (p.totalSold || 0), 0);
    const totalRevenue = products.reduce((sum, p) => sum + (p.totalRevenue || 0), 0);

    return { active, featured, frames, titles, totalSold, totalRevenue };
  }, [products]);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
      <div className="card p-3 text-center">
        <p className="text-2xl font-display text-text-primary">{products.length}</p>
        <p className="text-xs text-text-muted">總道具數</p>
      </div>
      <div className="card p-3 text-center">
        <p className="text-2xl font-display text-accent-mint">{stats.active}</p>
        <p className="text-xs text-text-muted">上架中</p>
      </div>
      <div className="card p-3 text-center">
        <p className="text-2xl font-display text-tier-gold">{stats.featured}</p>
        <p className="text-xs text-text-muted">精選</p>
      </div>
      <div className="card p-3 text-center">
        <p className="text-2xl font-display text-tiffany-600">{stats.frames}</p>
        <p className="text-xs text-text-muted">頭像框</p>
      </div>
      <div className="card p-3 text-center">
        <p className="text-2xl font-display text-accent-pink">{stats.titles}</p>
        <p className="text-xs text-text-muted">稱號</p>
      </div>
      <div className="card p-3 text-center">
        <p className="text-2xl font-display text-purple-600">
          {stats.totalSold.toLocaleString()}
        </p>
        <p className="text-xs text-text-muted">總兌換量</p>
      </div>
    </div>
  );
}

// ============================================
// Main Component
// ============================================

interface PlatformProductsPageProps {
  onNavigate?: (page: string) => void;
}

export function PlatformProductsPage({ onNavigate }: PlatformProductsPageProps) {
  const [status, setStatus] = useState<FilterStatus>('all');
  const [category, setCategory] = useState<FilterCategory>('all');
  const [sortBy, setSortBy] = useState<SortBy>('featured');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let result = [...MOCK_PLATFORM_PRODUCTS];

    // Filter by status
    if (status === 'active') {
      result = result.filter((p) => p.isActive);
    } else if (status === 'inactive') {
      result = result.filter((p) => !p.isActive);
    } else if (status === 'featured') {
      result = result.filter((p) => p.featuredOrder !== undefined);
    }

    // Filter by category
    if (category !== 'all') {
      result = result.filter((p) => p.category === category);
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.tags?.some((t) => t.toLowerCase().includes(query))
      );
    }

    // Sort
    switch (sortBy) {
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'price':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'sold':
        result.sort((a, b) => (b.totalSold || 0) - (a.totalSold || 0));
        break;
      case 'featured':
      default:
        result.sort((a, b) => {
          if (a.featuredOrder && b.featuredOrder) {
            return a.featuredOrder - b.featuredOrder;
          }
          if (a.featuredOrder) return -1;
          if (b.featuredOrder) return 1;
          return 0;
        });
        break;
    }

    return result;
  }, [status, category, sortBy, searchQuery]);

  const handleView = (product: PlatformProduct) => {
    // TODO: Open preview modal
    console.log('View product:', product.id);
  };

  const handleEdit = (product: PlatformProduct) => {
    // TODO: Navigate to edit form
    console.log('Edit product:', product.id);
  };

  const handleToggleFeatured = (product: PlatformProduct) => {
    // TODO: Toggle featured status
    console.log('Toggle featured:', product.id);
  };

  return (
    <div className="min-h-screen bg-teal-mesh">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-tiffany-500 to-purple-500 flex items-center justify-center shadow-lg">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-display text-text-primary">
                平台道具管理
              </h1>
              <p className="text-sm text-text-muted">
                管理全平台虛擬道具（頭像框、稱號）
              </p>
            </div>
          </div>

          <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-tiffany-500 to-tiffany-600 text-white rounded-xl font-display shadow-teal hover:shadow-lg transition-all">
            <Plus className="w-4 h-4" />
            新增道具
          </button>
        </div>

        {/* Stats Bar */}
        <StatsBar products={MOCK_PLATFORM_PRODUCTS} />

        {/* Filter Bar */}
        <FilterBar
          status={status}
          category={category}
          sortBy={sortBy}
          searchQuery={searchQuery}
          onStatusChange={setStatus}
          onCategoryChange={setCategory}
          onSortChange={setSortBy}
          onSearchChange={setSearchQuery}
        />

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onView={() => handleView(product)}
                onEdit={() => handleEdit(product)}
                onToggleFeatured={() => handleToggleFeatured(product)}
              />
            ))}
          </div>
        ) : (
          <div className="card p-12 text-center">
            <Package className="w-12 h-12 text-text-muted mx-auto mb-4" />
            <p className="text-text-muted">沒有符合條件的道具</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default PlatformProductsPage;
