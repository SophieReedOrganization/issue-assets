/**
 * 機構商店管理頁面
 * 使用 @workspace/ui 風格的專業介面
 */

import { useState } from "react";
import { Plus, Edit2, Trash2, Check, X, Package, Users, Clock, Gift, Search } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "../../components/ui/dialog";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "../../components/ui/table";
import type { OrganizationReward, RedemptionRecord } from "../../types/gamification";
import {
  MOCK_ORG_REWARDS,
  MOCK_REDEMPTION_RECORDS,
  formatDateTime,
  getStatusText,
} from "../../data/mockData";

// ============================================
// Stats Card Component
// ============================================

function StatsCard({
  title,
  value,
  description,
  icon: Icon,
  color,
}: {
  title: string;
  value: string | number;
  description: string;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            <p className="text-xs text-gray-400 mt-1">{description}</p>
          </div>
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${color}`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================
// Add/Edit Reward Dialog
// ============================================

function RewardFormDialog({
  open,
  onOpenChange,
  reward,
  onSave,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reward?: OrganizationReward | null;
  onSave: (data: Partial<OrganizationReward>) => void;
}) {
  const [formData, setFormData] = useState({
    name: reward?.name || "",
    description: reward?.description || "",
    price: reward?.price || 500,
    stock: reward?.stock || 10,
    emoji: reward?.emoji || "🎁",
    category: reward?.category || "privilege",
  });

  const isEditing = !!reward;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "編輯獎品" : "新增獎品"}</DialogTitle>
          <DialogDescription>
            {isEditing ? "修改機構專屬獎品資訊" : "設定機構專屬獎品，僅限本機構學生兌換"}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name">獎品名稱</Label>
            <Input
              id="name"
              placeholder="例：免作業券"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">獎品說明</Label>
            <Input
              id="description"
              placeholder="例：可免除一次作業"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">金幣價格</Label>
              <Input
                id="price"
                type="number"
                min={1}
                placeholder="800"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) || 0 })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="stock">數量</Label>
              <Input
                id="stock"
                type="number"
                min={0}
                placeholder="10"
                value={formData.stock}
                onChange={(e) => setFormData({ ...formData, stock: parseInt(e.target.value) || 0 })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="emoji">圖示</Label>
              <Input
                id="emoji"
                placeholder="🎁"
                value={formData.emoji}
                onChange={(e) => setFormData({ ...formData, emoji: e.target.value })}
                className="text-center text-2xl"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">類型</Label>
              <select
                id="category"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as "privilege" | "physical" | "other" })}
                className="flex h-9 w-full rounded-md border border-gray-300 bg-white px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gray-200"
              >
                <option value="privilege">特權類</option>
                <option value="physical">實體類</option>
                <option value="other">其他</option>
              </select>
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              取消
            </Button>
            <Button type="submit">
              {isEditing ? "儲存變更" : "新增獎品"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ============================================
// Delete Confirmation Dialog
// ============================================

function DeleteConfirmDialog({
  open,
  onOpenChange,
  reward,
  onConfirm,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reward: OrganizationReward | null;
  onConfirm: () => void;
}) {
  if (!reward) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle>確認刪除</DialogTitle>
          <DialogDescription>
            確定要刪除「{reward.name}」嗎？此操作無法復原。
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button variant="destructive" onClick={onConfirm}>
            確認刪除
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================
// Main Component
// ============================================

export function OrgShopManagement() {
  const [rewards, setRewards] = useState<OrganizationReward[]>(MOCK_ORG_REWARDS);
  const [records] = useState<RedemptionRecord[]>(MOCK_REDEMPTION_RECORDS);
  const [activeTab, setActiveTab] = useState<"rewards" | "records">("rewards");
  const [searchQuery, setSearchQuery] = useState("");

  // Dialog states
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingReward, setEditingReward] = useState<OrganizationReward | null>(null);
  const [deletingReward, setDeletingReward] = useState<OrganizationReward | null>(null);

  // Stats
  const totalRewards = rewards.length;
  const totalStock = rewards.reduce((sum, r) => sum + r.stock, 0);
  const pendingRecords = records.filter((r) => r.status === "ready").length;
  const completedRecords = records.filter((r) => r.status === "completed").length;

  // Handlers
  const handleAddReward = (data: Partial<OrganizationReward>) => {
    const newReward: OrganizationReward = {
      id: `org-${Date.now()}`,
      name: data.name || "",
      description: data.description,
      price: data.price || 500,
      currency: "coins", // Organization rewards always use coins
      emoji: data.emoji || "🎁",
      stock: data.stock || 10,
      type: "physical",
      organizationId: "demo-org",
      organizationName: "Demo 補習班",
      category: (data.category as "privilege" | "physical" | "other") || "privilege",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setRewards([...rewards, newReward]);
  };

  const handleEditReward = (data: Partial<OrganizationReward>) => {
    if (!editingReward) return;
    setRewards(
      rewards.map((r) =>
        r.id === editingReward.id
          ? { ...r, ...data, updatedAt: new Date().toISOString() }
          : r
      )
    );
    setEditingReward(null);
  };

  const handleDeleteReward = () => {
    if (!deletingReward) return;
    setRewards(rewards.filter((r) => r.id !== deletingReward.id));
    setDeletingReward(null);
  };

  const handleMarkComplete = (recordId: string) => {
    // In real app, this would update the record status
    console.log("Mark complete:", recordId);
  };

  // Filtered data
  const filteredRewards = rewards.filter(
    (r) =>
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredRecords = records.filter(
    (r) =>
      r.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.rewardName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.redemptionCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">商店管理</h1>
            <p className="text-gray-500 text-sm mt-1">
              管理 Demo 補習班的專屬獎品
            </p>
          </div>
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            新增獎品
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatsCard
            title="獎品種類"
            value={totalRewards}
            description="目前上架中"
            icon={Package}
            color="bg-blue-500"
          />
          <StatsCard
            title="總庫存"
            value={totalStock}
            description="所有獎品合計"
            icon={Gift}
            color="bg-purple-500"
          />
          <StatsCard
            title="待領取"
            value={pendingRecords}
            description="等待學生領取"
            icon={Clock}
            color="bg-amber-500"
          />
          <StatsCard
            title="已完成"
            value={completedRecords}
            description="本月已領取"
            icon={Users}
            color="bg-green-500"
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("rewards")}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "rewards"
                ? "border-gray-900 text-gray-900"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            獎品列表
          </button>
          <button
            onClick={() => setActiveTab("records")}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "records"
                ? "border-gray-900 text-gray-900"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            兌換記錄
            {pendingRecords > 0 && (
              <Badge variant="destructive" className="ml-2">
                {pendingRecords}
              </Badge>
            )}
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder={activeTab === "rewards" ? "搜尋獎品名稱..." : "搜尋學生、獎品或兌換碼..."}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Content */}
        {activeTab === "rewards" ? (
          <Card>
            <CardHeader>
              <CardTitle>獎品列表</CardTitle>
              <CardDescription>
                共 {filteredRewards.length} 項獎品
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12"></TableHead>
                    <TableHead>名稱</TableHead>
                    <TableHead>類型</TableHead>
                    <TableHead className="text-right">價格</TableHead>
                    <TableHead className="text-right">庫存</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRewards.map((reward) => (
                    <TableRow key={reward.id}>
                      <TableCell>
                        <span className="text-2xl">{reward.emoji}</span>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{reward.name}</p>
                          <p className="text-sm text-gray-500">{reward.description}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={reward.category === "privilege" ? "default" : "secondary"}>
                          {reward.category === "privilege" ? "特權" : reward.category === "physical" ? "實體" : "其他"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {reward.price.toLocaleString()} 幣
                      </TableCell>
                      <TableCell className="text-right">
                        <span className={reward.stock <= 3 ? "text-red-600 font-medium" : ""}>
                          {reward.stock}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setEditingReward(reward)}
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeletingReward(reward)}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {filteredRewards.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                        {searchQuery ? "找不到符合的獎品" : "尚未新增任何獎品"}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>兌換記錄</CardTitle>
              <CardDescription>
                共 {filteredRecords.length} 筆記錄
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>學生</TableHead>
                    <TableHead>獎品</TableHead>
                    <TableHead>兌換碼</TableHead>
                    <TableHead className="text-right">金幣</TableHead>
                    <TableHead>時間</TableHead>
                    <TableHead>狀態</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">{record.studentName}</TableCell>
                      <TableCell>{record.rewardName}</TableCell>
                      <TableCell>
                        <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                          {record.redemptionCode}
                        </code>
                      </TableCell>
                      <TableCell className="text-right">
                        {record.currencySpent.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatDateTime(record.createdAt)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={record.status === "ready" ? "warning" : "success"}
                        >
                          {getStatusText(record.status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {record.status === "ready" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleMarkComplete(record.id)}
                          >
                            <Check className="w-4 h-4 mr-1" />
                            已領取
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                  {filteredRecords.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                        {searchQuery ? "找不到符合的記錄" : "尚無兌換記錄"}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Add Reward Dialog */}
      <RewardFormDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onSave={handleAddReward}
      />

      {/* Edit Reward Dialog */}
      <RewardFormDialog
        open={!!editingReward}
        onOpenChange={(open) => !open && setEditingReward(null)}
        reward={editingReward}
        onSave={handleEditReward}
      />

      {/* Delete Confirmation Dialog */}
      <DeleteConfirmDialog
        open={!!deletingReward}
        onOpenChange={(open) => !open && setDeletingReward(null)}
        reward={deletingReward}
        onConfirm={handleDeleteReward}
      />
    </div>
  );
}

export default OrgShopManagement;
