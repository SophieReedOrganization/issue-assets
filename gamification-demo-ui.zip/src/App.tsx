/**
 * App Root Component - 2026 EduBaania Tiffany/Teal Theme
 *
 * Design System: Tiffany/Teal + Clean + Modern
 * Target: Taiwan Middle/High School Students (2026)
 * Features: Light mode, clean surfaces, teal accents
 *
 * Includes:
 * - Student Demo (Home, Badges, Shop, Leaderboard)
 * - Org Admin (Dashboard, Products, Orders)
 * - Platform Admin (Dashboard, Products, Orders, Organizations)
 */

import { useState } from "react";
import {
  Home,
  Award,
  ShoppingBag,
  Trophy,
  Zap,
  Flame,
  Star,
  Store,
  Package,
  ClipboardList,
  LayoutDashboard,
  ArrowLeft,
  Settings,
  Globe,
  Building2,
} from "lucide-react";
import { cn } from "./lib/utils";
import { BadgesPageDemo } from "./pages/demo/BadgesPageDemo";
import { ShopPageDemo } from "./pages/demo/ShopPageDemo";
import { LeaderboardPageDemo } from "./pages/demo/LeaderboardPageDemo";
import { GamificationShowcase } from "./pages/demo/GamificationShowcase";
import { OrdersPageDemo } from "./pages/demo/OrdersPageDemo";
import { ShopDashboard, ProductsListPage, ProductFormPage, OrdersListPage } from "./pages/org-admin";
import { PlatformDashboard, PlatformProductsPage, PlatformOrdersPage, OrganizationsPage } from "./pages/platform-admin";
import { MOCK_USER_PROFILE, MOCK_ORDERS, MOCK_SHOP_STATS, MOCK_PLATFORM_STATS } from "./data/mockData";

// ============================================
// Types
// ============================================

type AppMode = "student" | "org-admin" | "platform-admin";
type StudentPage = "home" | "badges" | "shop" | "leaderboard" | "orders";
type OrgAdminPage = "dashboard" | "products" | "product-form" | "orders" | "reports";
type PlatformAdminPage = "dashboard" | "products" | "orders" | "organizations";

// ============================================
// Constants
// ============================================

const STUDENT_PAGES: { key: StudentPage; label: string; icon: typeof Home }[] = [
  { key: "home", label: "首頁", icon: Home },
  { key: "badges", label: "成就", icon: Award },
  { key: "shop", label: "商店", icon: ShoppingBag },
  { key: "leaderboard", label: "排行", icon: Trophy },
];

const ORG_ADMIN_PAGES: { key: OrgAdminPage; label: string; icon: typeof Store }[] = [
  { key: "dashboard", label: "總覽", icon: LayoutDashboard },
  { key: "products", label: "獎品", icon: Package },
  { key: "orders", label: "兌換", icon: ClipboardList },
];

const PLATFORM_ADMIN_PAGES: { key: PlatformAdminPage; label: string; icon: typeof Globe }[] = [
  { key: "dashboard", label: "總覽", icon: LayoutDashboard },
  { key: "products", label: "道具", icon: Package },
  { key: "orders", label: "兌換", icon: ClipboardList },
  { key: "organizations", label: "機構", icon: Building2 },
];

// ============================================
// Components
// ============================================

// XP Progress Ring Component
function XPRing({ current, max, level }: { current: number; max: number; level: number }) {
  const percentage = (current / max) * 100;
  const circumference = 2 * Math.PI * 18;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative w-12 h-12">
      <svg className="w-full h-full xp-ring" viewBox="0 0 40 40">
        <defs>
          <linearGradient id="tealGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0ABAB5" />
            <stop offset="100%" stopColor="#22D3EE" />
          </linearGradient>
        </defs>
        <circle
          className="xp-ring-bg"
          cx="20"
          cy="20"
          r="18"
          fill="none"
          strokeWidth="3"
        />
        <circle
          className="xp-ring-progress"
          cx="20"
          cy="20"
          r="18"
          fill="none"
          strokeWidth="3"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          stroke="url(#tealGradient)"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-sm font-display text-tiffany-600 font-bold">{level}</span>
      </div>
    </div>
  );
}

// Mode Switcher Component
function ModeSwitcher({
  mode,
  onModeChange,
}: {
  mode: AppMode;
  onModeChange: (mode: AppMode) => void;
}) {
  return (
    <div className="fixed bottom-24 md:bottom-6 right-4 z-50">
      <div className="card p-1 shadow-lg border-2 border-surface-border">
        <div className="flex gap-1">
          <button
            onClick={() => onModeChange("student")}
            className={cn(
              "px-3 py-2 rounded-lg text-xs font-display transition-all",
              mode === "student"
                ? "bg-tiffany-500 text-white"
                : "text-text-muted hover:bg-surface-hover"
            )}
          >
            Student
          </button>
          <button
            onClick={() => onModeChange("org-admin")}
            className={cn(
              "px-3 py-2 rounded-lg text-xs font-display transition-all",
              mode === "org-admin"
                ? "bg-accent-pink text-white"
                : "text-text-muted hover:bg-surface-hover"
            )}
          >
            Org Admin
          </button>
          <button
            onClick={() => onModeChange("platform-admin")}
            className={cn(
              "px-3 py-2 rounded-lg text-xs font-display transition-all",
              mode === "platform-admin"
                ? "bg-purple-500 text-white"
                : "text-text-muted hover:bg-surface-hover"
            )}
          >
            Platform
          </button>
        </div>
      </div>
    </div>
  );
}

// Student Navigation Header
function StudentHeader({
  activePage,
  onPageChange,
  pendingOrders,
}: {
  activePage: StudentPage;
  onPageChange: (page: StudentPage) => void;
  pendingOrders: number;
}) {
  return (
    <nav className="sticky top-0 z-50 bg-surface-card/95 backdrop-blur-md border-b border-surface-border shadow-card">
      <div className="container-app py-3">
        <div className="flex items-center gap-4">
          {/* Avatar & Level Ring */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="relative">
              <XPRing
                current={MOCK_USER_PROFILE.currentXp}
                max={MOCK_USER_PROFILE.xpToNextLevel}
                level={MOCK_USER_PROFILE.level}
              />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-br from-tiffany-500 to-accent-cyan flex items-center justify-center shadow-teal">
                <Star className="w-3 h-3 text-white" />
              </div>
            </div>

            {/* User Info - Hidden on mobile */}
            <div className="hidden sm:block">
              <p className="text-sm font-display text-text-primary">{MOCK_USER_PROFILE.displayName}</p>
              <div className="flex items-center gap-1 text-xs text-text-secondary">
                <Flame className="w-3 h-3 text-accent-orange" />
                <span>{MOCK_USER_PROFILE.currentStreak} 天連續</span>
              </div>
            </div>
          </div>

          {/* Tab Navigation - Center */}
          <div className="flex-1 flex justify-center">
            <div className="flex gap-1 p-1 rounded-2xl bg-surface-elevated border border-surface-border">
              {STUDENT_PAGES.map((page) => {
                const Icon = page.icon;
                const isActive = activePage === page.key;
                const hasBadge = page.key === "shop" && pendingOrders > 0;

                return (
                  <button
                    key={page.key}
                    onClick={() => onPageChange(page.key)}
                    className={cn(
                      "relative flex items-center gap-2 px-4 py-2.5 rounded-xl font-display text-sm",
                      "transition-all duration-300 cursor-pointer",
                      isActive
                        ? "bg-white text-tiffany-600 shadow-soft-md"
                        : "text-text-secondary hover:text-text-primary hover:bg-white/50"
                    )}
                  >
                    <Icon className={cn(
                      "w-4 h-4 transition-all",
                      isActive && "text-tiffany-500"
                    )} />
                    <span className="hidden sm:inline">{page.label}</span>
                    {hasBadge && (
                      <span className="absolute -top-1 -right-1 w-5 h-5 bg-accent-coral text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-pink animate-pulse">
                        {pendingOrders}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Currency Display */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {/* XP Badge */}
            <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl bg-tiffany-50 border border-tiffany-200">
              <Zap className="w-4 h-4 text-tiffany-600" />
              <span className="font-display text-sm text-tiffany-600">
                {MOCK_USER_PROFILE.totalXp.toLocaleString()}
              </span>
            </div>

            {/* Coins */}
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-tier-gold/10 border border-tier-gold/20">
              <span className="text-lg">🪙</span>
              <span className="font-display text-sm text-tier-gold">
                {MOCK_USER_PROFILE.coins.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

// Org Admin Sidebar Navigation
function OrgAdminSidebar({
  activePage,
  onPageChange,
  pendingOrders,
}: {
  activePage: OrgAdminPage;
  onPageChange: (page: OrgAdminPage) => void;
  pendingOrders: number;
}) {
  return (
    <aside className="hidden md:flex w-64 flex-col bg-surface-card border-r border-surface-border">
      {/* Logo */}
      <div className="p-6 border-b border-surface-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent-pink to-tiffany-500 flex items-center justify-center">
            <Store className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-display text-text-primary">Demo 補習班</p>
            <p className="text-xs text-text-muted">商店管理</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {ORG_ADMIN_PAGES.map((page) => {
          const Icon = page.icon;
          const isActive = activePage === page.key || (page.key === "products" && activePage === "product-form");
          const hasBadge = page.key === "orders" && pendingOrders > 0;

          return (
            <button
              key={page.key}
              onClick={() => onPageChange(page.key)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-display text-sm transition-all",
                isActive
                  ? "bg-accent-pink/10 text-accent-pink"
                  : "text-text-secondary hover:bg-surface-hover hover:text-text-primary"
              )}
            >
              <Icon className="w-5 h-5" />
              {page.label}
              {hasBadge && (
                <span className="ml-auto px-2 py-0.5 bg-accent-coral text-white text-xs font-bold rounded-full">
                  {pendingOrders}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-surface-border">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-text-muted hover:bg-surface-hover transition-colors">
          <Settings className="w-5 h-5" />
          <span className="text-sm">設定</span>
        </button>
      </div>
    </aside>
  );
}

// Org Admin Mobile Header
function OrgAdminMobileHeader({
  activePage,
  onPageChange,
  pendingOrders,
}: {
  activePage: OrgAdminPage;
  onPageChange: (page: OrgAdminPage) => void;
  pendingOrders: number;
}) {
  return (
    <nav className="md:hidden sticky top-0 z-50 bg-surface-card/95 backdrop-blur-md border-b border-surface-border shadow-card">
      <div className="px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent-pink to-tiffany-500 flex items-center justify-center">
              <Store className="w-4 h-4 text-white" />
            </div>
            <p className="font-display text-text-primary text-sm">商店管理</p>
          </div>
        </div>

        <div className="flex gap-1 p-1 rounded-xl bg-surface-elevated">
          {ORG_ADMIN_PAGES.map((page) => {
            const Icon = page.icon;
            const isActive = activePage === page.key || (page.key === "products" && activePage === "product-form");
            const hasBadge = page.key === "orders" && pendingOrders > 0;

            return (
              <button
                key={page.key}
                onClick={() => onPageChange(page.key)}
                className={cn(
                  "relative flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-display transition-all",
                  isActive
                    ? "bg-white text-accent-pink shadow-sm"
                    : "text-text-muted"
                )}
              >
                <Icon className="w-4 h-4" />
                {page.label}
                {hasBadge && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-accent-coral text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                    {pendingOrders}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

// Student Mobile Bottom Navigation
function StudentMobileNav({
  activePage,
  onPageChange,
  pendingOrders,
}: {
  activePage: StudentPage;
  onPageChange: (page: StudentPage) => void;
  pendingOrders: number;
}) {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-surface-card/95 backdrop-blur-md border-t border-surface-border shadow-card pb-safe z-50">
      <div className="flex justify-around items-center py-2 px-2">
        {STUDENT_PAGES.map((page) => {
          const Icon = page.icon;
          const isActive = activePage === page.key;
          const hasBadge = page.key === "shop" && pendingOrders > 0;

          return (
            <button
              key={page.key}
              onClick={() => onPageChange(page.key)}
              className={cn(
                "relative flex flex-col items-center gap-1 px-4 py-2 rounded-xl",
                "transition-all duration-300 cursor-pointer",
                isActive
                  ? "text-tiffany-600"
                  : "text-text-muted hover:text-text-secondary"
              )}
            >
              <div
                className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center transition-all",
                  isActive
                    ? "bg-tiffany-50 shadow-teal"
                    : "hover:bg-surface-elevated"
                )}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span
                className={cn(
                  "text-[10px] font-display tracking-wide",
                  isActive ? "text-tiffany-600" : "text-text-muted"
                )}
              >
                {page.label}
              </span>
              {hasBadge && (
                <span className="absolute top-0 right-2 w-4 h-4 bg-accent-coral text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow-pink">
                  {pendingOrders}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// Platform Admin Sidebar Navigation
function PlatformAdminSidebar({
  activePage,
  onPageChange,
  pendingOrders,
}: {
  activePage: PlatformAdminPage;
  onPageChange: (page: PlatformAdminPage) => void;
  pendingOrders: number;
}) {
  return (
    <aside className="hidden md:flex w-64 flex-col bg-surface-card border-r border-surface-border">
      {/* Logo */}
      <div className="p-6 border-b border-surface-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-accent-pink flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-display text-text-primary">EduBaania</p>
            <p className="text-xs text-text-muted">平台管理</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {PLATFORM_ADMIN_PAGES.map((page) => {
          const Icon = page.icon;
          const isActive = activePage === page.key;
          const hasBadge = page.key === "orders" && pendingOrders > 0;

          return (
            <button
              key={page.key}
              onClick={() => onPageChange(page.key)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-display text-sm transition-all",
                isActive
                  ? "bg-purple-500/10 text-purple-600"
                  : "text-text-secondary hover:bg-surface-hover hover:text-text-primary"
              )}
            >
              <Icon className="w-5 h-5" />
              {page.label}
              {hasBadge && (
                <span className="ml-auto px-2 py-0.5 bg-accent-coral text-white text-xs font-bold rounded-full">
                  {pendingOrders}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-surface-border">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-text-muted hover:bg-surface-hover transition-colors">
          <Settings className="w-5 h-5" />
          <span className="text-sm">設定</span>
        </button>
      </div>
    </aside>
  );
}

// Platform Admin Mobile Header
function PlatformAdminMobileHeader({
  activePage,
  onPageChange,
  pendingOrders,
}: {
  activePage: PlatformAdminPage;
  onPageChange: (page: PlatformAdminPage) => void;
  pendingOrders: number;
}) {
  return (
    <nav className="md:hidden sticky top-0 z-50 bg-surface-card/95 backdrop-blur-md border-b border-surface-border shadow-card">
      <div className="px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-accent-pink flex items-center justify-center">
              <Globe className="w-4 h-4 text-white" />
            </div>
            <p className="font-display text-text-primary text-sm">平台管理</p>
          </div>
        </div>

        <div className="flex gap-1 p-1 rounded-xl bg-surface-elevated overflow-x-auto">
          {PLATFORM_ADMIN_PAGES.map((page) => {
            const Icon = page.icon;
            const isActive = activePage === page.key;
            const hasBadge = page.key === "orders" && pendingOrders > 0;

            return (
              <button
                key={page.key}
                onClick={() => onPageChange(page.key)}
                className={cn(
                  "relative flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-display transition-all whitespace-nowrap",
                  isActive
                    ? "bg-white text-purple-600 shadow-sm"
                    : "text-text-muted"
                )}
              >
                <Icon className="w-4 h-4" />
                {page.label}
                {hasBadge && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-accent-coral text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                    {pendingOrders}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

// ============================================
// Main App Component
// ============================================

function App() {
  const [appMode, setAppMode] = useState<AppMode>("student");
  const [studentPage, setStudentPage] = useState<StudentPage>("home");
  const [orgAdminPage, setOrgAdminPage] = useState<OrgAdminPage>("dashboard");
  const [platformAdminPage, setPlatformAdminPage] = useState<PlatformAdminPage>("dashboard");
  const [editingProductId, setEditingProductId] = useState<string | undefined>();

  // Count pending orders for badges
  const studentPendingOrders = MOCK_ORDERS.filter(
    (o) => o.status === "ready" || o.status === "pending"
  ).length;

  const adminPendingOrders = MOCK_SHOP_STATS.pendingOrders;
  const platformPendingOrders = MOCK_PLATFORM_STATS.pendingOrders;

  // Handle Org Admin page navigation
  const handleOrgAdminNavigate = (page: string) => {
    if (page === "product-form") {
      setEditingProductId(undefined);
      setOrgAdminPage("product-form");
    } else {
      setOrgAdminPage(page as OrgAdminPage);
    }
  };

  // Handle Platform Admin page navigation
  const handlePlatformAdminNavigate = (page: string) => {
    setPlatformAdminPage(page as PlatformAdminPage);
  };

  // Handle product edit
  const handleEditProduct = (productId: string) => {
    setEditingProductId(productId);
    setOrgAdminPage("product-form");
  };

  // Handle product form save
  const handleProductSave = () => {
    setOrgAdminPage("products");
    setEditingProductId(undefined);
  };

  // Render Student App
  if (appMode === "student") {
    return (
      <div className="min-h-screen flex flex-col bg-teal-mesh">
        <StudentHeader
          activePage={studentPage}
          onPageChange={setStudentPage}
          pendingOrders={studentPendingOrders}
        />

        <main className="flex-1">
          {studentPage === "home" && <GamificationShowcase />}
          {studentPage === "badges" && <BadgesPageDemo />}
          {studentPage === "shop" && <ShopPageDemo />}
          {studentPage === "leaderboard" && <LeaderboardPageDemo />}
          {studentPage === "orders" && <OrdersPageDemo />}
        </main>

        <StudentMobileNav
          activePage={studentPage}
          onPageChange={setStudentPage}
          pendingOrders={studentPendingOrders}
        />

        {/* Spacer for mobile bottom nav */}
        <div className="md:hidden h-24" />

        <ModeSwitcher mode={appMode} onModeChange={setAppMode} />
      </div>
    );
  }

  // Render Platform Admin App
  if (appMode === "platform-admin") {
    return (
      <div className="min-h-screen flex bg-teal-mesh">
        <PlatformAdminSidebar
          activePage={platformAdminPage}
          onPageChange={setPlatformAdminPage}
          pendingOrders={platformPendingOrders}
        />

        <div className="flex-1 flex flex-col min-h-screen">
          <PlatformAdminMobileHeader
            activePage={platformAdminPage}
            onPageChange={setPlatformAdminPage}
            pendingOrders={platformPendingOrders}
          />

          <main className="flex-1">
            {platformAdminPage === "dashboard" && (
              <PlatformDashboard onNavigate={handlePlatformAdminNavigate} />
            )}
            {platformAdminPage === "products" && <PlatformProductsPage />}
            {platformAdminPage === "orders" && <PlatformOrdersPage />}
            {platformAdminPage === "organizations" && <OrganizationsPage />}
          </main>
        </div>

        <ModeSwitcher mode={appMode} onModeChange={setAppMode} />
      </div>
    );
  }

  // Render Org Admin App
  return (
    <div className="min-h-screen flex bg-teal-mesh">
      <OrgAdminSidebar
        activePage={orgAdminPage}
        onPageChange={handleOrgAdminNavigate}
        pendingOrders={adminPendingOrders}
      />

      <div className="flex-1 flex flex-col min-h-screen">
        <OrgAdminMobileHeader
          activePage={orgAdminPage}
          onPageChange={handleOrgAdminNavigate}
          pendingOrders={adminPendingOrders}
        />

        <main className="flex-1">
          {orgAdminPage === "dashboard" && (
            <ShopDashboard onNavigate={handleOrgAdminNavigate} />
          )}
          {orgAdminPage === "products" && <ProductsListPage />}
          {orgAdminPage === "product-form" && (
            <ProductFormPage
              productId={editingProductId}
              onBack={() => setOrgAdminPage("products")}
              onSave={handleProductSave}
            />
          )}
          {orgAdminPage === "orders" && <OrdersListPage />}
        </main>
      </div>

      <ModeSwitcher mode={appMode} onModeChange={setAppMode} />
    </div>
  );
}

export default App;
