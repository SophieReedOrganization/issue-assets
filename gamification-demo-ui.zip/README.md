# Gamification Demo - 遊戲化系統展示

這是一個獨立的 Demo 專案，用於展示遊戲化獎勵系統的 UI 設計。

## 專案結構

```
gamification-demo/
├── src/
│   └── pages/
│       └── demo/
│           ├── GamificationDemoPage.tsx   # 基礎 Demo（Tabs 版本）
│           ├── GamificationShowcase.tsx   # 增強 Demo（優化設計）
│           └── index.ts                   # 導出
├── docs/                                  # 規格文檔（連結到 ../docs/gamification-system/）
└── README.md
```

## Demo 頁面

### 1. GamificationDemoPage (基礎版)
- 三個 Tab：徽章、商店、排行榜
- 基本的 Tiffany Green 主題
- Mock 資料展示

### 2. GamificationShowcase (增強版)
基於 [Claude blog 文章](https://claude.com/blog/improving-frontend-design-through-skills) 的設計原則優化：

- **視覺深度**: Blur 效果、層疊背景、發光徽章
- **流暢動畫**: animate-in, fade-in, slide-in-from-bottom
- **豐富色彩**: oklch 設計 tokens、漸層系統
- **微互動**: Hover 縮放、進度環、徽章光暈
- **統一主題**: Tiffany Green 主色 + 暖金色系

### 包含功能
- **ProfileHeader**: 頭像框、XP 進度條、等級、連勝、金幣
- **BadgesSection**: 6 個徽章（銅/銀/金/鑽石階級）+ 光暈效果
- **ShopPreview**: 6 個商店物品（擁有/鎖定狀態）
- **LeaderboardPreview**: Top 7 排名 + 名次變化指示
- **DailyRewards**: 每週簽到日曆
- **BadgeModal**: 徽章詳情彈窗 + 獎勵顯示

## 整合到 Student App

要將這些 Demo 頁面整合到實際的 Student App，請參考：

### 1. 複製檔案
```bash
cp -r src/pages/demo/* apps/student/src/pages/demo/
```

### 2. 更新路由配置
```typescript
// apps/student/src/config/routes.ts
import { GamificationDemoPage, GamificationShowcase } from "../pages/demo";

// 在 protectedRoutes 陣列中添加：
{
  path: "demo/gamification",
  component: GamificationDemoPage,
  requiresAuth: false,
  requiresMainLayout: false,
},
{
  path: "demo/showcase",
  component: GamificationShowcase,
  requiresAuth: false,
  requiresMainLayout: false,
},
```

### 3. 更新 RouteGenerator（支援公開路由）
如果需要支援 `requiresAuth: false`，需要更新 `RouteGenerator.tsx`：

```typescript
// 在 generateProtectedRoutes 函數中
const requiresAuth = config.requiresAuth !== false;

// 根據 requiresAuth 決定是否包裹保護組件
if (requiresAuth) {
  return (
    <ProtectedRoute>
      <StudentRouteGuard>{element}</StudentRouteGuard>
    </ProtectedRoute>
  );
}
return element;
```

### 4. 存取 Demo
- `/:orgSlug/demo/gamification` - 基礎版
- `/:orgSlug/demo/showcase` - 增強版

## 依賴套件

這些 Demo 使用的套件與 Student App 一致：
- React 19
- TypeScript 5.8.3
- Tailwind CSS 4 (oklch 色彩)
- lucide-react (圖示)
- @workspace/ui (cn utility)

## 規格文檔

完整的系統規格文檔位於：
- `../docs/gamification-system/README.md` - 系統總覽
- `../docs/gamification-system/01-database-schema.md` - 資料庫設計
- `../docs/gamification-system/02-api-specification.md` - API 規格
- `../docs/gamification-system/03-reward-rules.md` - 獎勵規則
- `../docs/gamification-system/04-badge-system.md` - 徽章系統
- `../docs/gamification-system/05-ai-generation.md` - AI 生成
- `../docs/gamification-system/06-leaderboard-system.md` - 排行榜
- `../docs/gamification-system/07-shop-system.md` - 商店系統
- `../docs/gamification-system/08-frontend-integration.md` - 前端整合
- `../docs/gamification-system/09-demo-pages.md` - Demo 頁面程式碼
