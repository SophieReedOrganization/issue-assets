# 頭像框與徽章規格書 v2

> 設計原則：從樸素到華麗的漸進式視覺體驗，價格越高視覺效果越豐富

---

## 一、設計語言

### 視覺層級定義

| 層級 | 稀有度 | 視覺特徵 | 動態效果 |
|------|--------|----------|----------|
| T1 | Common (普通) | 單色、簡約線條、無裝飾 | 無 |
| T2 | Bronze (銅) | 雙色漸層、簡單圖案邊框 | 無 |
| T3 | Silver (銀) | 三色漸層、精緻花紋、微光澤 | 輕微閃爍 |
| T4 | Gold (金) | 多彩漸層、華麗裝飾、金屬質感 | 持續光暈 |
| T5 | Legendary (傳說) | 全彩動態、粒子效果、獨特主題 | 動態粒子+光環 |

### 配色系統

```
T1 (Common):     #E5E7EB → #D1D5DB (灰階)
T2 (Bronze):     #CD7F32 → #B87333 (銅色)
T3 (Silver):     #C0C0C0 → #A8A9AD → #E8E8E8 (銀色帶光澤)
T4 (Gold):       #FFD700 → #FFA500 → #FF8C00 (金色漸層)
T5 (Legendary):  彩虹漸層 + 主題色 (依主題變化)
```

---

## 二、頭像框規格（31 個）

### A. 免費贈送（4 個）- T1 Common

| ID | 名稱 | 描述 | 視覺設計 | 取得方式 |
|----|------|------|----------|----------|
| frame_default | 素面圓框 | 乾淨簡約的基礎框 | 2px 灰色實線圓框，無裝飾 | 註冊即得 |
| frame_welcome | 新手小白框 | 歡迎新同學 | 3px 淺藍虛線框，角落有小星星 | 完成新手引導 |
| frame_first_task | 起步框 | 第一步最重要 | 3px 淺綠實線框，底部有小葉子 | 完成首個任務 |
| frame_first_exam | 初試身手框 | 勇敢嘗試 | 3px 淺橘實線框，頂部有小鉛筆 | 完成首份試卷 |

**Prompt 風格**: Simple, clean, minimalist avatar frame, single color outline, no decorations, flat design, white background, 512x512

---

### B. 成就解鎖 - 任務系列（3 個）

| ID | 名稱 | 描述 | 稀有度 | 解鎖條件 | 視覺設計 |
|----|------|------|--------|----------|----------|
| frame_task_bronze | 勤勞蜜蜂框 | 努力的證明 | T2 Bronze | 累計 50 任務 | 銅色邊框+小蜜蜂圖案 |
| frame_task_silver | 任務達人框 | 穩定輸出 | T3 Silver | 累計 200 任務 | 銀色漸層+齒輪裝飾 |
| frame_task_gold | 任務之王框 | 傳說中的肝帝 | T4 Gold | 累計 500 任務 | 金色華麗框+皇冠+閃光 |

---

### C. 成就解鎖 - 試卷系列（3 個）

| ID | 名稱 | 描述 | 稀有度 | 解鎖條件 | 視覺設計 |
|----|------|------|--------|----------|----------|
| frame_exam_bronze | 考試新手框 | 開始挑戰 | T2 Bronze | 累計 15 試卷 | 銅色+試卷圖案 |
| frame_exam_silver | 考場老手框 | 身經百戰 | T3 Silver | 累計 60 試卷 | 銀色+書本裝飾 |
| frame_exam_gold | 考神認證框 | 考試之神 | T4 Gold | 累計 100 試卷 | 金色+光環+試卷飄飛 |

---

### D. 成就解鎖 - 滿分系列（3 個）

| ID | 名稱 | 描述 | 稀有度 | 解鎖條件 | 視覺設計 |
|----|------|------|--------|----------|----------|
| frame_perfect_bronze | 滿分新星框 | 初嚐滿分 | T2 Bronze | 累計 5 滿分 | 銅色+100分徽章 |
| frame_perfect_silver | 滿分達人框 | 滿分常客 | T3 Silver | 累計 25 滿分 | 銀色+星星環繞 |
| frame_perfect_gold | 零失誤框 | 完美主義 | T4 Gold | 累計 50 滿分 | 金色+鑽石+光芒 |

---

### E. 成就解鎖 - 誠實系列（3 個）

| ID | 名稱 | 描述 | 稀有度 | 解鎖條件 | 視覺設計 |
|----|------|------|--------|----------|----------|
| frame_honest_bronze | 誠實小將框 | 腳踏實地 | T2 Bronze | 累計 20 無猜題 | 銅色+愛心圖案 |
| frame_honest_silver | 實力派框 | 真材實料 | T3 Silver | 累計 60 無猜題 | 銀色+盾牌裝飾 |
| frame_honest_gold | 硬底子框 | 靠實力說話 | T4 Gold | 累計 100 無猜題 | 金色+勳章+光環 |

---

### F. 金幣購買 - 入門級（3 個）200-300 幣 / Lv.1-2

| ID | 名稱 | 描述 | 稀有度 | 價格 | 等級 | 視覺設計 |
|----|------|------|--------|------|------|----------|
| frame_simple_blue | 天空藍框 | 清爽的藍 | T2 Bronze | 200 | Lv.1 | 淺藍漸層，簡單雲朵 |
| frame_simple_green | 草地綠框 | 自然的綠 | T2 Bronze | 200 | Lv.1 | 淺綠漸層，簡單葉子 |
| frame_simple_pink | 櫻花粉框 | 可愛的粉 | T2 Bronze | 250 | Lv.2 | 粉色漸層，小花瓣 |

---

### G. 金幣購買 - 基礎級（3 個）300-400 幣 / Lv.3-4

| ID | 名稱 | 描述 | 稀有度 | 價格 | 等級 | 視覺設計 |
|----|------|------|--------|------|------|----------|
| frame_rainbow_lite | 輕彩虹框 | 七彩繽紛 | T3 Silver | 350 | Lv.3 | 柔和彩虹漸層 |
| frame_starry_lite | 星空輕框 | 點點星光 | T3 Silver | 350 | Lv.3 | 深藍+散落星星 |
| frame_candy_lite | 糖果輕框 | 甜甜的 | T3 Silver | 400 | Lv.4 | 粉彩條紋 |

---

### H. 金幣購買 - 進階級（3 個）500-700 幣 / Lv.5-7

| ID | 名稱 | 描述 | 稀有度 | 價格 | 等級 | 視覺設計 |
|----|------|------|--------|------|------|----------|
| frame_flame | 烈焰框 | 燃燒吧 | T3 Silver | 500 | Lv.5 | 橘紅火焰漸層+火花 |
| frame_ocean | 深海框 | 海洋之心 | T3 Silver | 550 | Lv.6 | 深藍漸層+波浪+泡泡 |
| frame_sakura | 櫻花雨框 | 浪漫飄落 | T4 Gold | 700 | Lv.7 | 粉色+飄落櫻花 |

---

### I. 金幣購買 - 高級級（3 個）800-1200 幣 / Lv.8-12

| ID | 名稱 | 描述 | 稀有度 | 價格 | 等級 | 視覺設計 |
|----|------|------|--------|------|------|----------|
| frame_neon | 霓虹派對框 | 夜店風 | T4 Gold | 800 | Lv.8 | 多彩霓虹+發光效果 |
| frame_crystal | 水晶寶石框 | 璀璨奪目 | T4 Gold | 1000 | Lv.10 | 透明水晶+折射光 |
| frame_galaxy | 銀河星雲框 | 宇宙浩瀚 | T4 Gold | 1200 | Lv.12 | 紫藍星雲+閃爍星 |

---

### J. 金幣購買 - 頂級（3 個）1500-3000 幣 / Lv.15-20

| ID | 名稱 | 描述 | 稀有度 | 價格 | 等級 | 視覺設計 |
|----|------|------|--------|------|------|----------|
| frame_phoenix | 鳳凰涅槃框 | 浴火重生 | T5 Legendary | 1500 | Lv.15 | 火紅鳳凰羽毛+火焰粒子 |
| frame_dragon | 神龍騰雲框 | 龍的傳人 | T5 Legendary | 2000 | Lv.18 | 金龍盤繞+祥雲 |
| frame_ultimate | 至尊榮耀框 | 頂級尊貴 | T5 Legendary | 3000 | Lv.20 | 全彩流光+皇冠+粒子 |

---

## 三、徽章視覺規格（64 個）

### 視覺層級對應

| 徽章等級 | 視覺特徵 | 邊框 | 背景 | 圖示風格 |
|----------|----------|------|------|----------|
| Bronze | 銅色金屬邊框 | 2px 銅色 | 米色/淺棕 | 簡約線條圖示 |
| Silver | 銀色漸層邊框 | 3px 銀色+光澤 | 淺灰漸層 | 精緻圖示+微陰影 |
| Gold | 金色華麗邊框 | 4px 金色+發光 | 金色漸層 | 立體圖示+光芒 |
| Diamond | 鑽石多彩邊框 | 5px 彩虹+粒子 | 漸層+光暈 | 華麗圖示+動態 |

### 徽章尺寸規格

- 標準顯示：64x64 px
- 詳情頁面：128x128 px
- 檔案格式：PNG with transparency
- 圖檔命名：{category}_{number}.png

---

## 四、圖片生成 Prompt 模板

### 頭像框 Prompt 結構

```
[Tier] avatar frame for mobile app, [主題描述], [顏色方案],
[裝飾元素], [效果],
circular frame design, centered empty space for profile picture,
high quality, game UI style, 512x512, PNG transparent background
```

#### 範例 Prompts

**T1 Common - 素面圓框**
```
Simple minimalist avatar frame, thin gray outline, clean design,
no decorations, flat style,
circular frame design, centered empty space for profile picture,
high quality, mobile app UI, 512x512, PNG transparent background
```

**T2 Bronze - 勤勞蜜蜂框**
```
Bronze tier avatar frame, copper metallic border, cute bee decorations,
honeycomb pattern subtle background, warm amber tones,
circular frame design, centered empty space for profile picture,
high quality, game UI style, 512x512, PNG transparent background
```

**T3 Silver - 任務達人框**
```
Silver tier avatar frame, shiny silver gradient border, gear and cog decorations,
mechanical theme, cool silver and steel blue colors, subtle shine effect,
circular frame design, centered empty space for profile picture,
high quality, game UI style, 512x512, PNG transparent background
```

**T4 Gold - 任務之王框**
```
Gold tier avatar frame, luxurious golden border with ornate decorations,
royal crown on top, sparkling gems, radiant golden glow effect,
rich gold and amber gradient, premium feel,
circular frame design, centered empty space for profile picture,
high quality, game UI style, 512x512, PNG transparent background
```

**T5 Legendary - 鳳凰涅槃框**
```
Legendary tier avatar frame, majestic phoenix feathers surrounding the frame,
vibrant red and orange fire effects, golden accents, magical particles,
dynamic flame animation style, epic and powerful,
circular frame design, centered empty space for profile picture,
high quality, premium game UI style, 512x512, PNG transparent background
```

---

### 徽章 Prompt 結構

```
[Tier] achievement badge, [主題圖示], [顏色方案],
[邊框樣式], [背景效果],
game achievement icon style, 128x128, PNG transparent background
```

#### 範例 Prompts

**Bronze 徽章 - 剛開始而已**
```
Bronze achievement badge, open book icon with pencil,
copper metallic border, cream background,
simple clean design, encouraging style,
game achievement icon, 128x128, PNG transparent background
```

**Diamond 徽章 - 傳說中的捲王**
```
Diamond achievement badge, majestic scroll with golden crown,
rainbow prismatic border with sparkles, purple and gold gradient background,
glowing effects, legendary aura, premium feel,
game achievement icon, 128x128, PNG transparent background
```

---

## 五、檔案結構

```
public/assets/
├── frames/                    # 當前使用的頭像框
│   ├── frame_default.png
│   ├── frame_welcome.png
│   └── ... (31 files)
├── frames_backup_v2_YYYYMMDD/ # 本次備份
├── badges/                    # 徽章圖片
│   ├── task_10.png
│   └── ... (64 files)
└── badges_backup/             # 徽章備份（如需要）
```

---

## 六、實作優先順序

### Phase 1: 核心頭像框（優先生成）
1. 4 個免費框（T1）
2. 12 個成就解鎖框（T2-T4）
3. 3 個入門購買框（T2）

### Phase 2: 進階頭像框
4. 3 個基礎購買框（T3）
5. 3 個進階購買框（T3-T4）

### Phase 3: 頂級頭像框
6. 3 個高級購買框（T4）
7. 3 個頂級購買框（T5）

### Phase 4: 徽章更新（如需要）
- 依照新視覺系統重新生成 64 個徽章

---

## 七、技術備註

### 圖片生成建議
- 使用 Gemini 3 Pro Image 或 DALL-E 3
- 保持風格一致性，建議同批次生成
- 輸出格式：PNG，透明背景
- 頭像框尺寸：512x512（縮放顯示）
- 徽章尺寸：128x128

### 前端整合
- 更新 `mockData.ts` 中的 `MOCK_FRAMES` 陣列
- 確保 `imageUrl` 路徑正確
- 測試各等級視覺效果呈現
