# 互動講義 HTML 遊戲化整合規格書

> 定義互動講義（HTML 任務）如何與遊戲化系統整合

---

## 一、概述

### 1.1 設計理念

每個互動講義（HTML 任務）都是一個獨立的學習單元，具有：
- **自己的玩法**：拖拉、選擇、填空、配對、遊戲等
- **自己的評分邏輯**：由 HTML 內部決定表現好壞
- **標準化輸出**：完成後傳遞 `xp` 和 `coins` 給父層

父層（App）**不管內部邏輯**，只接收最終的 XP 和金幣數值。

### 1.2 架構圖

```
┌─────────────────────────────────────────────────────────┐
│                    學生 App（父層）                       │
│                                                         │
│  接收 postMessage → 更新學生 XP/金幣 → 觸發徽章檢查      │
└─────────────────────────────────────────────────────────┘
                          ▲
                          │ postMessage
                          │ { type: 'TASK_COMPLETE', xp, coins, ... }
                          │
┌─────────────────────────────────────────────────────────┐
│              互動講義 HTML（iframe）                      │
│                                                         │
│  內部玩法 → 評分邏輯 → 計算 XP/金幣 → 發送結果           │
└─────────────────────────────────────────────────────────┘
```

---

## 二、通訊協議

### 2.1 HTML → App（任務完成）

當學生完成任務時，HTML 發送以下訊息：

```typescript
interface TaskCompleteMessage {
  type: 'TASK_COMPLETE';
  payload: {
    xp: number;           // 獲得的經驗值（0-100）
    coins: number;        // 獲得的金幣（0-30）
    completionRate: number; // 完成率 0-100%（可選，供分析用）
    timeSpent: number;    // 花費秒數（可選，供分析用）
    metadata?: {          // 額外資訊（可選）
      attempts?: number;  // 嘗試次數
      hints?: number;     // 使用提示次數
      [key: string]: any;
    };
  };
}
```

**發送範例：**

```javascript
// 任務完成時發送
window.parent.postMessage({
  type: 'TASK_COMPLETE',
  payload: {
    xp: 8,
    coins: 2,
    completionRate: 80,
    timeSpent: 120
  }
}, '*');
```

### 2.2 App → HTML（初始化資訊）

App 可選擇性傳遞初始化資訊給 HTML：

```typescript
interface TaskInitMessage {
  type: 'TASK_INIT';
  payload: {
    studentId: string;
    studentLevel: number;
    taskId: string;
    maxXp: number;        // 此任務最大可獲得 XP
    maxCoins: number;     // 此任務最大可獲得金幣
  };
}
```

---

## 三、XP 與金幣計算規則

### 3.1 任務難度分級

| 難度 | 最大 XP | 最大金幣 | 說明 |
|------|---------|----------|------|
| 簡單 | 10 XP | 3 幣 | 基礎概念、簡單互動 |
| 中等 | 15 XP | 5 幣 | 需要思考、多步驟 |
| 困難 | 20 XP | 8 幣 | 複雜邏輯、高難度挑戰 |
| 挑戰 | 30 XP | 12 幣 | 綜合應用、限時挑戰 |

### 3.2 評分公式（建議）

HTML 內部根據學生表現計算獎勵：

```javascript
// 基礎公式
const baseXp = taskConfig.maxXp;
const baseCoins = taskConfig.maxCoins;

// 根據完成率調整
const completionMultiplier = completionRate / 100; // 0-1

// 根據嘗試次數調整（可選）
const attemptPenalty = Math.max(0, 1 - (attempts - 1) * 0.1); // 每多一次 -10%

// 最終計算
const finalXp = Math.round(baseXp * completionMultiplier * attemptPenalty);
const finalCoins = Math.round(baseCoins * completionMultiplier * attemptPenalty);
```

### 3.3 最低獎勵保底

為避免學生挫折感，設定最低獎勵：

| 情況 | 最低 XP | 最低金幣 |
|------|---------|----------|
| 完成任務（不論表現）| 2 XP | 1 幣 |
| 放棄/未完成 | 0 XP | 0 幣 |

---

## 四、常見任務類型與獎勵設計

### 4.1 選擇題類型

```javascript
// 配置
const config = {
  maxXp: 10,
  maxCoins: 3,
  totalQuestions: 5
};

// 計算
function calculateReward(correctAnswers, totalQuestions) {
  const rate = correctAnswers / totalQuestions;
  return {
    xp: Math.max(2, Math.round(config.maxXp * rate)),
    coins: Math.max(1, Math.round(config.maxCoins * rate)),
    completionRate: Math.round(rate * 100)
  };
}

// 範例：答對 4/5 題
// → xp: 8, coins: 2, completionRate: 80
```

### 4.2 拖拉配對類型

```javascript
const config = {
  maxXp: 15,
  maxCoins: 5,
  totalPairs: 6,
  maxAttempts: 3  // 每個配對最多嘗試次數
};

function calculateReward(results) {
  // results: [{ correct: true, attempts: 1 }, ...]

  let score = 0;
  results.forEach(r => {
    if (r.correct) {
      // 首次就對得滿分，多次嘗試扣分
      score += Math.max(0.5, 1 - (r.attempts - 1) * 0.25);
    }
  });

  const rate = score / results.length;
  return {
    xp: Math.max(2, Math.round(config.maxXp * rate)),
    coins: Math.max(1, Math.round(config.maxCoins * rate)),
    completionRate: Math.round(rate * 100)
  };
}
```

### 4.3 填空題類型

```javascript
const config = {
  maxXp: 12,
  maxCoins: 4,
  totalBlanks: 4
};

function calculateReward(correctBlanks, totalBlanks, hintsUsed) {
  const baseRate = correctBlanks / totalBlanks;
  const hintPenalty = hintsUsed * 0.1; // 每用一次提示 -10%
  const rate = Math.max(0, baseRate - hintPenalty);

  return {
    xp: Math.max(2, Math.round(config.maxXp * rate)),
    coins: Math.max(1, Math.round(config.maxCoins * rate)),
    completionRate: Math.round(rate * 100),
    metadata: { hintsUsed }
  };
}
```

### 4.4 互動遊戲類型

```javascript
const config = {
  maxXp: 20,
  maxCoins: 8,
  targetScore: 1000,
  timeLimit: 120  // 秒
};

function calculateReward(score, timeSpent, lives) {
  // 分數比例
  const scoreRate = Math.min(1, score / config.targetScore);

  // 時間獎勵（提早完成加分）
  const timeBonus = timeSpent < config.timeLimit * 0.7 ? 1.1 : 1;

  // 生命懲罰
  const livePenalty = Math.max(0.5, 1 - (3 - lives) * 0.15);

  const rate = scoreRate * timeBonus * livePenalty;

  return {
    xp: Math.max(2, Math.round(config.maxXp * rate)),
    coins: Math.max(1, Math.round(config.maxCoins * rate)),
    completionRate: Math.round(Math.min(100, rate * 100)),
    timeSpent,
    metadata: { score, lives }
  };
}
```

### 4.5 閱讀理解類型

```javascript
const config = {
  maxXp: 10,
  maxCoins: 3,
  minReadTime: 60,  // 最少閱讀秒數
  questions: 3
};

function calculateReward(correctAnswers, timeSpent) {
  // 閱讀時間檢查（防止跳過）
  if (timeSpent < config.minReadTime * 0.5) {
    return { xp: 2, coins: 1, completionRate: 20 };
  }

  const rate = correctAnswers / config.questions;
  return {
    xp: Math.max(2, Math.round(config.maxXp * rate)),
    coins: Math.max(1, Math.round(config.maxCoins * rate)),
    completionRate: Math.round(rate * 100),
    timeSpent
  };
}
```

---

## 五、HTML 模板範例

### 5.1 基本結構

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>互動講義</title>
  <style>
    /* 樣式 */
  </style>
</head>
<body>
  <div id="app">
    <!-- 任務內容 -->
  </div>

  <script>
    // ==========================================
    // 遊戲化整合模組
    // ==========================================

    const Gamification = {
      config: {
        maxXp: 10,
        maxCoins: 3
      },

      startTime: Date.now(),

      // 發送完成訊息
      complete(result) {
        const timeSpent = Math.round((Date.now() - this.startTime) / 1000);

        window.parent.postMessage({
          type: 'TASK_COMPLETE',
          payload: {
            xp: Math.max(2, Math.min(this.config.maxXp, result.xp)),
            coins: Math.max(1, Math.min(this.config.maxCoins, result.coins)),
            completionRate: result.completionRate || 100,
            timeSpent,
            metadata: result.metadata || {}
          }
        }, '*');
      },

      // 計算獎勵（通用）
      calculate(correctCount, totalCount, options = {}) {
        const rate = correctCount / totalCount;
        const penalty = options.penalty || 0;
        const finalRate = Math.max(0.2, rate - penalty);

        return {
          xp: Math.round(this.config.maxXp * finalRate),
          coins: Math.round(this.config.maxCoins * finalRate),
          completionRate: Math.round(finalRate * 100)
        };
      }
    };

    // ==========================================
    // 任務邏輯（自訂）
    // ==========================================

    // 範例：簡單選擇題
    let correctAnswers = 0;
    const totalQuestions = 5;

    function checkAnswer(isCorrect) {
      if (isCorrect) correctAnswers++;
    }

    function submitTask() {
      const result = Gamification.calculate(correctAnswers, totalQuestions);
      Gamification.complete(result);
    }
  </script>
</body>
</html>
```

### 5.2 完整範例：拖拉配對

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>詞彙配對</title>
  <style>
    .container { padding: 20px; font-family: sans-serif; }
    .pairs { display: flex; gap: 40px; justify-content: center; }
    .column { display: flex; flex-direction: column; gap: 10px; }
    .item {
      padding: 12px 20px;
      background: #f0f0f0;
      border-radius: 8px;
      cursor: grab;
      user-select: none;
    }
    .item.correct { background: #d4edda; }
    .item.wrong { background: #f8d7da; }
    .drop-zone {
      min-height: 50px;
      border: 2px dashed #ccc;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .drop-zone.over { border-color: #007bff; background: #e7f3ff; }
    .submit-btn {
      display: block;
      margin: 20px auto;
      padding: 12px 40px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
    }
    .submit-btn:disabled { background: #ccc; }
  </style>
</head>
<body>
  <div class="container">
    <h2>將英文單字拖到對應的中文意思</h2>

    <div class="pairs">
      <div class="column" id="words">
        <!-- 英文單字 -->
      </div>
      <div class="column" id="meanings">
        <!-- 中文意思（放置區）-->
      </div>
    </div>

    <button class="submit-btn" id="submitBtn" disabled>完成</button>
  </div>

  <script>
    // ==========================================
    // 遊戲化配置
    // ==========================================
    const Gamification = {
      config: { maxXp: 15, maxCoins: 5 },
      startTime: Date.now(),

      complete(result) {
        const timeSpent = Math.round((Date.now() - this.startTime) / 1000);
        window.parent.postMessage({
          type: 'TASK_COMPLETE',
          payload: { ...result, timeSpent }
        }, '*');
      }
    };

    // ==========================================
    // 題目資料
    // ==========================================
    const pairs = [
      { word: 'Apple', meaning: '蘋果' },
      { word: 'Book', meaning: '書本' },
      { word: 'Cat', meaning: '貓咪' },
      { word: 'Dog', meaning: '狗狗' },
      { word: 'Elephant', meaning: '大象' }
    ];

    const attempts = {}; // 記錄每個配對的嘗試次數
    const results = {};  // 記錄配對結果

    // ==========================================
    // 初始化
    // ==========================================
    function init() {
      const wordsCol = document.getElementById('words');
      const meaningsCol = document.getElementById('meanings');

      // 打亂順序
      const shuffledWords = [...pairs].sort(() => Math.random() - 0.5);
      const shuffledMeanings = [...pairs].sort(() => Math.random() - 0.5);

      // 建立單字（可拖曳）
      shuffledWords.forEach(p => {
        const div = document.createElement('div');
        div.className = 'item';
        div.textContent = p.word;
        div.draggable = true;
        div.dataset.word = p.word;
        div.addEventListener('dragstart', handleDragStart);
        wordsCol.appendChild(div);
      });

      // 建立放置區
      shuffledMeanings.forEach(p => {
        const zone = document.createElement('div');
        zone.className = 'drop-zone';
        zone.textContent = p.meaning;
        zone.dataset.meaning = p.meaning;
        zone.addEventListener('dragover', handleDragOver);
        zone.addEventListener('dragleave', handleDragLeave);
        zone.addEventListener('drop', handleDrop);
        meaningsCol.appendChild(zone);

        attempts[p.meaning] = 0;
      });
    }

    let draggedWord = null;

    function handleDragStart(e) {
      draggedWord = e.target.dataset.word;
      e.target.style.opacity = '0.5';
    }

    function handleDragOver(e) {
      e.preventDefault();
      e.target.classList.add('over');
    }

    function handleDragLeave(e) {
      e.target.classList.remove('over');
    }

    function handleDrop(e) {
      e.preventDefault();
      e.target.classList.remove('over');

      const meaning = e.target.dataset.meaning;
      const correctWord = pairs.find(p => p.meaning === meaning).word;

      attempts[meaning]++;

      if (draggedWord === correctWord) {
        // 正確
        e.target.innerHTML = `<div class="item correct">${draggedWord}</div>`;
        e.target.style.border = 'none';
        results[meaning] = { correct: true, attempts: attempts[meaning] };

        // 移除已配對的單字
        document.querySelector(`[data-word="${draggedWord}"]`).remove();
      } else {
        // 錯誤
        e.target.classList.add('wrong');
        setTimeout(() => e.target.classList.remove('wrong'), 500);
      }

      // 檢查是否全部完成
      checkCompletion();
    }

    function checkCompletion() {
      const completed = Object.keys(results).length;
      document.getElementById('submitBtn').disabled = completed < pairs.length;
    }

    // ==========================================
    // 提交結果
    // ==========================================
    document.getElementById('submitBtn').addEventListener('click', () => {
      let totalScore = 0;

      Object.values(results).forEach(r => {
        if (r.correct) {
          // 首次正確得 1 分，每多嘗試一次扣 0.25
          totalScore += Math.max(0.5, 1 - (r.attempts - 1) * 0.25);
        }
      });

      const rate = totalScore / pairs.length;

      Gamification.complete({
        xp: Math.max(2, Math.round(Gamification.config.maxXp * rate)),
        coins: Math.max(1, Math.round(Gamification.config.maxCoins * rate)),
        completionRate: Math.round(rate * 100),
        metadata: { attempts: Object.values(attempts) }
      });
    });

    init();
  </script>
</body>
</html>
```

---

## 六、App 端接收處理

### 6.1 監聽 postMessage

```typescript
// React 範例
useEffect(() => {
  const handleMessage = (event: MessageEvent) => {
    if (event.data?.type === 'TASK_COMPLETE') {
      const { xp, coins, completionRate, timeSpent, metadata } = event.data.payload;

      // 1. 更新學生資料
      updateStudentProfile({
        xp: currentXp + xp,
        coins: currentCoins + coins,
        totalTasksCompleted: totalTasks + 1
      });

      // 2. 檢查徽章解鎖
      checkBadgeUnlock();

      // 3. 顯示獎勵動畫
      showRewardAnimation({ xp, coins });

      // 4. 記錄學習數據（可選）
      logTaskCompletion({
        taskId,
        xp,
        coins,
        completionRate,
        timeSpent,
        metadata
      });
    }
  };

  window.addEventListener('message', handleMessage);
  return () => window.removeEventListener('message', handleMessage);
}, []);
```

### 6.2 獎勵動畫顯示

```typescript
function showRewardAnimation({ xp, coins }: { xp: number; coins: number }) {
  // 顯示獲得獎勵的 Toast 或動畫
  toast({
    title: '任務完成！',
    description: `獲得 ${xp} XP 和 ${coins} 金幣`,
    icon: '🎉'
  });
}
```

---

## 七、任務配置管理

### 7.1 任務配置結構

```typescript
interface TaskConfig {
  id: string;
  name: string;
  htmlUrl: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'challenge';
  maxXp: number;
  maxCoins: number;
  estimatedTime: number; // 預估完成秒數
  tags: string[];        // 標籤（如：數學、閱讀）
}

// 任務配置範例
const TASK_CONFIGS: TaskConfig[] = [
  {
    id: 'math-001',
    name: '分數加法練習',
    htmlUrl: '/tasks/math-001.html',
    difficulty: 'easy',
    maxXp: 10,
    maxCoins: 3,
    estimatedTime: 120,
    tags: ['數學', '分數']
  },
  {
    id: 'vocab-001',
    name: '英文單字配對',
    htmlUrl: '/tasks/vocab-001.html',
    difficulty: 'medium',
    maxXp: 15,
    maxCoins: 5,
    estimatedTime: 180,
    tags: ['英文', '單字']
  }
];
```

### 7.2 難度與獎勵對照表

| 難度 | maxXp | maxCoins | 預估時間 |
|------|-------|----------|----------|
| easy | 10 | 3 | 1-2 分鐘 |
| medium | 15 | 5 | 2-4 分鐘 |
| hard | 20 | 8 | 4-6 分鐘 |
| challenge | 30 | 12 | 6-10 分鐘 |

---

## 八、安全與防作弊

### 8.1 基本驗證

```typescript
// App 端驗證
function validateTaskResult(result: TaskCompletePayload, config: TaskConfig) {
  // 1. XP 不超過上限
  if (result.xp > config.maxXp) {
    result.xp = config.maxXp;
  }

  // 2. 金幣不超過上限
  if (result.coins > config.maxCoins) {
    result.coins = config.maxCoins;
  }

  // 3. 時間過短警告（可選）
  if (result.timeSpent < config.estimatedTime * 0.1) {
    console.warn('完成時間過短，可能作弊');
    // 可選擇降低獎勵或標記
  }

  return result;
}
```

### 8.2 進階防護（未來擴充）

- 伺服器端驗證
- 行為模式分析
- 時間戳記驗證

---

## 九、總結

### 9.1 快速導入步驟

1. **設定任務配置**：定義 `maxXp` 和 `maxCoins`
2. **HTML 內實作評分邏輯**：根據學生表現計算獎勵
3. **發送 postMessage**：任務完成時傳遞結果
4. **App 端接收處理**：更新學生資料、顯示動畫

### 9.2 設計原則

- **公平性**：獎勵與表現成正比
- **保底機制**：完成即有基本獎勵
- **透明度**：學生可預期獲得的獎勵範圍
- **彈性**：每個 HTML 可自訂評分邏輯

---

*文件版本：1.0*
*更新日期：2025-01-02*
