# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A standalone demo project showcasing a gamification reward system UI for Taiwan middle/high school students. This prototype demonstrates three user roles and is meant to be integrated into a larger application.

## Commands

```bash
npm run dev      # Start dev server (auto-opens browser)
npm run build    # TypeScript check + Vite production build
npm run preview  # Preview production build
```

## Architecture

**Tech Stack:** React 19 + TypeScript + Vite + Tailwind CSS 3

**App Modes:** Three switchable modes via bottom-right mode switcher:
- **Student** - Browse shop, redeem prizes, view orders
- **Org Admin** - Manage organization's prizes and redemptions
- **Platform Admin** - Manage platform-wide virtual items and view all organizations

**Source Structure:**

```
src/
├── App.tsx                    # Root with mode switcher and navigation
├── pages/
│   ├── demo/                  # Student pages
│   ├── org-admin/             # Organization admin pages
│   └── platform-admin/        # Platform admin pages
├── components/ui/             # Reusable UI primitives (Radix UI based)
├── types/
│   ├── gamification.ts        # Student types + reward system
│   ├── org-admin.ts           # Org admin types
│   └── platform-admin.ts      # Platform admin types
├── data/mockData.ts           # All mock data
└── lib/utils.ts               # cn() utility for Tailwind
```

## Design System

**Tiffany/Teal Theme:**
- Primary: Tiffany (#0ABAB5) with cyan accents
- Tier colors: Bronze (#CD7F32), Silver (#94A3B8), Gold (#EAB308), Diamond (#8B5CF6)
- Background: `bg-teal-mesh` gradient
- Cards: `card` class with rounded corners and subtle shadows

## Reward System

基於 `docs/gamification-system/03-reward-rules.md` 設計。

### Flexible Rewards (彈性獎勵)

後端可針對每個任務完成時回傳實際獎勵數值，未回傳則使用預設值。

```typescript
interface TaskCompletionResponse {
  success: boolean;
  taskId: string;
  taskType: 'task' | 'exam' | 'badge' | 'login' | 'streak';
  rewards?: { xp?: number; coins?: number };  // 彈性覆蓋
  bonusReason?: string;
}

// 使用方式
const finalReward = resolveRewards(response, DEFAULT_REWARDS.taskBeginner);
```

### Default Rewards (預設獎勵)

#### 任務獎勵（依難度）
| Difficulty | XP | Coins |
|------------|---:|------:|
| beginner | 30 | 5 |
| intermediate | 50 | 10 |
| advanced | 70 | 15 |

**時長加成：** `+floor(minutes/10)*10 XP`, `+floor(bonusXP/10) coins`

#### 考試獎勵
| Type | Base XP | Base Coins |
|------|--------:|-----------:|
| quiz | 30 | 5 |
| exam | 50 | 10 |
| practice | 20 | 3 |

#### 準確度加成
| Accuracy | +XP | +Coins |
|----------|----:|-------:|
| 100% (完美) | +50 | +20 |
| 90-99% (優秀) | +30 | +10 |
| 80-89% (良好) | +15 | +5 |
| 70-79% (及格) | +5 | +2 |

#### 特殊考試獎勵
| Event | +XP | +Coins |
|-------|----:|-------:|
| 無猜題 | +20 | +5 |
| 5連勝 | +10 | +2 |
| 10連勝 | +25 | +5 |
| 20連勝 | +50 | +10 |
| 50連勝 | +100 | +25 |

#### 每日登入
| Event | XP | Coins |
|-------|---:|------:|
| 每日首次登入 | 10 | 5 |

#### Streak 里程碑（一次性）
| Days | XP | Coins |
|-----:|---:|------:|
| 7 | 50 | 20 |
| 14 | 100 | 50 |
| 30 | 200 | 100 |
| 60 | 300 | 150 |
| 100 | 500 | 300 |

#### 特殊事件
| Event | +XP | +Coins | Note |
|-------|----:|-------:|------|
| 早起學習 (08:00前) | +10 | +5 | 每日一次 |
| 週末戰士 | +15 | +8 | 每次 |
| 完美日 | +50 | +25 | 每日一次 |

### Streak Multiplier (連續登入加成)

| Days | Multiplier |
|-----:|----------:|
| 1-6 | 1.0x |
| 7-13 | 1.1x |
| 14-29 | 1.15x |
| 30-59 | 1.2x |
| 60-99 | 1.3x |
| 100+ | 1.5x |

### Level System (等級系統)

```
XP_PER_LEVEL = 300
level = floor(totalXp / 300) + 1
```

| Level | Title |
|------:|-------|
| 1-5 | 學習冒險者 |
| 6-10 | 知識探索家 |
| 11-15 | 智慧追尋者 |
| 16+ | 學霸大師 |

**升級獎勵：** Lv.2-5: +20 coins, Lv.6-10: +30, Lv.11-15: +40, Lv.16+: +50

### Daily Limits (每日上限)

| Type | XP | Coins |
|------|---:|------:|
| 任務 | 2000 | 500 |
| 考試 | 1000 | 300 |
| 登入 | 10 | 5 |

## Coin Economy (金幣經濟)

### 匯率
```
1000 金幣 = 1 NTD
```

### 每月金幣收入預估

| 學生類型 | 月收入 (金幣) | 成本 (NTD) |
|---------|------------:|----------:|
| 偶爾使用 | ~600 | ~0.6 |
| 一般活躍 | ~900 | ~0.9 |
| 高度活躍 | ~1,200 | ~1.2 |
| 頂尖學生 | ~1,800 | ~1.8 |

### XP 對金幣比例

| 獎勵類型 | XP:金幣 |
|---------|-------:|
| 任務基礎 | 5:1 ~ 6:1 |
| 考試基礎 | 5:1 ~ 6:1 |
| 特殊加成 | 2:1 ~ 3:1 |
| **整體平均** | **~4:1** |

**設計原則：** XP 升級相對容易（滿足成就感），金幣較珍貴（控制成本）

### 成本控制機制

1. **每日上限** - 任務 500 金幣、考試 300 金幣
2. **等級門檻** - 高價獎品需達一定等級
3. **購買限制** - 單項獎品每人限購數量
4. **庫存管理** - 實體獎品設定總庫存

## Item Types by Role

| Role | Type | Description |
|------|------|-------------|
| **Platform Admin** | `virtual` | 頭像框、稱號、表情包、主題 |
| **Org Admin** | `physical` | 實體獎品（零食、文具、禮品卡） |
| **Org Admin** | `privilege` | 特權（免作業、換座位、遲到豁免） |

## Redemption Flow

```
Student                          Org Admin
   │                                 │
   ├─ 1. Purchase ──────────────────►│ pending
   │                        2. Confirm├─► confirmed
   │                   3. Mark ready ├─► ready + 兌換碼
   ├─ 4. Show code ─────────────────►│
   │              5. "快捷兌換" ──────├─► completed
```

## Order Status

| Status | Chinese |
|--------|---------|
| `pending` | 待處理 |
| `confirmed` | 已確認 |
| `ready` | 可領取 |
| `completed` | 已領取 |
| `cancelled` | 已取消 |
| `expired` | 已過期 |

## Terminology

| English | Chinese |
|---------|---------|
| Prize/Reward | 獎品 |
| Virtual Item | 道具 |
| Privilege | 特權 |
| Redemption | 兌換 |
| Redemption Code | 兌換碼 |
| Coins | 金幣 |
| XP | 經驗值 |

## Related Documentation

`../docs/gamification-system/` - Database schema, API specs, reward rules
