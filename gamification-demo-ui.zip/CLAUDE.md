# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A standalone demo project showcasing a gamification reward system UI for Taiwan middle/high school students. This prototype demonstrates three user roles and is meant to be integrated into a larger application.

## Commands

```bash
npm run dev      # Start dev server (auto-opens browser)
npm run build    # TypeScript check + Vite production build
npm run preview  # Preview production build
```

## Architecture

**Tech Stack:** React 19 + TypeScript + Vite + Tailwind CSS 3

**App Modes:** Three switchable modes via bottom-right mode switcher:
- **Student** - Browse shop, redeem prizes, view orders
- **Org Admin** - Manage organization's prizes and redemptions
- **Platform Admin** - Manage platform-wide virtual items and view all organizations

**Source Structure:**

```
src/
├── App.tsx                    # Root with mode switcher and navigation
├── pages/
│   ├── demo/                  # Student pages
│   │   ├── GamificationShowcase.tsx  # Home overview
│   │   ├── BadgesPageDemo.tsx        # Badge collection
│   │   ├── ShopPageDemo.tsx          # Shop with purchase flow
│   │   ├── LeaderboardPageDemo.tsx   # Rankings
│   │   └── OrdersPageDemo.tsx        # Order history & redemption codes
│   ├── org-admin/             # Organization admin pages
│   │   ├── ShopDashboard.tsx         # Dashboard with quick redemption
│   │   ├── ProductsListPage.tsx      # Prize management
│   │   ├── ProductFormPage.tsx       # Add/edit prizes (physical, privilege)
│   │   └── OrdersListPage.tsx        # Redemption management
│   └── platform-admin/        # Platform admin pages
│       ├── PlatformDashboard.tsx     # Platform overview
│       ├── PlatformProductsPage.tsx  # Virtual items (frames, titles)
│       ├── PlatformOrdersPage.tsx    # All redemptions
│       └── OrganizationsPage.tsx     # Organization management
├── components/ui/             # Reusable UI primitives (Radix UI based)
├── types/
│   ├── gamification.ts        # Student-facing types
│   ├── org-admin.ts           # Org admin types (ProductType: physical | privilege)
│   └── platform-admin.ts      # Platform admin types (PlatformProductType: virtual)
├── data/mockData.ts           # All mock data
└── lib/utils.ts               # cn() utility for Tailwind
```

## Design System

**Tiffany/Teal Theme:**
- Primary: Tiffany (#0ABAB5) with cyan accents
- Tier colors: Bronze (#CD7F32), Silver (#94A3B8), Gold (#EAB308), Diamond (#8B5CF6)
- Background: `bg-teal-mesh` gradient
- Cards: `card` class with rounded corners and subtle shadows
- Icons: lucide-react (emojis only for content like badges/avatars)

## Item Types by Role

| Role | Item Types | Description |
|------|------------|-------------|
| **Platform Admin** | `virtual` | 頭像框、稱號、表情包、主題 (avatar_frame, title, emoji_pack, theme) |
| **Org Admin** | `physical` | 實體獎品 - 零食、文具、禮品卡等需現場領取 |
| **Org Admin** | `privilege` | 特權 - 免作業、換座位、遲到豁免等特殊權益 |

**Note:** Org Admin 無法建立虛擬道具，虛擬道具是平台級數位資產，由 Platform Admin 管理。

## Redemption Flow

```
Student                          Org Admin
   │                                 │
   ├─ 1. Purchase item ─────────────►│ Order created (pending)
   │                                 │
   │                        2. Confirm├─► Status: confirmed
   │                                 │
   │                   3. Mark ready ├─► Status: ready + 兌換碼
   │                                 │
   ├─ 4. Show code to staff ────────►│
   │                                 │
   │              5. Enter code in   │
   │                 "快捷兌換"       ├─► Status: completed
   │                                 │
```

### Quick Redemption (快捷兌換)
`QuickRedemptionInput` component on Org Admin dashboard:
- Enter redemption code (e.g., ABCD-1234)
- Auto-find matching order with `ready` status
- Display student info and item details
- One-click completion

## Terminology

| English | Chinese | Context |
|---------|---------|---------|
| Prize/Reward | 獎品 | Physical items from organization |
| Virtual Item | 道具 | Platform items (frames, titles) |
| Privilege | 特權 | Special permissions (免作業, 換座位) |
| Redemption | 兌換 | The act of claiming a prize |
| Redemption Code | 兌換碼 | Code for pickup verification |
| Coins | 金幣 | Currency for physical rewards |
| XP | 經驗值 | Currency for virtual items |

## Order Status

| Status | Chinese | Description |
|--------|---------|-------------|
| `pending` | 待處理 | Order placed, awaiting admin confirmation |
| `confirmed` | 已確認 | Admin confirmed, preparing item |
| `ready` | 可領取 | Item ready, redemption code generated |
| `completed` | 已領取 | Student picked up the item |
| `cancelled` | 已取消 | Order cancelled by admin |
| `expired` | 已過期 | Redemption code expired |

## Integration Notes

This demo is designed to be integrated into a Student App. See README.md for full integration steps including route configuration.

## Related Documentation

System specifications are in a sibling directory at `../docs/gamification-system/` (database schema, API specs, reward rules, badge/shop/leaderboard systems).
