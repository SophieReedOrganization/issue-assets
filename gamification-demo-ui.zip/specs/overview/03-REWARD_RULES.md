# 獎勵規則與數值平衡

> XP/金幣獲取、等級升級、數值平衡分析

---

## 1. 經驗值 (XP) 系統

### 1.1 XP 獲取途徑

| 行為 | XP 獎勵 | 資料來源 | 說明 |
|------|---------|----------|------|
| 完成任務 | 10 XP | `status = completed` | 每完成一個任務 |
| 任務高分 | +5 XP | `achieved_score >= 80` | 任務得分 ≥80 額外獎勵 |
| 試卷及格 | 20 XP | `accuracy_rate >= 60` | 正確率 ≥60% |
| 試卷優秀 | 30 XP | `accuracy_rate >= 80` | 正確率 ≥80% |
| 試卷滿分 | 50 XP | `accuracy_rate = 100` | 全對 |
| 無猜題加成 | +10 XP | `is_guessing_detected = false` | 未偵測到猜題 |
| 銅牌徽章 | 30 XP | 徽章系統 | 獲得銅牌徽章 |
| 銀牌徽章 | 75 XP | 徽章系統 | 獲得銀牌徽章 |
| 金牌徽章 | 150 XP | 徽章系統 | 獲得金牌徽章 |
| 鑽石徽章 | 300 XP | 徽章系統 | 獲得鑽石徽章 |

### 1.2 XP 計算公式

```typescript
// 任務 XP 計算
function calculateTaskXP(task: StudentPathTask): number {
  let xp = 10; // 基礎獎勵
  if (task.achieved_score >= 80) {
    xp += 5; // 高分加成
  }
  return xp;
}

// 試卷 XP 計算
function calculateExamXP(exam: ExamSubmission): number {
  let xp = 0;

  // 基礎獎勵（依正確率分級，取最高級）
  if (exam.accuracy_rate === 100) {
    xp = 50; // 滿分
  } else if (exam.accuracy_rate >= 80) {
    xp = 30; // 優秀
  } else if (exam.accuracy_rate >= 60) {
    xp = 20; // 及格
  }

  // 無猜題加成
  if (!exam.is_guessing_detected) {
    xp += 10;
  }

  return xp;
}
```

### 1.3 每日上限（防刷機制）

| 項目 | 上限 | 說明 |
|------|------|------|
| 任務 XP | 150 XP/天 | 約 10 個任務 |
| 試卷 XP | 無限制 | 鼓勵多練習 |

---

## 2. 金幣系統

### 2.1 金幣獲取途徑

| 行為 | 金幣獎勵 | 資料來源 | 說明 |
|------|----------|----------|------|
| 完成任務 | 3 幣 | `status = completed` | 每完成一個任務 |
| 任務高分 | +2 幣 | `achieved_score >= 80` | 高分額外獎勵 |
| 試卷及格 | 5 幣 | `accuracy_rate >= 60` | 正確率 ≥60% |
| 試卷優秀 | 10 幣 | `accuracy_rate >= 80` | 正確率 ≥80% |
| 試卷滿分 | 20 幣 | `accuracy_rate = 100` | 全對 |
| 無猜題加成 | +5 幣 | `is_guessing_detected = false` | 認真作答獎勵 |
| 銅牌徽章 | 10 幣 | 徽章系統 | 獲得銅牌徽章 |
| 銀牌徽章 | 30 幣 | 徽章系統 | 獲得銀牌徽章 |
| 金牌徽章 | 75 幣 | 徽章系統 | 獲得金牌徽章 |
| 鑽石徽章 | 150 幣 | 徽章系統 | 獲得鑽石徽章 |

### 2.2 金幣計算公式

```typescript
// 任務金幣計算
function calculateTaskCoins(task: StudentPathTask): number {
  let coins = 3; // 基礎獎勵
  if (task.achieved_score >= 80) {
    coins += 2; // 高分加成
  }
  return coins;
}

// 試卷金幣計算
function calculateExamCoins(exam: ExamSubmission): number {
  let coins = 0;

  // 基礎獎勵（依正確率分級，取最高級）
  if (exam.accuracy_rate === 100) {
    coins = 20; // 滿分
  } else if (exam.accuracy_rate >= 80) {
    coins = 10; // 優秀
  } else if (exam.accuracy_rate >= 60) {
    coins = 5; // 及格
  }

  // 無猜題加成
  if (!exam.is_guessing_detected) {
    coins += 5;
  }

  return coins;
}
```

### 2.3 金幣匯率參考

| 項目 | 設定 |
|------|------|
| 金幣匯率 | 1 幣 ≈ NT$0.01（100 幣 = NT$1）|
| 一般學生每月獲取 | ~360 幣（任務+試卷，不含徽章獎勵）|
| 重度學生每月獲取 | ~720 幣（任務+試卷，不含徽章獎勵）|

---

## 3. 等級系統

### 3.1 等級門檻表

| 等級 | 累計 XP | 該級所需 XP | 說明 |
|------|---------|-------------|------|
| Lv.1 | 0 | - | 起始等級 |
| Lv.2 | 100 | 100 | 新手階段 |
| Lv.3 | 300 | 200 | |
| Lv.4 | 600 | 300 | |
| Lv.5 | 1,000 | 400 | 解鎖更多商品 |
| Lv.6 | 1,500 | 500 | 穩定成長期 |
| Lv.7 | 2,200 | 700 | |
| Lv.8 | 3,000 | 800 | |
| Lv.9 | 4,000 | 1,000 | |
| Lv.10 | 5,000 | 1,000 | 解鎖稀有商品 |
| Lv.11 | 6,200 | 1,200 | |
| Lv.12 | 7,600 | 1,400 | |
| Lv.13 | 9,200 | 1,600 | |
| Lv.14 | 11,000 | 1,800 | |
| Lv.15 | 13,000 | 2,000 | 解鎖傳說商品 |
| Lv.16 | 15,500 | 2,500 | |
| Lv.17 | 18,500 | 3,000 | |
| Lv.18 | 22,000 | 3,500 | |
| Lv.19 | 26,000 | 4,000 | |
| Lv.20 | 30,000 | 4,000 | 最高等級商品 |

### 3.2 等級計算函數

```typescript
const LEVEL_XP_TABLE: Record<number, number> = {
  1: 0, 2: 100, 3: 300, 4: 600, 5: 1000,
  6: 1500, 7: 2200, 8: 3000, 9: 4000, 10: 5000,
  11: 6200, 12: 7600, 13: 9200, 14: 11000, 15: 13000,
  16: 15500, 17: 18500, 18: 22000, 19: 26000, 20: 30000,
};

function calculateLevel(totalXp: number): number {
  let level = 1;
  for (const [lvl, requiredXp] of Object.entries(LEVEL_XP_TABLE)) {
    if (totalXp >= requiredXp) {
      level = parseInt(lvl);
    } else {
      break;
    }
  }
  return level;
}

function getXpToNextLevel(totalXp: number, currentLevel: number): number {
  const nextLevelXp = LEVEL_XP_TABLE[currentLevel + 1];
  if (!nextLevelXp) return 0; // 已達最高等級
  return nextLevelXp - totalXp;
}
```

---

## 4. 徽章獎勵

### 4.1 稀有度獎勵表

| 稀有度 | XP 獎勵 | 金幣獎勵 | 代表色 |
|--------|---------|----------|--------|
| 🥉 銅牌 | 30 XP | 10 幣 | #CD7F32 |
| 🥈 銀牌 | 75 XP | 30 幣 | #C0C0C0 |
| 🥇 金牌 | 150 XP | 75 幣 | #FFD700 |
| 💎 鑽石 | 300 XP | 150 幣 | #B9F2FF |

### 4.2 徽章分佈統計

| 稀有度 | 數量 | 佔比 | 累計 XP 貢獻 | 累計金幣貢獻 |
|--------|------|------|--------------|--------------|
| 銅牌 | 22 | 34% | 660 XP | 220 幣 |
| 銀牌 | 20 | 31% | 1,500 XP | 600 幣 |
| 金牌 | 11 | 17% | 1,650 XP | 825 幣 |
| 鑽石 | 11 | 17% | 3,300 XP | 1,650 幣 |
| **總計** | **64** | 100% | **7,110 XP** | **3,295 幣** |

---

## 5. 數值平衡分析

### 5.1 一般學生情境模擬

**假設條件：** 每週 5 天、每天 3 個任務、每週 2 份試卷（80% 正確率、無猜題）

| 項目 | 計算 | 每週獲取 |
|------|------|----------|
| 任務 XP | 5×3×10 | 150 XP |
| 任務高分 XP (50%) | 5×3×0.5×5 | 37 XP |
| 試卷優秀 XP | 2×30 | 60 XP |
| 無猜題加成 | 2×10 | 20 XP |
| **XP 小計** | | **~267 XP** |
| 任務金幣 | 5×3×3 | 45 幣 |
| 任務高分金幣 | 5×3×0.5×2 | 15 幣 |
| 試卷優秀金幣 | 2×10 | 20 幣 |
| 無猜題金幣 | 2×5 | 10 幣 |
| **金幣小計** | | **~90 幣** |
| **每月總計** | | **~1,068 XP / ~360 幣** |

### 5.2 不同使用頻率對比

| 使用頻率 | 每週任務 | 每週試卷 | 每週 XP | 每週金幣 | 每月 XP | 每月金幣 |
|----------|----------|----------|---------|----------|---------|----------|
| 輕度（3天）| 6 個 | 1 份 | ~100 XP | ~30 幣 | ~400 XP | ~120 幣 |
| 一般（5天）| 15 個 | 2 份 | ~270 XP | ~90 幣 | ~1,080 XP | ~360 幣 |
| 重度（7天）| 25 個 | 4 份 | ~500 XP | ~180 幣 | ~2,000 XP | ~720 幣 |

### 5.3 升級速度預估

| 學生類型 | 每月 XP | 達 Lv.5 | 達 Lv.10 | 達 Lv.15 | 達 Lv.20 |
|----------|---------|---------|----------|----------|----------|
| 輕度使用 | ~400 XP | ~2.5 個月 | ~12 個月 | ~32 個月 | ~75 個月 |
| 一般使用 | ~1,000 XP | ~1 個月 | ~5 個月 | ~13 個月 | ~30 個月 |
| 重度使用 | ~2,000 XP | ~2 週 | ~2.5 個月 | ~6.5 個月 | ~15 個月 |

### 5.4 商品購買力參考

基於一般學生每月 ~360 幣：

| 商品類型 | 價格範圍 | 一般學生需時 |
|----------|----------|--------------|
| 基礎表情包 | 150 幣 | ~2 週 |
| 基礎頭像框 | 200-300 幣 | 2.5-3.5 週 |
| 進階頭像框 | 400-500 幣 | 4.5-6 週 |
| 基礎稱號 | 200-300 幣 | 2.5-3.5 週 |
| 進階稱號 | 400-700 幣 | 4.5-8 週 |
| 高級稱號 | 800-1,000 幣 | 9-11 週 |
| 傳說稱號 | 1,500-2,000 幣 | 4-6 個月 |
| 精美鉛筆（實體）| 500 幣 | ~6 週 |
| 乖乖餅乾（實體）| 1,000 幣 | ~3 個月 |

---

## 6. 常量定義

```typescript
// 獎勵規則常量
export const REWARD_RULES = {
  // 任務獎勵
  task: { xp: 10, coins: 3 },
  taskHighScore: { xp: 5, coins: 2 },  // achieved_score >= 80

  // 試卷獎勵（依 accuracy_rate 分級）
  examPass: { xp: 20, coins: 5 },      // accuracy_rate >= 60
  examGood: { xp: 30, coins: 10 },     // accuracy_rate >= 80
  examPerfect: { xp: 50, coins: 20 },  // accuracy_rate = 100
  examNoGuessing: { xp: 10, coins: 5 }, // is_guessing_detected = false

  // 徽章獎勵
  badgeBronze: { xp: 30, coins: 10 },
  badgeSilver: { xp: 75, coins: 30 },
  badgeGold: { xp: 150, coins: 75 },
  badgeDiamond: { xp: 300, coins: 150 },
};

// 每日上限
export const DAILY_LIMITS = {
  taskXp: 150, // 任務 XP 每日上限
};

// 等級經驗值表
export const LEVEL_XP_TABLE: Record<number, number> = {
  1: 0, 2: 100, 3: 300, 4: 600, 5: 1000,
  6: 1500, 7: 2200, 8: 3000, 9: 4000, 10: 5000,
  11: 6200, 12: 7600, 13: 9200, 14: 11000, 15: 13000,
  16: 15500, 17: 18500, 18: 22000, 19: 26000, 20: 30000,
};
```

---

## 7. 相關文件

| 文件 | 說明 |
|------|------|
| [系統總覽](./01-SYSTEM_OVERVIEW.md) | 系統架構與核心概念 |
| [資料模型](./02-DATA_MODEL.md) | 資料結構定義 |
| [徽章系統](../student-app/01-BADGE_SYSTEM.md) | 64 個徽章詳細定義 |
