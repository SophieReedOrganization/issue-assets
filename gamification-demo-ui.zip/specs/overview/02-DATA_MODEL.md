# 資料模型與 API 依賴

> 遊戲化系統資料結構與現有後端資料依賴

---

## 1. 現有後端可用資料（已確認）

以下欄位**已存在且可直接使用**：

### 1.1 任務相關 (StudentPathTask)

| 欄位 | 類型 | 說明 | 用於 |
|------|------|------|------|
| `status` | enum | pending/in_progress/completed/skipped/overdue | 任務完成計數 |
| `achieved_score` | number | 任務獲得分數 | 高分判定 (≥80) |
| `duration_seconds` | number | 花費時間（秒）| 學習時長統計 |
| `completed_at` | datetime | 完成時間 | 早起/夜間徽章 |

### 1.2 試卷相關 (ExamSubmissionResponse)

| 欄位 | 類型 | 說明 | 用於 |
|------|------|------|------|
| `total_score` | number | 獲得分數 | 成績計算 |
| `max_score` | number | 滿分 | 及格率計算 |
| `correct_count` | number | 答對題數 | 正確數統計 |
| `wrong_count` | number | 答錯題數 | 錯誤分析 |
| `accuracy_rate` | number | 正確率 (0-100) | 正確率徽章、滿分判定 |
| `is_guessing_detected` | boolean | 是否偵測到猜題 | 誠實作答徽章 |

### 1.3 學習路徑統計 (StudentPathDetailResponse)

| 欄位 | 類型 | 說明 | 用於 |
|------|------|------|------|
| `total_tasks` | number | 總任務數 | 進度計算 |
| `completed_tasks` | number | 已完成任務數 | 進度計算 |
| `progress_percentage` | number | 進度百分比 | 學習路徑徽章 |

### 1.4 每日任務 (StudentDailyTasksResponse)

| 欄位 | 類型 | 說明 | 用於 |
|------|------|------|------|
| `total_tasks` | number | 今日總任務數 | 每日完成計算 |
| `completed_tasks` | number | 今日已完成數 | 每日完成計算 |
| `completion_rate` | number | 今日完成率 | 每日任務徽章 |

---

## 2. 需要新建的欄位（遊戲化專用）

### 2.1 必要欄位 (P0)

| 欄位 | 類型 | 預設值 | 說明 |
|------|------|--------|------|
| `total_xp` | number | 0 | 累計經驗值 |
| `level` | number | 1 | 當前等級 |
| `coins` | number | 0 | 金幣餘額 |
| `badges_earned` | string[] | [] | 已獲得徽章 ID 列表 |
| `equipped_title` | string | 'title_newbie' | 當前裝備的稱號 ID |
| `equipped_frame` | string | 'frame_default' | 當前裝備的頭像框 ID |
| `owned_titles` | string[] | ['title_newbie'] | 已擁有的稱號 ID 列表 |
| `owned_frames` | string[] | ['frame_default'] | 已擁有的頭像框 ID 列表 |

### 2.2 未來欄位 (P1)

| 欄位 | 類型 | 說明 |
|------|------|------|
| `current_streak` | number | 連續學習天數 |
| `longest_streak` | number | 最長連續天數 |
| `total_coins_earned` | number | 累計獲得金幣（不含消費） |
| `total_coins_spent` | number | 累計消費金幣 |

---

## 3. 資料模型定義

### 3.1 學生遊戲化資料 (StudentGameProfile)

```typescript
interface StudentGameProfile {
  // 基本資訊
  studentId: string;

  // 經驗值與等級
  totalXp: number;
  level: number;

  // 金幣
  coins: number;

  // 徽章
  badgesEarned: string[];      // 已獲得徽章 ID

  // 稱號
  equippedTitle: string;       // 當前裝備稱號 ID
  ownedTitles: string[];       // 已擁有稱號 ID

  // 頭像框
  equippedFrame: string;       // 當前裝備頭像框 ID
  ownedFrames: string[];       // 已擁有頭像框 ID

  // 統計（從現有 API 計算）
  stats: {
    totalTasksCompleted: number;
    totalExamsCompleted: number;
    totalPerfectScores: number;
    totalHonestExams: number;
    highScoreTasks: number;
  };

  // 時間戳
  createdAt: datetime;
  updatedAt: datetime;
}
```

### 3.2 徽章定義 (BadgeDefinition)

```typescript
interface BadgeDefinition {
  id: string;                  // 唯一識別碼 e.g. 'task_10'
  name: string;                // 顯示名稱 e.g. '起步者'
  description: string;         // 說明文字
  series: string;              // 系列 e.g. 'task', 'exam', 'perfect'
  rarity: 'bronze' | 'silver' | 'gold' | 'diamond';

  // 解鎖條件
  unlockCondition: {
    type: string;              // 條件類型
    field: string;             // 欄位名稱
    operator: 'gte' | 'eq' | 'count';
    value: number;             // 目標值
    dataSource: string;        // API 資料來源
  };

  // 獎勵
  rewards: {
    xp: number;
    coins: number;
  };

  // 圖片
  imageUrl: string;
}
```

### 3.3 頭像框定義 (FrameDefinition)

```typescript
interface FrameDefinition {
  id: string;                  // 唯一識別碼 e.g. 'frame_flame'
  name: string;                // 顯示名稱 e.g. '火焰邊框'
  description: string;         // 說明文字
  rarity: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';

  // 獲取方式
  acquisitionType: 'free' | 'achievement' | 'purchase';

  // 解鎖條件（成就解鎖時）
  unlockCondition?: {
    type: string;
    target: number;
    dataSource: string;
  };

  // 購買資訊（金幣兌換時）
  purchaseInfo?: {
    price: number;             // 金幣價格
    levelRequired: number;     // 等級需求
  };

  // 圖片
  imageUrl: string;
}
```

### 3.4 稱號定義 (TitleDefinition)

```typescript
interface TitleDefinition {
  id: string;                  // 唯一識別碼 e.g. 'title_scholar'
  name: string;                // 顯示名稱 e.g. '學霸'
  description: string;         // 說明文字
  rarity: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';

  // 獲取方式
  acquisitionType: 'free' | 'achievement' | 'purchase';

  // 解鎖條件（成就解鎖時）
  unlockCondition?: {
    type: string;
    target: number;
    dataSource: string;
  };

  // 購買資訊（金幣兌換時）
  purchaseInfo?: {
    price: number;
    levelRequired: number;
  };
}
```

### 3.5 商店商品 (ShopItem)

```typescript
interface ShopItem {
  id: string;
  type: 'title' | 'frame' | 'virtual' | 'physical';
  name: string;
  description: string;
  imageUrl: string;

  // 價格與門檻
  price: number;               // 金幣價格
  levelRequired: number;       // 等級需求

  // 分類
  category: string;            // 商品分類
  tags: string[];              // 標籤

  // 可用性
  isActive: boolean;           // 是否上架
  stock?: number;              // 庫存數量（實體商品）

  // 所屬
  scope: 'platform' | 'org';   // 平台商店或機構商店
  orgId?: string;              // 機構 ID（機構商店時）

  // 稀有度（虛擬商品）
  rarity?: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';
}
```

### 3.6 訂單 (Order)

```typescript
interface Order {
  id: string;
  orderNumber: string;         // 訂單編號 e.g. 'GAME-ABCD-1234'

  // 關聯
  studentId: string;
  itemId: string;
  orgId?: string;              // 機構商品訂單

  // 商品資訊快照
  itemSnapshot: {
    name: string;
    type: string;
    price: number;
    imageUrl: string;
  };

  // 狀態
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';

  // 時間戳
  createdAt: datetime;
  confirmedAt?: datetime;
  completedAt?: datetime;
}
```

---

## 4. 統計查詢需求

### 4.1 可從現有 API 計算的統計

| 統計項目 | 查詢邏輯 | 用於 |
|----------|----------|------|
| 累計完成任務數 | `COUNT(StudentPathTask WHERE status = 'completed')` | 任務系列徽章 |
| 累計高分任務數 | `COUNT(StudentPathTask WHERE achieved_score >= 80)` | 高分系列徽章 |
| 累計試卷數 | `COUNT(ExamSubmission)` | 試卷系列徽章 |
| 累計滿分次數 | `COUNT(ExamSubmission WHERE accuracy_rate = 100)` | 滿分系列徽章 |
| 累計無猜題次數 | `COUNT(ExamSubmission WHERE is_guessing_detected = false)` | 誠實系列徽章 |
| 累計優秀試卷 | `COUNT(ExamSubmission WHERE accuracy_rate >= 80)` | 正確率系列徽章 |
| 早起任務數 | `COUNT(StudentPathTask WHERE HOUR(completed_at) BETWEEN 6 AND 8)` | 早起徽章 |
| 夜間任務數 | `COUNT(StudentPathTask WHERE HOUR(completed_at) BETWEEN 20 AND 23)` | 夜間徽章 |
| 每日全完成天數 | `COUNT(days WHERE completion_rate = 100)` | 每日任務徽章 |

### 4.2 需後端新增的統計

| 統計項目 | 說明 | 用於 |
|----------|------|------|
| 連續學習天數 | 追蹤每日是否有學習活動 | 連續學習徽章 |
| 累計學習時長 | 加總 `duration_seconds` | 學習時長徽章 |
| 答題連擊數 | 追蹤連續答對的最高數量 | 連擊系列徽章 |
| 排行榜歷史 | 每週排名結算記錄 | 排行榜徽章 |

---

## 5. API 資料流

### 5.1 任務完成流程

```
學生完成任務
    ↓
後端更新 StudentPathTask.status = 'completed'
    ↓
觸發遊戲化計算:
    1. 計算 XP: base + (achieved_score >= 80 ? bonus : 0)
    2. 計算金幣: base + (achieved_score >= 80 ? bonus : 0)
    3. 累加到 StudentGameProfile.totalXp / coins
    4. 檢查升級條件
    5. 檢查徽章解鎖條件
    ↓
返回獎勵資訊給前端顯示
```

### 5.2 試卷提交流程

```
學生提交試卷
    ↓
後端計算 accuracy_rate, is_guessing_detected
    ↓
觸發遊戲化計算:
    1. 計算 XP: 依 accuracy_rate 分級 + no_guessing_bonus
    2. 計算金幣: 依 accuracy_rate 分級 + no_guessing_bonus
    3. 累加到 StudentGameProfile
    4. 檢查升級/徽章條件
    ↓
返回獎勵資訊
```

---

## 6. 相關文件

| 文件 | 說明 |
|------|------|
| [獎勵規則](./03-REWARD_RULES.md) | XP/金幣計算公式 |
| [現有 API 依賴](../api/01-DATA_DEPENDENCY.md) | 詳細 API 欄位說明 |
| [後端需求](../api/03-BACKEND_REQUIREMENTS.md) | 資料庫變更需求 |
