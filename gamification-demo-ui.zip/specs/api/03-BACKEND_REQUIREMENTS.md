# 後端需求

> 資料庫欄位、統計查詢、API 端點需求

---

## 1. 必要新增欄位 (P0)

### 1.1 學生遊戲化資料表 (student_game_profile)

| 欄位 | 類型 | 預設值 | 說明 | 索引 |
|------|------|--------|------|------|
| student_id | UUID | - | 學生 ID (FK) | PK |
| total_xp | INT | 0 | 累計經驗值 | ✅ |
| level | INT | 1 | 當前等級 | ✅ |
| coins | INT | 0 | 金幣餘額 | ✅ |
| badges_earned | JSONB | [] | 已獲得徽章 ID 列表 | |
| equipped_title | VARCHAR | 'title_newbie' | 當前裝備稱號 ID | |
| equipped_frame | VARCHAR | 'frame_default' | 當前裝備頭像框 ID | |
| owned_titles | JSONB | ['title_newbie'] | 已擁有稱號 ID 列表 | |
| owned_frames | JSONB | ['frame_default'] | 已擁有頭像框 ID 列表 | |
| created_at | TIMESTAMP | NOW() | 建立時間 | |
| updated_at | TIMESTAMP | NOW() | 更新時間 | |

### 1.2 SQL 建表語句

```sql
CREATE TABLE student_game_profile (
  student_id UUID PRIMARY KEY REFERENCES students(id),
  total_xp INT NOT NULL DEFAULT 0,
  level INT NOT NULL DEFAULT 1,
  coins INT NOT NULL DEFAULT 0,
  badges_earned JSONB NOT NULL DEFAULT '[]',
  equipped_title VARCHAR(50) NOT NULL DEFAULT 'title_newbie',
  equipped_frame VARCHAR(50) NOT NULL DEFAULT 'frame_default',
  owned_titles JSONB NOT NULL DEFAULT '["title_newbie"]',
  owned_frames JSONB NOT NULL DEFAULT '["frame_default"]',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_game_profile_xp ON student_game_profile(total_xp DESC);
CREATE INDEX idx_game_profile_level ON student_game_profile(level DESC);
```

---

## 2. 統計查詢需求

### 2.1 徽章解鎖檢查查詢

```sql
-- 任務完成數
SELECT COUNT(*) as task_completed
FROM student_path_tasks
WHERE student_id = $1 AND status = 'completed';

-- 高分任務數
SELECT COUNT(*) as high_score_tasks
FROM student_path_tasks
WHERE student_id = $1 AND achieved_score >= 80;

-- 試卷完成數
SELECT COUNT(*) as exam_completed
FROM exam_submissions
WHERE student_id = $1;

-- 滿分次數
SELECT COUNT(*) as perfect_scores
FROM exam_submissions
WHERE student_id = $1 AND accuracy_rate = 100;

-- 無猜題次數
SELECT COUNT(*) as honest_exams
FROM exam_submissions
WHERE student_id = $1 AND is_guessing_detected = false;

-- 早起任務數
SELECT COUNT(*) as early_tasks
FROM student_path_tasks
WHERE student_id = $1
  AND status = 'completed'
  AND EXTRACT(HOUR FROM completed_at) BETWEEN 6 AND 8;

-- 夜間任務數
SELECT COUNT(*) as night_tasks
FROM student_path_tasks
WHERE student_id = $1
  AND status = 'completed'
  AND EXTRACT(HOUR FROM completed_at) BETWEEN 20 AND 23;

-- 每日全完成天數
SELECT COUNT(DISTINCT DATE(completed_at)) as perfect_days
FROM student_daily_task_logs
WHERE student_id = $1 AND completion_rate = 100;
```

### 2.2 排行榜查詢

```sql
-- 班級 XP 排行榜
SELECT
  s.id, s.name, s.avatar,
  g.total_xp, g.level, g.equipped_title, g.equipped_frame
FROM students s
JOIN student_game_profile g ON s.id = g.student_id
WHERE s.class_id = $1
ORDER BY g.total_xp DESC
LIMIT 50;

-- 學校排行榜
SELECT
  s.id, s.name, s.avatar,
  g.total_xp, g.level
FROM students s
JOIN student_game_profile g ON s.id = g.student_id
WHERE s.org_id = $1
ORDER BY g.total_xp DESC
LIMIT 100;
```

---

## 3. 觸發器需求

### 3.1 任務完成觸發 XP/金幣

```sql
CREATE OR REPLACE FUNCTION on_task_complete()
RETURNS TRIGGER AS $$
DECLARE
  xp_reward INT := 10;
  coin_reward INT := 3;
BEGIN
  -- 只處理狀態變更為 completed 的情況
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- 高分加成
    IF NEW.achieved_score >= 80 THEN
      xp_reward := xp_reward + 5;
      coin_reward := coin_reward + 2;
    END IF;

    -- 更新遊戲化資料
    UPDATE student_game_profile
    SET
      total_xp = total_xp + xp_reward,
      coins = coins + coin_reward,
      updated_at = NOW()
    WHERE student_id = NEW.student_id;

    -- 檢查升級
    PERFORM check_level_up(NEW.student_id);

    -- 檢查徽章
    PERFORM check_badge_unlock(NEW.student_id);
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_task_complete
AFTER INSERT OR UPDATE ON student_path_tasks
FOR EACH ROW EXECUTE FUNCTION on_task_complete();
```

### 3.2 試卷提交觸發 XP/金幣

```sql
CREATE OR REPLACE FUNCTION on_exam_submit()
RETURNS TRIGGER AS $$
DECLARE
  xp_reward INT := 0;
  coin_reward INT := 0;
BEGIN
  -- 依正確率分級
  IF NEW.accuracy_rate = 100 THEN
    xp_reward := 50;
    coin_reward := 20;
  ELSIF NEW.accuracy_rate >= 80 THEN
    xp_reward := 30;
    coin_reward := 10;
  ELSIF NEW.accuracy_rate >= 60 THEN
    xp_reward := 20;
    coin_reward := 5;
  END IF;

  -- 無猜題加成
  IF NEW.is_guessing_detected = false THEN
    xp_reward := xp_reward + 10;
    coin_reward := coin_reward + 5;
  END IF;

  -- 更新遊戲化資料
  IF xp_reward > 0 THEN
    UPDATE student_game_profile
    SET
      total_xp = total_xp + xp_reward,
      coins = coins + coin_reward,
      updated_at = NOW()
    WHERE student_id = NEW.student_id;

    PERFORM check_level_up(NEW.student_id);
    PERFORM check_badge_unlock(NEW.student_id);
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_exam_submit
AFTER INSERT ON exam_submissions
FOR EACH ROW EXECUTE FUNCTION on_exam_submit();
```

---

## 4. API 端點需求

### 4.1 學生端 API

| 方法 | 端點 | 說明 |
|------|------|------|
| GET | `/api/students/me/game-profile` | 獲取個人遊戲化資料 |
| GET | `/api/students/me/badges` | 獲取徽章列表與解鎖狀態 |
| GET | `/api/students/me/frames` | 獲取頭像框列表與擁有狀態 |
| GET | `/api/students/me/titles` | 獲取稱號列表與擁有狀態 |
| PUT | `/api/students/me/equip` | 裝備稱號/頭像框 |
| GET | `/api/shop/items` | 獲取商店商品列表 |
| POST | `/api/shop/purchase` | 購買商品 |
| GET | `/api/students/me/orders` | 獲取訂單列表 |
| GET | `/api/leaderboard` | 獲取排行榜 |

### 4.2 機構管理端 API

| 方法 | 端點 | 說明 |
|------|------|------|
| GET | `/api/orgs/:orgId/shop/items` | 獲取機構商品列表 |
| POST | `/api/orgs/:orgId/shop/items` | 新增機構商品 |
| PUT | `/api/orgs/:orgId/shop/items/:id` | 更新機構商品 |
| DELETE | `/api/orgs/:orgId/shop/items/:id` | 刪除機構商品 |
| GET | `/api/orgs/:orgId/orders` | 獲取機構訂單列表 |
| PUT | `/api/orgs/:orgId/orders/:id/confirm` | 確認訂單 |
| PUT | `/api/orgs/:orgId/orders/:id/complete` | 完成訂單 |
| GET | `/api/orgs/:orgId/game-stats` | 獲取遊戲化統計 |

---

## 5. 實作優先級

### Phase 1 (MVP)

| 項目 | 說明 |
|------|------|
| student_game_profile 表 | 基本遊戲化資料 |
| XP/金幣觸發器 | 自動計算獎勵 |
| 徽章解鎖檢查 | 64 個徽章 |
| 學生端 API | profile, badges, shop |

### Phase 2

| 項目 | 說明 |
|------|------|
| 排行榜 | 班級/學校/全站 |
| 機構商店 | 管理端功能 |
| 訂單系統 | 實體獎品兌換 |

### Phase 3

| 項目 | 說明 |
|------|------|
| 連續學習追蹤 | streak 相關 |
| 進階統計 | 學習時長、連擊 |
| 活動系統 | 期間限定活動 |

---

## 6. 相關文件

| 文件 | 說明 |
|------|------|
| [現有 API 依賴](./01-DATA_DEPENDENCY.md) | 可用的資料欄位 |
| [資料模型](../overview/02-DATA_MODEL.md) | 完整資料結構 |
