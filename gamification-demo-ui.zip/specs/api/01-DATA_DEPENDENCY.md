# 現有 API 資料依賴

> 可直接使用的後端資料與對應功能

---

## 1. 可用 API 資料總覽

| 資料來源 | 可用欄位 | 對應功能 | 狀態 |
|----------|----------|----------|------|
| StudentPathTask | status, achieved_score, completed_at | 任務相關徽章、XP/金幣 | ✅ |
| ExamSubmission | accuracy_rate, is_guessing_detected | 試卷相關徽章、XP/金幣 | ✅ |
| StudentPathDetail | progress_percentage | 學習路徑徽章 | ✅ |
| StudentDailyTasks | completion_rate | 每日任務徽章 | ✅ |

---

## 2. StudentPathTask

### 2.1 可用欄位

| 欄位 | 類型 | 說明 |
|------|------|------|
| `status` | enum | pending / in_progress / completed / skipped / overdue |
| `achieved_score` | number | 任務獲得分數 |
| `duration_seconds` | number | 花費時間（秒）|
| `completed_at` | datetime | 完成時間 |

### 2.2 支援功能

| 功能 | 查詢條件 |
|------|----------|
| 任務完成計數 | `WHERE status = 'completed'` |
| 高分任務計數 | `WHERE achieved_score >= 80` |
| 早起任務計數 | `WHERE HOUR(completed_at) BETWEEN 6 AND 8` |
| 夜間任務計數 | `WHERE HOUR(completed_at) BETWEEN 20 AND 23` |
| 學習時長統計 | `SUM(duration_seconds)` |

### 2.3 對應徽章

| 徽章系列 | 條件 |
|----------|------|
| 📚 任務完成 | COUNT(status = 'completed') |
| ⭐ 任務高分 | COUNT(achieved_score >= 80) |
| 🌅 早起學習 | COUNT(HOUR(completed_at) BETWEEN 6 AND 8) |
| 🌙 夜間學習 | COUNT(HOUR(completed_at) BETWEEN 20 AND 23) |

---

## 3. ExamSubmission

### 3.1 可用欄位

| 欄位 | 類型 | 說明 |
|------|------|------|
| `total_score` | number | 獲得分數 |
| `max_score` | number | 滿分 |
| `correct_count` | number | 答對題數 |
| `wrong_count` | number | 答錯題數 |
| `accuracy_rate` | number | 正確率 (0-100) |
| `is_guessing_detected` | boolean | 是否偵測到猜題 |

### 3.2 支援功能

| 功能 | 查詢條件 |
|------|----------|
| 試卷完成計數 | `COUNT(*)` |
| 及格試卷計數 | `WHERE accuracy_rate >= 60` |
| 優秀試卷計數 | `WHERE accuracy_rate >= 80` |
| 高分試卷計數 | `WHERE accuracy_rate >= 90` |
| 滿分次數 | `WHERE accuracy_rate = 100` |
| 無猜題次數 | `WHERE is_guessing_detected = false` |

### 3.3 對應徽章

| 徽章系列 | 條件 |
|----------|------|
| 📝 試卷完成 | COUNT(*) |
| 🎯 正確率 | COUNT(accuracy_rate >= X%) |
| 💯 滿分 | COUNT(accuracy_rate = 100) |
| 💚 誠實作答 | COUNT(is_guessing_detected = false) |

---

## 4. StudentPathDetail

### 4.1 可用欄位

| 欄位 | 類型 | 說明 |
|------|------|------|
| `total_tasks` | number | 總任務數 |
| `completed_tasks` | number | 已完成任務數 |
| `progress_percentage` | number | 進度百分比 |

### 4.2 支援功能

| 功能 | 查詢條件 |
|------|----------|
| 路徑進度檢查 | `progress_percentage >= X` |
| 路徑完成計數 | `COUNT(progress_percentage = 100)` |

### 4.3 對應徽章

| 徽章系列 | 條件 |
|----------|------|
| 📊 學習路徑 | progress_percentage 達標 / 完成路徑數 |

---

## 5. StudentDailyTasks

### 5.1 可用欄位

| 欄位 | 類型 | 說明 |
|------|------|------|
| `total_tasks` | number | 今日總任務數 |
| `completed_tasks` | number | 今日已完成數 |
| `completion_rate` | number | 今日完成率 |

### 5.2 支援功能

| 功能 | 查詢條件 |
|------|----------|
| 每日全完成天數 | `COUNT(days WHERE completion_rate = 100)` |

### 5.3 對應徽章

| 徽章系列 | 條件 |
|----------|------|
| 📅 每日任務 | COUNT(completion_rate = 100) |

---

## 6. XP/金幣計算依賴

### 6.1 任務獎勵計算

```typescript
function calculateTaskReward(task: StudentPathTask) {
  // 來源：StudentPathTask
  const isCompleted = task.status === 'completed';
  const isHighScore = task.achieved_score >= 80;

  return {
    xp: isCompleted ? (10 + (isHighScore ? 5 : 0)) : 0,
    coins: isCompleted ? (3 + (isHighScore ? 2 : 0)) : 0,
  };
}
```

### 6.2 試卷獎勵計算

```typescript
function calculateExamReward(exam: ExamSubmission) {
  // 來源：ExamSubmission
  let xp = 0, coins = 0;

  // 依正確率分級
  if (exam.accuracy_rate === 100) {
    xp = 50; coins = 20;
  } else if (exam.accuracy_rate >= 80) {
    xp = 30; coins = 10;
  } else if (exam.accuracy_rate >= 60) {
    xp = 20; coins = 5;
  }

  // 無猜題加成
  if (!exam.is_guessing_detected) {
    xp += 10;
    coins += 5;
  }

  return { xp, coins };
}
```

---

## 7. Phase 1 可實作功能

基於現有 API 資料，以下功能可立即實作：

| 功能 | 資料來源 | 備註 |
|------|----------|------|
| 64 個徽章 | 上述 4 個 API | 全部可用 |
| 31 個頭像框 | 徽章統計 | 成就解鎖部分 |
| 30 個稱號 | 徽章統計 | 成就解鎖部分 |
| XP 計算 | StudentPathTask + ExamSubmission | 需後端累加 |
| 金幣計算 | StudentPathTask + ExamSubmission | 需後端累加 |
| 等級計算 | XP 累計 | 需後端新增欄位 |

---

## 8. 相關文件

| 文件 | 說明 |
|------|------|
| [後端需求](./03-BACKEND_REQUIREMENTS.md) | 需要新增的欄位 |
| [新增 API](./02-NEW_ENDPOINTS.md) | 需要新增的 endpoints |
