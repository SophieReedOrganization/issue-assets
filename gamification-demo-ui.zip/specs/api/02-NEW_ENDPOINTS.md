# 新增 API 端點

> 遊戲化系統所需的所有 API 端點規格

---

## 1. API 總覽

### 1.1 端點分類

| 分類 | 端點數 | 說明 |
|------|--------|------|
| 學生個人 | 8 | 遊戲化資料、徽章、商店 |
| 排行榜 | 1 | 班級/學校排行 |
| 機構商店 | 4 | 商品 CRUD |
| 機構訂單 | 4 | 訂單管理 |
| 機構統計 | 2 | 遊戲化統計 |
| **總計** | **19** | |

### 1.2 認證需求

所有 API 需要 JWT Bearer Token 認證：

```
Authorization: Bearer <token>
```

---

## 2. 學生端 API

### 2.1 GET `/api/students/me/game-profile`

獲取個人遊戲化資料

**Response:**

```typescript
interface GameProfileResponse {
  studentId: string;
  totalXp: number;
  level: number;
  coins: number;
  badgesEarned: string[];       // 已獲得徽章 ID 列表
  equippedTitle: string;        // 當前稱號 ID
  equippedFrame: string;        // 當前頭像框 ID
  ownedTitles: string[];        // 擁有稱號 ID 列表
  ownedFrames: string[];        // 擁有頭像框 ID 列表

  // 計算欄位
  xpToNextLevel: number;        // 升級所需 XP
  levelProgress: number;        // 當前等級進度 (0-100)

  // 統計
  stats: {
    tasksCompleted: number;
    examsCompleted: number;
    perfectScores: number;
    highScoreTasks: number;
  };
}
```

**範例：**

```json
{
  "studentId": "uuid-xxx",
  "totalXp": 1250,
  "level": 5,
  "coins": 360,
  "badgesEarned": ["task_10", "task_30", "exam_5", "honest_5"],
  "equippedTitle": "title_learner",
  "equippedFrame": "frame_task_bronze",
  "ownedTitles": ["title_newbie", "title_learner"],
  "ownedFrames": ["frame_default", "frame_task_bronze"],
  "xpToNextLevel": 250,
  "levelProgress": 62.5,
  "stats": {
    "tasksCompleted": 45,
    "examsCompleted": 12,
    "perfectScores": 3,
    "highScoreTasks": 28
  }
}
```

---

### 2.2 GET `/api/students/me/badges`

獲取徽章列表與解鎖狀態

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| category | string | 篩選類別：task, exam, accuracy, perfect, honest, highscore, path, early, night, daily, collect |

**Response:**

```typescript
interface BadgesResponse {
  badges: Badge[];
  summary: {
    total: number;
    unlocked: number;
    byRarity: {
      bronze: { total: number; unlocked: number };
      silver: { total: number; unlocked: number };
      gold: { total: number; unlocked: number };
      diamond: { total: number; unlocked: number };
    };
  };
}

interface Badge {
  id: string;
  name: string;
  description: string;
  category: string;
  rarity: 'bronze' | 'silver' | 'gold' | 'diamond';
  imageUrl: string;

  // 解鎖狀態
  isUnlocked: boolean;
  unlockedAt?: string;          // ISO datetime

  // 進度
  condition: {
    type: string;
    target: number;
    current: number;
  };

  // 獎勵
  rewards: {
    xp: number;
    coins: number;
  };
}
```

---

### 2.3 GET `/api/students/me/frames`

獲取頭像框列表與擁有狀態

**Response:**

```typescript
interface FramesResponse {
  frames: Frame[];
  equippedId: string;
}

interface Frame {
  id: string;
  name: string;
  description: string;
  rarity: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';
  imageUrl: string;

  // 獲取方式
  acquisitionType: 'free' | 'achievement' | 'purchase';

  // 擁有狀態
  isOwned: boolean;
  ownedAt?: string;

  // 購買資訊（僅 purchase 類型）
  purchaseInfo?: {
    price: number;
    levelRequired: number;
    canPurchase: boolean;        // 金幣足夠 && 等級達標
  };

  // 解鎖資訊（僅 achievement 類型）
  unlockCondition?: {
    description: string;
    current: number;
    target: number;
  };
}
```

---

### 2.4 GET `/api/students/me/titles`

獲取稱號列表與擁有狀態

**Response:**

```typescript
interface TitlesResponse {
  titles: Title[];
  equippedId: string;
}

interface Title {
  id: string;
  name: string;
  description: string;
  rarity: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';

  // 獲取方式
  acquisitionType: 'free' | 'achievement' | 'purchase';

  // 擁有狀態
  isOwned: boolean;
  ownedAt?: string;

  // 購買資訊
  purchaseInfo?: {
    price: number;
    levelRequired: number;
    canPurchase: boolean;
  };

  // 解鎖資訊
  unlockCondition?: {
    description: string;
    current: number;
    target: number;
  };
}
```

---

### 2.5 PUT `/api/students/me/equip`

裝備稱號/頭像框

**Request:**

```typescript
interface EquipRequest {
  type: 'title' | 'frame';
  itemId: string;
}
```

**Response:**

```typescript
interface EquipResponse {
  success: boolean;
  equipped: {
    type: 'title' | 'frame';
    itemId: string;
    name: string;
  };
}
```

**錯誤碼：**

| Code | 說明 |
|------|------|
| 400 | 無效的 type 或 itemId |
| 403 | 尚未擁有此道具 |

---

### 2.6 GET `/api/shop/items`

獲取商店商品列表

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| scope | string | platform / org / all (預設 all) |
| type | string | title / frame / virtual / physical |
| category | string | 商品分類 |

**Response:**

```typescript
interface ShopItemsResponse {
  platformItems: ShopItem[];
  orgItems: ShopItem[];         // 該學生所屬機構的商品
  userInfo: {
    coins: number;
    level: number;
  };
}

interface ShopItem {
  id: string;
  type: 'title' | 'frame' | 'virtual' | 'physical';
  name: string;
  description: string;
  imageUrl: string;

  // 價格
  price: number;
  levelRequired: number;

  // 分類
  category: string;
  rarity?: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';

  // 可用性
  isActive: boolean;
  stock?: number;               // 實體商品庫存

  // 所屬
  scope: 'platform' | 'org';
  orgId?: string;

  // 購買狀態
  purchaseStatus: {
    canPurchase: boolean;
    reason?: 'owned' | 'insufficient_coins' | 'level_required' | 'out_of_stock';
    isOwned: boolean;           // 已擁有（title/frame）
  };
}
```

---

### 2.7 POST `/api/shop/purchase`

購買商品

**Request:**

```typescript
interface PurchaseRequest {
  itemId: string;
  quantity?: number;            // 預設 1，實體商品可指定數量
}
```

**Response:**

```typescript
interface PurchaseResponse {
  success: boolean;
  order?: {
    id: string;
    orderNumber: string;
    status: 'completed' | 'pending';  // 虛擬道具立即完成
    item: {
      id: string;
      name: string;
      type: string;
    };
    price: number;
  };
  updatedCoins: number;

  // 虛擬道具才有
  acquired?: {
    type: 'title' | 'frame';
    itemId: string;
  };
}
```

**錯誤碼：**

| Code | 說明 |
|------|------|
| 400 | 無效的商品 ID |
| 402 | 金幣不足 |
| 403 | 等級不足 |
| 409 | 已擁有（虛擬道具）|
| 410 | 缺貨（實體商品）|

---

### 2.8 GET `/api/students/me/orders`

獲取訂單列表

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| status | string | pending / confirmed / completed / cancelled |
| page | number | 頁碼，預設 1 |
| limit | number | 每頁數量，預設 20 |

**Response:**

```typescript
interface OrdersResponse {
  orders: Order[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

interface Order {
  id: string;
  orderNumber: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';

  item: {
    id: string;
    name: string;
    type: string;
    imageUrl: string;
    price: number;
  };

  quantity: number;
  totalPrice: number;

  createdAt: string;
  confirmedAt?: string;
  completedAt?: string;
}
```

---

## 3. 排行榜 API

### 3.1 GET `/api/leaderboard`

獲取排行榜

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| scope | string | class / school / global (預設 class) |
| classId | string | 班級 ID（scope=class 時必填）|
| metric | string | xp / level / badges (預設 xp) |
| limit | number | 數量，預設 50，最大 100 |

**Response:**

```typescript
interface LeaderboardResponse {
  scope: 'class' | 'school' | 'global';
  metric: 'xp' | 'level' | 'badges';

  rankings: RankingEntry[];

  currentUser: {
    rank: number;
    entry: RankingEntry;
  };
}

interface RankingEntry {
  rank: number;
  studentId: string;
  name: string;
  avatar: string;
  equippedTitle: string;
  equippedFrame: string;

  // 排行數據
  totalXp: number;
  level: number;
  badgeCount: number;
}
```

---

## 4. 機構商店 API

### 4.1 GET `/api/orgs/:orgId/shop/items`

獲取機構商品列表

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| status | string | active / inactive / all |
| type | string | privilege / physical / virtual |

**Response:**

```typescript
interface OrgShopItemsResponse {
  items: OrgShopItem[];
  summary: {
    total: number;
    active: number;
    outOfStock: number;
  };
}

interface OrgShopItem {
  id: string;
  type: 'privilege' | 'physical' | 'virtual';
  name: string;
  description: string;
  imageUrl: string;

  price: number;
  levelRequired: number;

  isActive: boolean;
  stock?: number;
  isUnlimited: boolean;
  lowStockThreshold?: number;

  maxPerUser?: number;

  createdAt: string;
  updatedAt: string;

  // 統計
  stats: {
    totalSold: number;
    revenue: number;
  };
}
```

---

### 4.2 POST `/api/orgs/:orgId/shop/items`

新增機構商品

**Request:**

```typescript
interface CreateOrgItemRequest {
  type: 'privilege' | 'physical' | 'virtual';
  name: string;
  description: string;
  imageUrl: string;

  price: number;
  levelRequired?: number;       // 預設 1

  stock?: number;               // 實體商品
  isUnlimited?: boolean;        // 預設 false
  lowStockThreshold?: number;

  maxPerUser?: number;          // 0 = 不限
}
```

**Response:**

```typescript
interface CreateOrgItemResponse {
  success: boolean;
  item: OrgShopItem;
}
```

---

### 4.3 PUT `/api/orgs/:orgId/shop/items/:id`

更新機構商品

**Request:**

```typescript
interface UpdateOrgItemRequest {
  name?: string;
  description?: string;
  imageUrl?: string;

  price?: number;
  levelRequired?: number;

  stock?: number;
  isUnlimited?: boolean;
  lowStockThreshold?: number;

  maxPerUser?: number;
  isActive?: boolean;
}
```

---

### 4.4 DELETE `/api/orgs/:orgId/shop/items/:id`

刪除機構商品（軟刪除）

**Response:**

```typescript
interface DeleteOrgItemResponse {
  success: boolean;
  message: string;
}
```

**錯誤碼：**

| Code | 說明 |
|------|------|
| 400 | 有待處理訂單，無法刪除 |

---

## 5. 機構訂單 API

### 5.1 GET `/api/orgs/:orgId/orders`

獲取機構訂單列表

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| status | string | pending / confirmed / completed / cancelled / all |
| page | number | 頁碼 |
| limit | number | 每頁數量 |
| studentId | string | 篩選特定學生 |
| classId | string | 篩選特定班級 |

**Response:**

```typescript
interface OrgOrdersResponse {
  orders: OrgOrder[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
  summary: {
    pending: number;
    confirmed: number;
    completed: number;
    cancelled: number;
  };
}

interface OrgOrder {
  id: string;
  orderNumber: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';

  student: {
    id: string;
    name: string;
    avatar: string;
    className: string;
  };

  item: {
    id: string;
    name: string;
    type: string;
    imageUrl: string;
    price: number;
  };

  quantity: number;
  totalPrice: number;

  createdAt: string;
  confirmedAt?: string;
  completedAt?: string;
  cancelledAt?: string;

  note?: string;
}
```

---

### 5.2 PUT `/api/orgs/:orgId/orders/:id/confirm`

確認訂單

**Request:**

```typescript
interface ConfirmOrderRequest {
  note?: string;
}
```

**Response:**

```typescript
interface ConfirmOrderResponse {
  success: boolean;
  order: OrgOrder;
}
```

---

### 5.3 PUT `/api/orgs/:orgId/orders/:id/complete`

完成訂單

**Request:**

```typescript
interface CompleteOrderRequest {
  note?: string;
}
```

---

### 5.4 PUT `/api/orgs/:orgId/orders/:id/cancel`

取消訂單（退款）

**Request:**

```typescript
interface CancelOrderRequest {
  reason: string;
}
```

**Response:**

```typescript
interface CancelOrderResponse {
  success: boolean;
  order: OrgOrder;
  refund: {
    coins: number;
    studentId: string;
  };
}
```

---

## 6. 機構統計 API

### 6.1 GET `/api/orgs/:orgId/game-stats`

獲取機構遊戲化統計

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| classId | string | 篩選特定班級 |

**Response:**

```typescript
interface OrgGameStatsResponse {
  overview: {
    totalStudents: number;
    activeStudents: number;      // 7 天內有活動
    totalXp: number;
    totalCoins: number;
    totalBadges: number;
    averageLevel: number;
  };

  distribution: {
    levelDistribution: { level: number; count: number }[];
    badgeDistribution: { rarity: string; count: number }[];
  };

  topPerformers: {
    byXp: { studentId: string; name: string; value: number }[];
    byBadges: { studentId: string; name: string; value: number }[];
  };

  shopStats: {
    totalOrders: number;
    totalRevenue: number;
    pendingOrders: number;
    popularItems: { itemId: string; name: string; count: number }[];
  };
}
```

---

### 6.2 GET `/api/orgs/:orgId/game-stats/trends`

獲取趨勢數據

**Query Parameters:**

| 參數 | 類型 | 說明 |
|------|------|------|
| period | string | week / month / quarter |
| metric | string | xp / coins / badges / active_users |

**Response:**

```typescript
interface TrendsResponse {
  period: string;
  metric: string;

  data: {
    date: string;               // YYYY-MM-DD
    value: number;
  }[];

  comparison: {
    current: number;
    previous: number;
    changePercent: number;
  };
}
```

---

## 7. 錯誤回應格式

所有 API 錯誤使用統一格式：

```typescript
interface ErrorResponse {
  error: {
    code: string;               // 錯誤碼
    message: string;            // 人類可讀訊息
    details?: any;              // 額外資訊
  };
}
```

**常見錯誤碼：**

| HTTP | Code | 說明 |
|------|------|------|
| 400 | INVALID_REQUEST | 請求格式錯誤 |
| 401 | UNAUTHORIZED | 未認證 |
| 403 | FORBIDDEN | 無權限 |
| 404 | NOT_FOUND | 資源不存在 |
| 409 | CONFLICT | 衝突（如已擁有）|
| 422 | VALIDATION_ERROR | 驗證失敗 |
| 500 | INTERNAL_ERROR | 伺服器錯誤 |

---

## 8. 相關文件

| 文件 | 說明 |
|------|------|
| [資料依賴](./01-DATA_DEPENDENCY.md) | 現有可用 API 資料 |
| [後端需求](./03-BACKEND_REQUIREMENTS.md) | 資料庫與觸發器 |
| [資料模型](../overview/02-DATA_MODEL.md) | 完整資料結構 |
