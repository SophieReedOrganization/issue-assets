# Gamification System Specifications

> 遊戲化獎勵系統完整規格書

---

## 目錄結構

```
specs/
├── README.md                    # 本文件 - 規格書總覽與索引
├── overview/                    # 系統總覽
│   ├── 01-SYSTEM_OVERVIEW.md    # 系統架構與核心概念
│   ├── 02-DATA_MODEL.md         # 資料模型與 API 依賴
│   └── 03-REWARD_RULES.md       # 獎勵規則與數值平衡
├── student-app/                 # 學生端規格
│   ├── 01-BADGE_SYSTEM.md       # 徽章系統
│   ├── 02-FRAME_TITLE_SYSTEM.md # 頭像框與稱號系統
│   ├── 03-SHOP_SYSTEM.md        # 商店系統
│   ├── 04-LEADERBOARD.md        # 排行榜系統
│   └── 05-UI_SPEC.md            # UI/UX 規格
├── org-admin/                   # 機構管理端規格
│   ├── 01-DASHBOARD.md          # 遊戲化數據儀表板
│   ├── 02-SHOP_MANAGEMENT.md    # 機構商店管理
│   └── 03-REWARD_CONFIG.md      # 獎勵設定
├── api/                         # API 規格
│   ├── 01-DATA_DEPENDENCY.md    # 現有 API 資料依賴
│   ├── 02-NEW_ENDPOINTS.md      # 需要新增的 API
│   └── 03-BACKEND_REQUIREMENTS.md # 後端需求
└── assets/                      # 資產清單
    ├── 01-BADGE_ASSETS.md       # 徽章圖片資產
    └── 02-FRAME_ASSETS.md       # 頭像框圖片資產
```

---

## 快速導覽

### 核心系統

| 文件 | 說明 | 優先級 |
|------|------|--------|
| [系統總覽](./overview/01-SYSTEM_OVERVIEW.md) | 系統架構、核心循環、角色權限 | P0 |
| [資料模型](./overview/02-DATA_MODEL.md) | 資料結構、API 依賴、後端需求 | P0 |
| [獎勵規則](./overview/03-REWARD_RULES.md) | XP/金幣獲取、等級升級、數值平衡 | P0 |

### 學生端功能

| 文件 | 說明 | Phase |
|------|------|-------|
| [徽章系統](./student-app/01-BADGE_SYSTEM.md) | 64 個徽章定義、解鎖條件、圖片資產 | Phase 1 |
| [頭像框與稱號](./student-app/02-FRAME_TITLE_SYSTEM.md) | 31 頭像框 + 30 稱號、獲取方式 | Phase 1 |
| [商店系統](./student-app/03-SHOP_SYSTEM.md) | 平台商店 + 機構商店、商品定價 | Phase 1 |
| [排行榜](./student-app/04-LEADERBOARD.md) | 班級/學校/全站排行、週期結算 | Phase 2 |
| [UI 規格](./student-app/05-UI_SPEC.md) | 頁面佈局、互動設計、動畫效果 | Phase 1 |

### 機構管理端

| 文件 | 說明 | Phase |
|------|------|-------|
| [數據儀表板](./org-admin/01-DASHBOARD.md) | 學生遊戲化數據統計、報表 | Phase 2 |
| [商店管理](./org-admin/02-SHOP_MANAGEMENT.md) | 機構專屬商品上架、庫存管理 | Phase 2 |
| [獎勵設定](./org-admin/03-REWARD_CONFIG.md) | 自訂獎勵規則、活動設定 | Phase 3 |

### API 與後端

| 文件 | 說明 |
|------|------|
| [現有 API 依賴](./api/01-DATA_DEPENDENCY.md) | 可直接使用的後端資料 |
| [新增 API](./api/02-NEW_ENDPOINTS.md) | 需要新增的 API endpoints |
| [後端需求](./api/03-BACKEND_REQUIREMENTS.md) | 資料庫欄位、統計查詢需求 |

---

## 現有 API 資料支援度

### 可立即使用（Phase 1）

| 資料來源 | 欄位 | 支援功能 |
|----------|------|----------|
| `StudentPathTask` | `status` | 任務完成計數 |
| `StudentPathTask` | `achieved_score` | 任務高分判定 |
| `StudentPathTask` | `completed_at` | 完成時間（早起/夜間徽章）|
| `ExamSubmission` | `accuracy_rate` | 正確率、滿分判定 |
| `ExamSubmission` | `is_guessing_detected` | 誠實作答判定 |
| `StudentPathDetail` | `progress_percentage` | 學習路徑進度 |
| `StudentDailyTasks` | `completion_rate` | 每日任務完成率 |

### 需後端新增（Phase 2）

| 欄位 | 類型 | 說明 | 優先級 |
|------|------|------|--------|
| `total_xp` | number | 累計經驗值 | P0 |
| `level` | number | 當前等級 | P0 |
| `coins` | number | 金幣餘額 | P0 |
| `badges_earned` | array | 已獲得徽章 | P0 |
| `current_streak` | number | 連續學習天數 | P1 |

---

## 資產統計

| 類型 | 數量 | 存放位置 |
|------|------|----------|
| 徽章圖片 | 64 個 | `assets/badges/` |
| 頭像框圖片 | 31 個 | `assets/frames/` |
| 頭像框備份（手遊風格）| 25 個 | `assets/frames_backup_mobile_game_style/` |

---

## 版本記錄

| 版本 | 日期 | 說明 |
|------|------|------|
| 1.0 | 2025-01-07 | 初版規格書建立 |

---

## 相關文件

- 舊版綜合規格書：`docs/GAMIFICATION_SYSTEM_SPEC.md`
- UI 原型規格：`docs/LEADERBOARD_UI_SPEC.md`
- 獎勵平衡分析：`docs/REWARD_BALANCE_ANALYSIS.md`
