# 徽章系統

> 64 個徽章定義、解鎖條件、圖片資產

---

## 1. 徽章概述

### 1.1 稀有度與獎勵

| 稀有度 | 數量 | XP 獎勵 | 金幣獎勵 | 代表色 |
|--------|------|---------|----------|--------|
| 🥉 銅牌 (Bronze) | 22 | 30 XP | 10 幣 | #CD7F32 |
| 🥈 銀牌 (Silver) | 20 | 75 XP | 30 幣 | #C0C0C0 |
| 🥇 金牌 (Gold) | 11 | 150 XP | 75 幣 | #FFD700 |
| 💎 鑽石 (Diamond) | 11 | 300 XP | 150 幣 | #B9F2FF |
| **總計** | **64** | | | |

### 1.2 系列分佈

| 系列 | 數量 | API 資料來源 | 狀態 |
|------|------|--------------|------|
| 📚 任務完成 | 7 | `StudentPathTask.status` | ✅ 可用 |
| 📝 試卷完成 | 6 | `ExamSubmission` count | ✅ 可用 |
| 🎯 正確率 | 6 | `ExamSubmission.accuracy_rate` | ✅ 可用 |
| 💯 滿分 | 6 | `accuracy_rate = 100` | ✅ 可用 |
| 💚 誠實作答 | 6 | `is_guessing_detected = false` | ✅ 可用 |
| ⭐ 任務高分 | 6 | `achieved_score >= 80` | ✅ 可用 |
| 📊 學習路徑 | 6 | `progress_percentage` | ✅ 可用 |
| 🌅 早起學習 | 5 | `completed_at` 時間 | ✅ 可用 |
| 🌙 夜間學習 | 5 | `completed_at` 時間 | ✅ 可用 |
| 📅 每日任務 | 6 | `completion_rate = 100` | ✅ 可用 |
| 🎁 收集 | 5 | 徽章數量 | ✅ 可用 |

---

## 2. 徽章詳細定義

### 📚 任務完成系列（7 個）

**資料來源：** `StudentPathTask.status = 'completed'` 的累計數量

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| task_10 | 起步者 | 🥉 銅 | 累計完成 10 個任務 | 30 | 10 | task_10.png |
| task_30 | 進擊者 | 🥉 銅 | 累計完成 30 個任務 | 30 | 10 | task_30.png |
| task_50 | 學習小將 | 🥉 銅 | 累計完成 50 個任務 | 30 | 10 | task_50.png |
| task_100 | 學習達人 | 🥈 銀 | 累計完成 100 個任務 | 75 | 30 | task_100.png |
| task_200 | 知識探險家 | 🥈 銀 | 累計完成 200 個任務 | 75 | 30 | task_200.png |
| task_500 | 知識巨人 | 🥇 金 | 累計完成 500 個任務 | 150 | 75 | task_500.png |
| task_1000 | 傳說學者 | 💎 鑽石 | 累計完成 1,000 個任務 | 300 | 150 | task_1000.png |

---

### 📝 試卷完成系列（6 個）

**資料來源：** `ExamSubmission` 提交紀錄累計數量

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| exam_5 | 初試身手 | 🥉 銅 | 累計完成 5 份試卷 | 30 | 10 | exam_5.png |
| exam_15 | 小試牛刀 | 🥉 銅 | 累計完成 15 份試卷 | 30 | 10 | exam_15.png |
| exam_30 | 考場老手 | 🥈 銀 | 累計完成 30 份試卷 | 75 | 30 | exam_30.png |
| exam_60 | 考試達人 | 🥈 銀 | 累計完成 60 份試卷 | 75 | 30 | exam_60.png |
| exam_100 | 考試專家 | 🥇 金 | 累計完成 100 份試卷 | 150 | 75 | exam_100.png |
| exam_200 | 考場傳說 | 💎 鑽石 | 累計完成 200 份試卷 | 300 | 150 | exam_200.png |

---

### 🎯 正確率系列（6 個）

**資料來源：** `ExamSubmission.accuracy_rate`

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| acc_pass_10 | 合格新手 | 🥉 銅 | 累計 10 份試卷正確率 ≥60% | 30 | 10 | acc_pass_10.png |
| acc_pass_30 | 穩定發揮 | 🥉 銅 | 累計 30 份試卷正確率 ≥60% | 30 | 10 | acc_pass_30.png |
| acc_good_10 | 優秀學員 | 🥈 銀 | 累計 10 份試卷正確率 ≥80% | 75 | 30 | acc_good_10.png |
| acc_good_30 | 實力派 | 🥈 銀 | 累計 30 份試卷正確率 ≥80% | 75 | 30 | acc_good_30.png |
| acc_high_10 | 高分王者 | 🥇 金 | 累計 10 份試卷正確率 ≥90% | 150 | 75 | acc_high_10.png |
| acc_high_30 | 學神降臨 | 💎 鑽石 | 累計 30 份試卷正確率 ≥90% | 300 | 150 | acc_high_30.png |

---

### 💯 滿分系列（6 個）

**資料來源：** `ExamSubmission.accuracy_rate = 100`

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| perfect_1 | 首次滿分 | 🥉 銅 | 獲得 1 次滿分 | 30 | 10 | perfect_1.png |
| perfect_3 | 滿分三連 | 🥉 銅 | 累計 3 次滿分 | 30 | 10 | perfect_3.png |
| perfect_10 | 滿分達人 | 🥈 銀 | 累計 10 次滿分 | 75 | 30 | perfect_10.png |
| perfect_25 | 完美主義者 | 🥈 銀 | 累計 25 次滿分 | 75 | 30 | perfect_25.png |
| perfect_50 | 滿分傳說 | 🥇 金 | 累計 50 次滿分 | 150 | 75 | perfect_50.png |
| perfect_100 | 零缺點神話 | 💎 鑽石 | 累計 100 次滿分 | 300 | 150 | perfect_100.png |

---

### 💚 誠實作答系列（6 個）

**資料來源：** `ExamSubmission.is_guessing_detected = false`

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| honest_5 | 誠實小將 | 🥉 銅 | 累計 5 份試卷無猜題 | 30 | 10 | honest_5.png |
| honest_15 | 認真學習者 | 🥉 銅 | 累計 15 份試卷無猜題 | 30 | 10 | honest_15.png |
| honest_30 | 誠實達人 | 🥈 銀 | 累計 30 份試卷無猜題 | 75 | 30 | honest_30.png |
| honest_60 | 誠實大師 | 🥈 銀 | 累計 60 份試卷無猜題 | 75 | 30 | honest_60.png |
| honest_100 | 誠實傳說 | 🥇 金 | 累計 100 份試卷無猜題 | 150 | 75 | honest_100.png |
| honest_200 | 誠信典範 | 💎 鑽石 | 累計 200 份試卷無猜題 | 300 | 150 | honest_200.png |

---

### ⭐ 任務高分系列（6 個）

**資料來源：** `StudentPathTask.achieved_score >= 80`

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| highscore_10 | 高分新秀 | 🥉 銅 | 累計 10 個任務得分 ≥80 | 30 | 10 | highscore_10.png |
| highscore_30 | 高分好手 | 🥉 銅 | 累計 30 個任務得分 ≥80 | 30 | 10 | highscore_30.png |
| highscore_60 | 高分常客 | 🥈 銀 | 累計 60 個任務得分 ≥80 | 75 | 30 | highscore_60.png |
| highscore_100 | 高分專家 | 🥈 銀 | 累計 100 個任務得分 ≥80 | 75 | 30 | highscore_100.png |
| highscore_200 | 高分大師 | 🥇 金 | 累計 200 個任務得分 ≥80 | 150 | 75 | highscore_200.png |
| highscore_500 | 高分之神 | 💎 鑽石 | 累計 500 個任務得分 ≥80 | 300 | 150 | highscore_500.png |

---

### 📊 學習路徑系列（6 個）

**資料來源：** `StudentPathDetail.progress_percentage`

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| path_25 | 啟程者 | 🥉 銅 | 任一學習路徑進度達 25% | 30 | 10 | path_25.png |
| path_50 | 中途站 | 🥉 銅 | 任一學習路徑進度達 50% | 30 | 10 | path_50.png |
| path_75 | 即將完成 | 🥈 銀 | 任一學習路徑進度達 75% | 75 | 30 | path_75.png |
| path_100 | 路徑征服者 | 🥈 銀 | 任一學習路徑完成 100% | 75 | 30 | path_100.png |
| path_complete_3 | 多路精通 | 🥇 金 | 完成 3 條學習路徑 | 150 | 75 | path_complete_3.png |
| path_complete_5 | 路徑霸主 | 💎 鑽石 | 完成 5 條學習路徑 | 300 | 150 | path_complete_5.png |

---

### 🌅 早起學習系列（5 個）

**資料來源：** 任務完成時間（06:00-08:00）

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| early_5 | 早起鳥兒 | 🥉 銅 | 清晨 6-8 點完成 5 個任務 | 30 | 10 | early_5.png |
| early_20 | 晨曦學者 | 🥉 銅 | 清晨 6-8 點完成 20 個任務 | 30 | 10 | early_20.png |
| early_50 | 黎明守護者 | 🥈 銀 | 清晨 6-8 點完成 50 個任務 | 75 | 30 | early_50.png |
| early_100 | 早安達人 | 🥇 金 | 清晨 6-8 點完成 100 個任務 | 150 | 75 | early_100.png |
| early_300 | 晨光傳說 | 💎 鑽石 | 清晨 6-8 點完成 300 個任務 | 300 | 150 | early_300.png |

---

### 🌙 夜間學習系列（5 個）

**資料來源：** 任務完成時間（20:00-23:00）

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| night_5 | 夜貓學習者 | 🥉 銅 | 晚間 20-23 點完成 5 個任務 | 30 | 10 | night_5.png |
| night_20 | 星空下的努力 | 🥉 銅 | 晚間 20-23 點完成 20 個任務 | 30 | 10 | night_20.png |
| night_50 | 月光學者 | 🥈 銀 | 晚間 20-23 點完成 50 個任務 | 75 | 30 | night_50.png |
| night_100 | 夜間達人 | 🥇 金 | 晚間 20-23 點完成 100 個任務 | 150 | 75 | night_100.png |
| night_300 | 星夜傳說 | 💎 鑽石 | 晚間 20-23 點完成 300 個任務 | 300 | 150 | night_300.png |

---

### 📅 每日任務系列（6 個）

**資料來源：** `StudentDailyTasks.completion_rate = 100`

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| daily_3 | 每日達成 | 🥉 銅 | 累計 3 天完成當日所有任務 | 30 | 10 | daily_3.png |
| daily_7 | 週週完美 | 🥉 銅 | 累計 7 天完成當日所有任務 | 30 | 10 | daily_7.png |
| daily_14 | 雙週滿勤 | 🥈 銀 | 累計 14 天完成當日所有任務 | 75 | 30 | daily_14.png |
| daily_30 | 月度模範 | 🥈 銀 | 累計 30 天完成當日所有任務 | 75 | 30 | daily_30.png |
| daily_60 | 完美執行者 | 🥇 金 | 累計 60 天完成當日所有任務 | 150 | 75 | daily_60.png |
| daily_100 | 每日傳說 | 💎 鑽石 | 累計 100 天完成當日所有任務 | 300 | 150 | daily_100.png |

---

### 🎁 收集系列（5 個）

**資料來源：** 徽章收集數量

| ID | 名稱 | 稀有度 | 條件 | XP | 金幣 | 圖片 |
|----|------|--------|------|-----|------|------|
| collect_10 | 收藏家新手 | 🥉 銅 | 收集 10 個徽章 | 30 | 10 | collect_10.png |
| collect_25 | 徽章愛好者 | 🥈 銀 | 收集 25 個徽章 | 75 | 30 | collect_25.png |
| collect_50 | 收藏達人 | 🥈 銀 | 收集 50 個徽章 | 75 | 30 | collect_50.png |
| collect_55 | 收藏大師 | 🥇 金 | 收集 55 個徽章 | 150 | 75 | collect_55.png |
| collect_all | 全徽章制霸 | 💎 鑽石 | 收集所有 59 個非收集類徽章 | 300 | 150 | collect_all.png |

> **注意：** 收集系列有 5 個徽章，因此「全徽章制霸」的條件是收集其他 59 個非收集類徽章（64 - 5 = 59）。

---

## 3. 圖片資產

### 3.1 存放位置

```
assets/badges/
├── task_10.png
├── task_30.png
├── task_50.png
├── task_100.png
├── task_200.png
├── task_500.png
├── task_1000.png
├── exam_5.png
├── exam_15.png
├── ... (共 64 個)
```

### 3.2 圖片規格

| 項目 | 規格 |
|------|------|
| 格式 | PNG (透明背景) |
| 尺寸 | 1:1 正方形 |
| 風格 | 柔軟黏土質感 + 高光 |
| 形狀 | 六角形盾牌 + 緞帶 |
| 邊框 | 奶油色/米色 |

### 3.3 風格描述

- 六角形盾牌造型（尖頂朝上）
- 厚實奶油色邊框（軟陶/翻糖質感）
- 底部小緞帶裝飾
- 柔和高光效果（邊緣頂部有光澤）
- 中心圖標為金色/奶油色
- 內部背景色依稀有度變化：
  - 銅：珊瑚紅
  - 銀：銀藍色
  - 金：金黃色
  - 鑽石：紫色

---

## 4. 解鎖檢查邏輯

```typescript
interface BadgeUnlockCondition {
  type: 'count' | 'percentage' | 'time_range';
  field: string;
  operator: 'gte' | 'eq' | 'between';
  value: number | [number, number];
  dataSource: string;
}

// 範例：任務完成系列
const taskBadgeConditions: Record<string, BadgeUnlockCondition> = {
  task_10: {
    type: 'count',
    field: 'status',
    operator: 'gte',
    value: 10,
    dataSource: 'StudentPathTask WHERE status = completed',
  },
  // ...
};

// 範例：早起學習系列
const earlyBadgeConditions: Record<string, BadgeUnlockCondition> = {
  early_5: {
    type: 'time_range',
    field: 'completed_at',
    operator: 'between',
    value: [6, 8], // 6:00 - 8:00
    dataSource: 'StudentPathTask WHERE HOUR(completed_at) BETWEEN 6 AND 8',
  },
  // ...
};

// 檢查函數
async function checkBadgeUnlock(
  studentId: string,
  badgeId: string
): Promise<boolean> {
  const condition = getBadgeCondition(badgeId);
  const currentValue = await queryCurrentValue(studentId, condition);
  return evaluateCondition(currentValue, condition);
}
```

---

## 5. 相關文件

| 文件 | 說明 |
|------|------|
| [資料模型](../overview/02-DATA_MODEL.md) | 徽章資料結構 |
| [獎勵規則](../overview/03-REWARD_RULES.md) | 徽章獎勵數值 |
| [徽章資產清單](../assets/01-BADGE_ASSETS.md) | 圖片檔案清單 |
