# 頭像框與稱號系統

> 31 個頭像框 + 30 個稱號定義、獲取方式、解鎖條件

---

## 1. 系統概述

### 1.1 獲取方式統計

| 類別 | 免費贈送 | 成就解鎖 | 金幣兌換 | 總計 |
|------|----------|----------|----------|------|
| 頭像框 | 4 | 12 | 15 | **31** |
| 稱號 | 3 | 15 | 12 | **30** |
| **總計** | **7** | **27** | **27** | **61** |

### 1.2 裝備規則

| 規則 | 說明 |
|------|------|
| 稱號裝備 | 一次只能裝備一個稱號 |
| 頭像框裝備 | 一次只能裝備一個頭像框 |
| 預設裝備 | 新用戶預設「新手學員」稱號 + 「基礎邊框」頭像框 |

### 1.3 顯示位置

| 位置 | 顯示內容 |
|------|----------|
| 導航列 | 頭像（含邊框）+ 稱號 |
| 個人資料卡 | 頭像（含邊框）+ 稱號 + 等級 |
| 排行榜 | 頭像（含邊框）+ 稱號 |
| 留言/互動 | 頭像（含邊框）|

---

## 2. 頭像框系統

### 2.1 免費贈送頭像框（4 個）

**獲取條件：** 系統自動贈送

| ID | 名稱 | 稀有度 | 觸發條件 | 圖片 |
|----|------|--------|----------|------|
| frame_default | 基礎邊框 | ⬜ 普通 | 註冊即獲得 | frame_default.png |
| frame_welcome | 新手之星 | ⬜ 普通 | 完成新手引導 | frame_welcome.png |
| frame_first_task | 學習起步 | ⬜ 普通 | 完成第一個任務 | frame_first_task.png |
| frame_first_exam | 初次挑戰 | ⬜ 普通 | 完成第一份試卷 | frame_first_exam.png |

---

### 2.2 成就解鎖頭像框（12 個）

**獲取條件：** 達成特定成就自動解鎖

#### 任務系列（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| frame_task_bronze | 勤學者 | 🥉 銅 | 累計完成 50 個任務 | `status = completed` |
| frame_task_silver | 學習之星 | 🥈 銀 | 累計完成 200 個任務 | `status = completed` |
| frame_task_gold | 知識王者 | 🥇 金 | 累計完成 500 個任務 | `status = completed` |

#### 試卷系列（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| frame_exam_bronze | 考試新秀 | 🥉 銅 | 累計完成 15 份試卷 | `ExamSubmission` count |
| frame_exam_silver | 考場老將 | 🥈 銀 | 累計完成 60 份試卷 | `ExamSubmission` count |
| frame_exam_gold | 考試達人 | 🥇 金 | 累計完成 100 份試卷 | `ExamSubmission` count |

#### 滿分系列（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| frame_perfect_bronze | 滿分新星 | 🥉 銅 | 累計 5 次滿分 | `accuracy_rate = 100` |
| frame_perfect_silver | 完美主義 | 🥈 銀 | 累計 25 次滿分 | `accuracy_rate = 100` |
| frame_perfect_gold | 零缺點 | 🥇 金 | 累計 50 次滿分 | `accuracy_rate = 100` |

#### 誠實系列（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| frame_honest_bronze | 誠實之心 | 🥉 銅 | 累計 20 份無猜題 | `is_guessing_detected = false` |
| frame_honest_silver | 誠信達人 | 🥈 銀 | 累計 60 份無猜題 | `is_guessing_detected = false` |
| frame_honest_gold | 誠信典範 | 🥇 金 | 累計 100 份無猜題 | `is_guessing_detected = false` |

---

### 2.3 金幣兌換頭像框（15 個）

**獲取條件：** 使用金幣在商店購買

| ID | 名稱 | 稀有度 | 價格 | 等級需求 | 風格 |
|----|------|--------|------|----------|------|
| frame_flame | 火焰邊框 | 🥉 銅 | 200 幣 | Lv.1 | 熱情火焰效果 |
| frame_ocean | 海洋邊框 | 🥉 銅 | 200 幣 | Lv.1 | 藍色波浪效果 |
| frame_forest | 森林邊框 | 🥉 銅 | 200 幣 | Lv.1 | 綠色樹葉效果 |
| frame_rainbow | 彩虹邊框 | 🥈 銀 | 300 幣 | Lv.2 | 七彩漸層效果 |
| frame_star | 星空邊框 | 🥈 銀 | 300 幣 | Lv.2 | 閃亮星星效果 |
| frame_candy | 糖果邊框 | 🥈 銀 | 300 幣 | Lv.2 | 可愛糖果風格 |
| frame_neon | 霓虹邊框 | 🥈 銀 | 400 幣 | Lv.3 | 霓虹燈效果 |
| frame_crystal | 水晶邊框 | 🥈 銀 | 400 幣 | Lv.3 | 透明水晶效果 |
| frame_sakura | 櫻花邊框 | 🥈 銀 | 400 幣 | Lv.3 | 粉色櫻花飄落 |
| frame_lightning | 雷電邊框 | 🥇 金 | 500 幣 | Lv.5 | 電流閃爍效果 |
| frame_galaxy | 銀河邊框 | 🥇 金 | 500 幣 | Lv.5 | 宇宙星雲效果 |
| frame_phoenix | 鳳凰邊框 | 🥇 金 | 600 幣 | Lv.7 | 火鳳凰羽毛 |
| frame_dragon | 龍騰邊框 | 🥇 金 | 800 幣 | Lv.10 | 金龍環繞效果 |
| frame_legendary | 傳說邊框 | 💎 傳說 | 1,000 幣 | Lv.15 | 金色傳說光環 |
| frame_ultimate | 至尊邊框 | 💎 傳說 | 1,500 幣 | Lv.20 | 最高等級專屬 |

---

### 2.4 頭像框稀有度與顯示

| 稀有度 | 邊框特效 | 獲取方式 |
|--------|----------|----------|
| ⬜ 普通 | 靜態邊框 | 免費贈送 |
| 🥉 銅 | 靜態邊框 | 成就解鎖/商店 200-300 幣 |
| 🥈 銀 | 微光效果 | 成就解鎖/商店 300-400 幣 |
| 🥇 金 | 閃爍效果 | 成就解鎖/商店 500-800 幣 |
| 💎 傳說 | 動態特效 | 商店 1,000+ 幣 |

---

## 3. 稱號系統

### 3.1 免費贈送稱號（3 個）

**獲取條件：** 系統自動贈送

| ID | 名稱 | 稀有度 | 觸發條件 |
|----|------|--------|----------|
| title_newbie | 新手學員 | ⬜ 普通 | 註冊即獲得 |
| title_explorer | 小小探索家 | ⬜ 普通 | 完成新手引導 |
| title_learner | 學習者 | ⬜ 普通 | 累計完成 10 個任務 |

---

### 3.2 成就解鎖稱號（15 個）

**獲取條件：** 達成特定成就自動解鎖

#### 任務相關（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| title_diligent | 勤奮小蜜蜂 | 🥉 銅 | 累計完成 30 個任務 | `status = completed` |
| title_hardworker | 努力王 | 🥈 銀 | 累計完成 100 個任務 | `status = completed` |
| title_scholar | 學霸 | 🥇 金 | 累計完成 300 個任務 | `status = completed` |

#### 試卷相關（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| title_exam_rookie | 考試新兵 | 🥉 銅 | 累計完成 10 份試卷 | `ExamSubmission` count |
| title_exam_veteran | 考場老手 | 🥈 銀 | 累計完成 50 份試卷 | `ExamSubmission` count |
| title_exam_master | 考試大師 | 🥇 金 | 累計完成 100 份試卷 | `ExamSubmission` count |

#### 正確率相關（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| title_accurate | 精準射手 | 🥉 銅 | 累計 10 份試卷正確率 ≥80% | `accuracy_rate >= 80` |
| title_sharpshooter | 神射手 | 🥈 銀 | 累計 30 份試卷正確率 ≥80% | `accuracy_rate >= 80` |
| title_sniper | 百發百中 | 🥇 金 | 累計 10 份試卷正確率 ≥90% | `accuracy_rate >= 90` |

#### 誠實相關（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| title_honest_kid | 誠實寶貝 | 🥉 銅 | 累計 10 份無猜題試卷 | `is_guessing_detected = false` |
| title_honest_star | 誠信之星 | 🥈 銀 | 累計 50 份無猜題試卷 | `is_guessing_detected = false` |
| title_integrity | 誠信典範 | 🥇 金 | 累計 100 份無猜題試卷 | `is_guessing_detected = false` |

#### 特殊相關（3 個）

| ID | 名稱 | 稀有度 | 解鎖條件 | 資料來源 |
|----|------|--------|----------|----------|
| title_early_bird | 早起鳥兒 | 🥈 銀 | 清晨 6-8 點完成 30 個任務 | `completed_at` 時間 |
| title_night_owl | 夜貓子 | 🥈 銀 | 晚間 20-23 點完成 30 個任務 | `completed_at` 時間 |
| title_perfectionist | 完美主義者 | 🥇 金 | 累計 30 次滿分 | `accuracy_rate = 100` |

---

### 3.3 金幣兌換稱號（12 個）

**獲取條件：** 使用金幣在商店購買

| ID | 名稱 | 價格 | 等級需求 | 說明 |
|----|------|------|----------|------|
| title_cool | 酷炫小子 | 200 幣 | Lv.1 | 展現個人風格 |
| title_smart | 小聰明 | 200 幣 | Lv.1 | 聰明伶俐的你 |
| title_brave | 勇敢者 | 250 幣 | Lv.2 | 勇於挑戰的精神 |
| title_genius | 小天才 | 300 幣 | Lv.2 | 天資聰穎 |
| title_star_student | 明星學員 | 400 幣 | Lv.3 | 閃耀的學習之星 |
| title_champion | 學習冠軍 | 500 幣 | Lv.5 | 學習競賽的王者 |
| title_professor | 小教授 | 600 幣 | Lv.7 | 博學多聞 |
| title_sage | 小賢者 | 700 幣 | Lv.8 | 智慧的化身 |
| title_master | 學習大師 | 800 幣 | Lv.10 | 精通學習之道 |
| title_legend | 傳奇學者 | 1,000 幣 | Lv.12 | 傳說中的學習者 |
| title_immortal | 學神 | 1,500 幣 | Lv.15 | 學習的神話 |
| title_supreme | 至尊學霸 | 2,000 幣 | Lv.20 | 最高榮譽稱號 |

---

## 4. 圖片資產

### 4.1 存放位置

```
assets/frames/
├── frame_default.png
├── frame_welcome.png
├── frame_first_task.png
├── frame_first_exam.png
├── frame_task_bronze.png
├── frame_task_silver.png
├── frame_task_gold.png
├── ... (共 31 個)
```

### 4.2 圖片規格

| 項目 | 規格 |
|------|------|
| 格式 | PNG (透明背景) |
| 尺寸 | 1:1 正方形 |
| 風格 | 手遊造型 + 柔軟黏土質感 + 高光 |
| 中心 | 空白圓形（放置頭像）|

### 4.3 風格描述

- 手遊風格造型（翅膀、皇冠、火焰、水晶等裝飾）
- 柔軟黏土/翻糖質感（pillowy、touchable）
- 柔和高光效果
- 中間空白圓形區域（約 60% 寬度）
- 各稀有度有明顯差異

---

## 5. 資料結構

```typescript
interface UserGameProfile {
  // 稱號
  equippedTitle: string;       // 當前裝備的稱號 ID
  ownedTitles: string[];       // 已擁有的稱號 ID 列表

  // 頭像框
  equippedFrame: string;       // 當前裝備的頭像框 ID
  ownedFrames: string[];       // 已擁有的頭像框 ID 列表
}

interface FrameDefinition {
  id: string;
  name: string;
  description: string;
  rarity: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';
  acquisitionType: 'free' | 'achievement' | 'purchase';
  unlockCondition?: UnlockCondition;
  purchaseInfo?: { price: number; levelRequired: number; };
  imageUrl: string;
}

interface TitleDefinition {
  id: string;
  name: string;
  description: string;
  rarity: 'common' | 'bronze' | 'silver' | 'gold' | 'legendary';
  acquisitionType: 'free' | 'achievement' | 'purchase';
  unlockCondition?: UnlockCondition;
  purchaseInfo?: { price: number; levelRequired: number; };
}
```

---

## 6. 獲取難度預估

基於一般學生每月 ~360 幣、~1,000 XP：

| 難度 | 頭像框 | 稱號 | 預估時間 |
|------|--------|------|----------|
| ⬜ 免費 | 4 | 3 | 新手引導階段 |
| 🥉 銅 | 7 | 4 | 1-2 週 |
| 🥈 銀 | 10 | 5 | 1-2 個月 |
| 🥇 金 | 8 | 6 | 3-6 個月 |
| 💎 傳說 | 2 | 12 | 6+ 個月 |

---

## 7. 相關文件

| 文件 | 說明 |
|------|------|
| [商店系統](./03-SHOP_SYSTEM.md) | 金幣兌換流程 |
| [頭像框資產清單](../assets/02-FRAME_ASSETS.md) | 圖片檔案清單 |
