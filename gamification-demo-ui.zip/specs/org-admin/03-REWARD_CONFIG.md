# 獎勵設定

> 機構層級的獎勵倍率調整、特殊活動設定（Phase 3 功能）

---

## 1. 功能概述

### 1.1 設定範圍

| 項目 | 說明 | 預計階段 |
|------|------|----------|
| 獎勵倍率 | 調整 XP/金幣發放倍率 | Phase 3 |
| 活動設定 | 限時加倍活動 | Phase 3 |
| 徽章管理 | 機構專屬徽章（擴展） | Future |

### 1.2 預設使用平台規則

> **Phase 1-2 說明：**
> 初期版本使用平台統一的獎勵規則，機構無法自訂。
> 此文件描述 Phase 3 的擴展功能規劃。

---

## 2. 獎勵倍率設定（Phase 3）

### 2.1 可調整項目

| 項目 | 預設值 | 可調範圍 | 說明 |
|------|--------|----------|------|
| XP 倍率 | 1.0x | 0.5x - 2.0x | 影響所有 XP 獲取 |
| 金幣倍率 | 1.0x | 0.5x - 2.0x | 影響所有金幣獲取 |
| 任務獎勵 | 1.0x | 0.5x - 2.0x | 僅影響任務獎勵 |
| 試卷獎勵 | 1.0x | 0.5x - 2.0x | 僅影響試卷獎勵 |

### 2.2 設定介面

```
┌─────────────────────────────────────────────────────────────┐
│ 獎勵倍率設定                                                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ 全域 XP 倍率                                                 │
│ ├──●──────────────────────────────────────────────┤        │
│ 0.5x              1.0x              1.5x              2.0x   │
│                                                             │
│ 全域金幣倍率                                                  │
│ ├──────────●──────────────────────────────────────┤        │
│ 0.5x              1.0x              1.5x              2.0x   │
│                                                             │
│ ⚠️ 調高倍率會加速學生金幣累積，請同步調整商品價格              │
│                                                             │
│                                         [重置預設]  [儲存]   │
└─────────────────────────────────────────────────────────────┘
```

### 2.3 倍率計算邏輯

```typescript
// Phase 3 獎勵計算
function calculateReward(
  baseXP: number,
  baseCoins: number,
  orgConfig: OrgRewardConfig,
  activeEvent?: Event
) {
  let xpMultiplier = orgConfig.xpMultiplier || 1.0;
  let coinMultiplier = orgConfig.coinMultiplier || 1.0;

  // 活動加成疊加
  if (activeEvent) {
    xpMultiplier *= activeEvent.xpMultiplier || 1.0;
    coinMultiplier *= activeEvent.coinMultiplier || 1.0;
  }

  return {
    xp: Math.floor(baseXP * xpMultiplier),
    coins: Math.floor(baseCoins * coinMultiplier),
  };
}
```

---

## 3. 活動系統（Phase 3）

### 3.1 活動類型

| 類型 | 說明 | 範例 |
|------|------|------|
| 雙倍 XP | 期間內 XP 獲取加倍 | 期末衝刺週 |
| 雙倍金幣 | 期間內金幣獲取加倍 | 兒童節活動 |
| 特定加成 | 指定類型任務加成 | 數學週：數學任務 2x |
| 全面加成 | XP + 金幣同時加倍 | 週年慶 |

### 3.2 活動設定介面

```
┌─────────────────────────────────────────────────────────────┐
│ 新增活動                                              [✕]   │
├─────────────────────────────────────────────────────────────┤
│ 活動名稱: [期末衝刺週______________]                         │
│                                                             │
│ 活動期間:                                                    │
│ 開始: [2024-06-10] [00:00]                                  │
│ 結束: [2024-06-16] [23:59]                                  │
│                                                             │
│ 加成設定:                                                    │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ ☑ XP 加成      倍率: [1.5] x                            │ │
│ │ ☑ 金幣加成     倍率: [1.2] x                            │ │
│ │ ☐ 限定任務類型  類型: [______]                          │ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                             │
│ 活動說明:                                                    │
│ [期末考前一週，努力學習有加倍獎勵！_______________________]    │
│                                                             │
│                                         [取消]  [建立活動]   │
└─────────────────────────────────────────────────────────────┘
```

### 3.3 活動列表

```
┌─────────────────────────────────────────────────────────────┐
│ 活動管理                                        [+ 新增活動] │
├─────────────────────────────────────────────────────────────┤
│ [進行中][已排程][已結束]                                      │
├─────────────────────────────────────────────────────────────┤
│ ┌────────────┬──────────────────┬──────────────┬──────────┐ │
│ │ 活動名稱    │ 期間              │ 加成          │ 狀態     │ │
│ ├────────────┼──────────────────┼──────────────┼──────────┤ │
│ │ 期末衝刺週  │ 06/10 - 06/16    │ XP 1.5x      │ 🟢進行中  │ │
│ │ 暑假預習    │ 07/01 - 07/31    │ 金幣 2x      │ 🔵已排程  │ │
│ │ 開學週      │ 02/15 - 02/21    │ XP+金幣 1.5x │ ⚫已結束  │ │
│ └────────────┴──────────────────┴──────────────┴──────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. 學生端活動顯示

### 4.1 活動 Banner

```
┌─────────────────────────────────────────────────────────────┐
│ 🎉 期末衝刺週                                                │
│ XP 獲得 1.5 倍！                                            │
│ 剩餘 3 天 12 小時                                           │
└─────────────────────────────────────────────────────────────┘
```

### 4.2 獎勵顯示加成標記

```
任務完成！
┌─────────────────────────────┐
│ +10 XP → +15 XP  ⚡1.5x    │
│ +3 金幣                     │
└─────────────────────────────┘
```

---

## 5. 目前版本（Phase 1-2）使用規則

### 5.1 固定獎勵規則

由於 Phase 1-2 不支援機構自訂，所有機構使用平台統一規則：

| 來源 | XP | 金幣 | 備註 |
|------|-----|------|------|
| 任務完成 | 10 | 3 | 基礎獎勵 |
| 任務高分 (≥80) | +5 | +2 | 高分加成 |
| 試卷滿分 | 50 | 20 | - |
| 試卷 ≥80% | 30 | 10 | - |
| 試卷 ≥60% | 20 | 5 | - |
| 無猜題加成 | +10 | +5 | - |

### 5.2 徽章獎勵（固定）

| 稀有度 | XP | 金幣 |
|--------|-----|------|
| 銅牌 | 30 | 10 |
| 銀牌 | 75 | 30 |
| 金牌 | 150 | 75 |
| 鑽石 | 300 | 150 |

---

## 6. Phase 3 資料結構

### 6.1 機構設定

```typescript
interface OrgRewardConfig {
  orgId: string;

  // 全域倍率
  xpMultiplier: number;        // 預設 1.0
  coinMultiplier: number;      // 預設 1.0

  // 分類倍率
  taskXpMultiplier?: number;
  taskCoinMultiplier?: number;
  examXpMultiplier?: number;
  examCoinMultiplier?: number;

  updatedAt: Date;
  updatedBy: string;
}
```

### 6.2 活動資料

```typescript
interface RewardEvent {
  id: string;
  orgId: string;
  name: string;
  description: string;

  // 期間
  startAt: Date;
  endAt: Date;

  // 加成
  xpMultiplier: number;
  coinMultiplier: number;

  // 限定（可選）
  targetTaskTypes?: string[];

  // 狀態
  status: 'scheduled' | 'active' | 'ended';

  createdAt: Date;
  createdBy: string;
}
```

### 6.3 SQL Schema（Phase 3）

```sql
-- 機構獎勵設定
CREATE TABLE org_reward_config (
  org_id UUID PRIMARY KEY REFERENCES organizations(id),
  xp_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
  coin_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
  task_xp_multiplier DECIMAL(3,2),
  task_coin_multiplier DECIMAL(3,2),
  exam_xp_multiplier DECIMAL(3,2),
  exam_coin_multiplier DECIMAL(3,2),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_by UUID REFERENCES users(id)
);

-- 獎勵活動
CREATE TABLE reward_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id),
  name VARCHAR(100) NOT NULL,
  description TEXT,
  start_at TIMESTAMP NOT NULL,
  end_at TIMESTAMP NOT NULL,
  xp_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
  coin_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
  target_task_types JSONB,
  status VARCHAR(20) NOT NULL DEFAULT 'scheduled',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_reward_events_org ON reward_events(org_id);
CREATE INDEX idx_reward_events_status ON reward_events(status);
CREATE INDEX idx_reward_events_period ON reward_events(start_at, end_at);
```

---

## 7. API 規格（Phase 3）

### 7.1 設定 API

| 方法 | 端點 | 說明 |
|------|------|------|
| GET | `/api/orgs/:orgId/reward-config` | 獲取獎勵設定 |
| PUT | `/api/orgs/:orgId/reward-config` | 更新獎勵設定 |

### 7.2 活動 API

| 方法 | 端點 | 說明 |
|------|------|------|
| GET | `/api/orgs/:orgId/events` | 獲取活動列表 |
| POST | `/api/orgs/:orgId/events` | 新增活動 |
| PUT | `/api/orgs/:orgId/events/:id` | 更新活動 |
| DELETE | `/api/orgs/:orgId/events/:id` | 刪除活動 |

---

## 8. 實作優先級

| Phase | 功能 | 說明 |
|-------|------|------|
| Phase 1 | 固定規則 | 使用平台統一獎勵規則 |
| Phase 2 | 固定規則 | 同上 |
| Phase 3 | 獎勵倍率設定 | 機構可調整倍率 |
| Phase 3 | 活動系統 | 限時加倍活動 |
| Future | 自訂徽章 | 機構專屬徽章 |

---

## 9. 相關文件

| 文件 | 說明 |
|------|------|
| [獎勵規則](../overview/03-REWARD_RULES.md) | 平台統一獎勵規則 |
| [儀表板](./01-DASHBOARD.md) | 管理後台總覽 |
| [後端需求](../api/03-BACKEND_REQUIREMENTS.md) | API 規格 |
