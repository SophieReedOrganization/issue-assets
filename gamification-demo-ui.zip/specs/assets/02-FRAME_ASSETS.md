# 頭像框圖片資產清單

> 31 個頭像框圖片檔案清單、規格說明

---

## 1. 圖片規格

| 項目 | 規格 |
|------|------|
| 格式 | PNG (透明背景) |
| 尺寸 | 1024 × 1024 px |
| 風格 | 手遊造型 + 柔軟黏土質感 + 高光 |
| 中心 | 空白圓形區域（約 60% 寬度）|

---

## 2. 風格說明

### 2.1 造型特點

- **手遊風格造型**：可有動態裝飾延伸（翅膀、火焰、水晶、皇冠等）
- **類似參考**：原神、Cookie Run Kingdom 頭像框風格
- **圓形基底**：核心為圓形邊框，裝飾向外延伸

### 2.2 材質特點

- **柔軟黏土質感**：pillowy, soft clay-like, fondant texture
- **非金屬/非塑膠**：避免過於光滑或金屬質感
- **類似參考**：Duolingo 成就徽章的軟萌材質

### 2.3 高光效果

- 邊緣和裝飾上有柔和高光
- 類似光線照射在軟陶/翻糖上的反射
- 增加立體感但不過度閃亮

### 2.4 中心空白區

- 中心有透明圓形區域
- 用於放置用戶頭像
- 約佔整體 60% 寬度

---

## 3. 檔案清單

### 3.1 免費贈送頭像框（4 個）

| 檔案名 | 名稱 | 稀有度 | 取得方式 | 狀態 |
|--------|------|--------|----------|------|
| frame_default.png | 基礎邊框 | ⬜ 普通 | 註冊即得 | ✅ |
| frame_welcome.png | 新手之星 | ⬜ 普通 | 完成新手引導 | ✅ |
| frame_first_task.png | 學習起步 | ⬜ 普通 | 完成第一個任務 | ✅ |
| frame_first_exam.png | 初次挑戰 | ⬜ 普通 | 完成第一份試卷 | ✅ |

### 3.2 成就解鎖頭像框（12 個）

#### 任務系列（3 個）

| 檔案名 | 名稱 | 稀有度 | 解鎖條件 | 狀態 |
|--------|------|--------|----------|------|
| frame_task_bronze.png | 勤學者 | 🥉 銅 | 50 任務 | ✅ |
| frame_task_silver.png | 學習之星 | 🥈 銀 | 200 任務 | ✅ |
| frame_task_gold.png | 知識王者 | 🥇 金 | 500 任務 | ✅ |

#### 試卷系列（3 個）

| 檔案名 | 名稱 | 稀有度 | 解鎖條件 | 狀態 |
|--------|------|--------|----------|------|
| frame_exam_bronze.png | 考試新秀 | 🥉 銅 | 15 試卷 | ✅ |
| frame_exam_silver.png | 考場老將 | 🥈 銀 | 60 試卷 | ✅ |
| frame_exam_gold.png | 考試達人 | 🥇 金 | 100 試卷 | ✅ |

#### 滿分系列（3 個）

| 檔案名 | 名稱 | 稀有度 | 解鎖條件 | 狀態 |
|--------|------|--------|----------|------|
| frame_perfect_bronze.png | 滿分新星 | 🥉 銅 | 5 次滿分 | ✅ |
| frame_perfect_silver.png | 完美主義 | 🥈 銀 | 25 次滿分 | ✅ |
| frame_perfect_gold.png | 零缺點 | 🥇 金 | 50 次滿分 | ✅ |

#### 誠實系列（3 個）

| 檔案名 | 名稱 | 稀有度 | 解鎖條件 | 狀態 |
|--------|------|--------|----------|------|
| frame_honest_bronze.png | 誠實之心 | 🥉 銅 | 20 無猜題 | ✅ |
| frame_honest_silver.png | 誠信達人 | 🥈 銀 | 60 無猜題 | ✅ |
| frame_honest_gold.png | 誠信典範 | 🥇 金 | 100 無猜題 | ✅ |

### 3.3 金幣兌換頭像框（15 個）

#### 入門級（Lv.1-2，200-300 幣）

| 檔案名 | 名稱 | 稀有度 | 價格 | 等級 | 狀態 |
|--------|------|--------|------|------|------|
| frame_flame.png | 火焰邊框 | 🥉 銅 | 200 | Lv.1 | ✅ |
| frame_ocean.png | 海洋邊框 | 🥉 銅 | 200 | Lv.1 | ✅ |
| frame_forest.png | 森林邊框 | 🥉 銅 | 200 | Lv.1 | ✅ |
| frame_rainbow.png | 彩虹邊框 | 🥈 銀 | 300 | Lv.2 | ✅ |
| frame_star.png | 星空邊框 | 🥈 銀 | 300 | Lv.2 | ✅ |
| frame_candy.png | 糖果邊框 | 🥈 銀 | 300 | Lv.2 | ✅ |

#### 進階級（Lv.3-5，400-500 幣）

| 檔案名 | 名稱 | 稀有度 | 價格 | 等級 | 狀態 |
|--------|------|--------|------|------|------|
| frame_neon.png | 霓虹邊框 | 🥈 銀 | 400 | Lv.3 | ✅ |
| frame_crystal.png | 水晶邊框 | 🥈 銀 | 400 | Lv.3 | ✅ |
| frame_sakura.png | 櫻花邊框 | 🥈 銀 | 400 | Lv.3 | ✅ |
| frame_lightning.png | 雷電邊框 | 🥇 金 | 500 | Lv.5 | ✅ |
| frame_galaxy.png | 銀河邊框 | 🥇 金 | 500 | Lv.5 | ✅ |

#### 高級級（Lv.7-20，600-1500 幣）

| 檔案名 | 名稱 | 稀有度 | 價格 | 等級 | 狀態 |
|--------|------|--------|------|------|------|
| frame_phoenix.png | 鳳凰邊框 | 🥇 金 | 600 | Lv.7 | ✅ |
| frame_dragon.png | 龍騰邊框 | 🥇 金 | 800 | Lv.10 | ✅ |
| frame_legendary.png | 傳說邊框 | 💎 傳說 | 1,000 | Lv.15 | ✅ |
| frame_ultimate.png | 至尊邊框 | 💎 傳說 | 1,500 | Lv.20 | ✅ |

---

## 4. 統計

### 4.1 獲取方式分佈

| 獲取方式 | 數量 |
|----------|------|
| 免費贈送 | 4 |
| 成就解鎖 | 12 |
| 金幣兌換 | 15 |
| **總計** | **31** |

### 4.2 稀有度分佈

| 稀有度 | 數量 |
|--------|------|
| ⬜ 普通 | 4 |
| 🥉 銅 | 7 |
| 🥈 銀 | 10 |
| 🥇 金 | 8 |
| 💎 傳說 | 2 |
| **總計** | **31** |

### 4.3 檔案完整性

| 狀態 | 數量 |
|------|------|
| ✅ 已完成 | 31 |
| ❌ 缺失 | 0 |

---

## 5. 存放位置

```
assets/frames/
├── frame_default.png        # 免費 - 基礎邊框
├── frame_welcome.png        # 免費 - 新手之星
├── frame_first_task.png     # 免費 - 學習起步
├── frame_first_exam.png     # 免費 - 初次挑戰
├── frame_task_bronze.png    # 成就 - 勤學者
├── frame_task_silver.png    # 成就 - 學習之星
├── frame_task_gold.png      # 成就 - 知識王者
├── frame_exam_bronze.png    # 成就 - 考試新秀
├── frame_exam_silver.png    # 成就 - 考場老將
├── frame_exam_gold.png      # 成就 - 考試達人
├── frame_perfect_bronze.png # 成就 - 滿分新星
├── frame_perfect_silver.png # 成就 - 完美主義
├── frame_perfect_gold.png   # 成就 - 零缺點
├── frame_honest_bronze.png  # 成就 - 誠實之心
├── frame_honest_silver.png  # 成就 - 誠信達人
├── frame_honest_gold.png    # 成就 - 誠信典範
├── frame_flame.png          # 商店 - 火焰邊框
├── frame_ocean.png          # 商店 - 海洋邊框
├── frame_forest.png         # 商店 - 森林邊框
├── frame_rainbow.png        # 商店 - 彩虹邊框
├── frame_star.png           # 商店 - 星空邊框
├── frame_candy.png          # 商店 - 糖果邊框
├── frame_neon.png           # 商店 - 霓虹邊框
├── frame_crystal.png        # 商店 - 水晶邊框
├── frame_sakura.png         # 商店 - 櫻花邊框
├── frame_lightning.png      # 商店 - 雷電邊框
├── frame_galaxy.png         # 商店 - 銀河邊框
├── frame_phoenix.png        # 商店 - 鳳凰邊框
├── frame_dragon.png         # 商店 - 龍騰邊框
├── frame_legendary.png      # 商店 - 傳說邊框
└── frame_ultimate.png       # 商店 - 至尊邊框
```

---

## 6. 備份資料

手遊風格版本（純金屬質感，已棄用）備份在：

```
assets/frames_backup_mobile_game_style/
```

---

## 7. 相關文件

| 文件 | 說明 |
|------|------|
| [頭像框與稱號系統](../student-app/02-FRAME_TITLE_SYSTEM.md) | 完整定義 |
| [徽章資產](./01-BADGE_ASSETS.md) | 徽章圖片清單 |
| [商店系統](../student-app/03-SHOP_SYSTEM.md) | 商店購買規則 |
