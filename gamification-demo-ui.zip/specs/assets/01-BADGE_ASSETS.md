# 徽章圖片資產清單

> 64 個徽章圖片檔案清單、規格說明

---

## 1. 圖片規格

| 項目 | 規格 |
|------|------|
| 格式 | PNG (透明背景) |
| 尺寸 | 1024 × 1024 px |
| 風格 | 六角形盾牌 + 柔軟黏土質感 + 高光 |
| 邊框 | 奶油色/米色厚實邊框 |
| 裝飾 | 底部緞帶裝飾 |

---

## 2. 風格說明

### 2.1 造型

- 六角形盾牌造型（尖頂朝上）
- 厚實奶油色邊框（軟陶/翻糖質感）
- 底部小緞帶裝飾
- 中心圖標為金色/奶油色

### 2.2 材質

- 柔軟黏土質感 (pillowy, soft clay-like)
- 柔和高光效果（邊緣頂部有光澤）
- 類似 Duolingo 成就徽章風格

### 2.3 稀有度背景色

| 稀有度 | 內部背景色 | 緞帶顏色 |
|--------|------------|----------|
| 🥉 銅 | 珊瑚紅 / 暖橘 | 橘色 |
| 🥈 銀 | 銀藍色 / 淺藍 | 藍色 |
| 🥇 金 | 金黃色 / 暖金 | 金色 |
| 💎 鑽石 | 紫色 / 薰衣草 | 紫色 |

---

## 3. 檔案清單

### 3.1 📚 任務完成系列（7 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| task_10.png | 起步者 | 🥉 銅 | ✅ |
| task_30.png | 進擊者 | 🥉 銅 | ✅ |
| task_50.png | 學習小將 | 🥉 銅 | ✅ |
| task_100.png | 學習達人 | 🥈 銀 | ✅ |
| task_200.png | 知識探險家 | 🥈 銀 | ✅ |
| task_500.png | 知識巨人 | 🥇 金 | ✅ |
| task_1000.png | 傳說學者 | 💎 鑽石 | ✅ |

### 3.2 📝 試卷完成系列（6 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| exam_5.png | 初試身手 | 🥉 銅 | ✅ |
| exam_15.png | 小試牛刀 | 🥉 銅 | ✅ |
| exam_30.png | 考場老手 | 🥈 銀 | ✅ |
| exam_60.png | 考試達人 | 🥈 銀 | ✅ |
| exam_100.png | 考試專家 | 🥇 金 | ✅ |
| exam_200.png | 考場傳說 | 💎 鑽石 | ✅ |

### 3.3 🎯 正確率系列（6 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| acc_pass_10.png | 合格新手 | 🥉 銅 | ✅ |
| acc_pass_30.png | 穩定發揮 | 🥉 銅 | ✅ |
| acc_good_10.png | 優秀學員 | 🥈 銀 | ✅ |
| acc_good_30.png | 實力派 | 🥈 銀 | ✅ |
| acc_high_10.png | 高分王者 | 🥇 金 | ✅ |
| acc_high_30.png | 學神降臨 | 💎 鑽石 | ✅ |

### 3.4 💯 滿分系列（6 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| perfect_1.png | 首次滿分 | 🥉 銅 | ✅ |
| perfect_3.png | 滿分三連 | 🥉 銅 | ✅ |
| perfect_10.png | 滿分達人 | 🥈 銀 | ✅ |
| perfect_25.png | 完美主義者 | 🥈 銀 | ✅ |
| perfect_50.png | 滿分傳說 | 🥇 金 | ✅ |
| perfect_100.png | 零缺點神話 | 💎 鑽石 | ✅ |

### 3.5 💚 誠實作答系列（6 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| honest_5.png | 誠實小將 | 🥉 銅 | ✅ |
| honest_15.png | 認真學習者 | 🥉 銅 | ✅ |
| honest_30.png | 誠實達人 | 🥈 銀 | ✅ |
| honest_60.png | 誠實大師 | 🥈 銀 | ✅ |
| honest_100.png | 誠實傳說 | 🥇 金 | ✅ |
| honest_200.png | 誠信典範 | 💎 鑽石 | ✅ |

### 3.6 ⭐ 任務高分系列（6 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| highscore_10.png | 高分新秀 | 🥉 銅 | ✅ |
| highscore_30.png | 高分好手 | 🥉 銅 | ✅ |
| highscore_60.png | 高分常客 | 🥈 銀 | ✅ |
| highscore_100.png | 高分專家 | 🥈 銀 | ✅ |
| highscore_200.png | 高分大師 | 🥇 金 | ✅ |
| highscore_500.png | 高分之神 | 💎 鑽石 | ✅ |

### 3.7 📊 學習路徑系列（6 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| path_25.png | 啟程者 | 🥉 銅 | ✅ |
| path_50.png | 中途站 | 🥉 銅 | ✅ |
| path_75.png | 即將完成 | 🥈 銀 | ✅ |
| path_100.png | 路徑征服者 | 🥈 銀 | ✅ |
| path_complete_3.png | 多路精通 | 🥇 金 | ✅ |
| path_complete_5.png | 路徑霸主 | 💎 鑽石 | ✅ |

### 3.8 🌅 早起學習系列（5 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| early_5.png | 早起鳥兒 | 🥉 銅 | ✅ |
| early_20.png | 晨曦學者 | 🥉 銅 | ✅ |
| early_50.png | 黎明守護者 | 🥈 銀 | ✅ |
| early_100.png | 早安達人 | 🥇 金 | ✅ |
| early_300.png | 晨光傳說 | 💎 鑽石 | ✅ |

### 3.9 🌙 夜間學習系列（5 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| night_5.png | 夜貓學習者 | 🥉 銅 | ✅ |
| night_20.png | 星空下的努力 | 🥉 銅 | ✅ |
| night_50.png | 月光學者 | 🥈 銀 | ✅ |
| night_100.png | 夜間達人 | 🥇 金 | ✅ |
| night_300.png | 星夜傳說 | 💎 鑽石 | ✅ |

### 3.10 📅 每日任務系列（6 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| daily_3.png | 每日達成 | 🥉 銅 | ✅ |
| daily_7.png | 週週完美 | 🥉 銅 | ✅ |
| daily_14.png | 雙週滿勤 | 🥈 銀 | ✅ |
| daily_30.png | 月度模範 | 🥈 銀 | ✅ |
| daily_60.png | 完美執行者 | 🥇 金 | ✅ |
| daily_100.png | 每日傳說 | 💎 鑽石 | ✅ |

### 3.11 🎁 收集系列（5 個）

| 檔案名 | 名稱 | 稀有度 | 狀態 |
|--------|------|--------|------|
| collect_10.png | 收藏家新手 | 🥉 銅 | ✅ |
| collect_25.png | 徽章愛好者 | 🥈 銀 | ✅ |
| collect_50.png | 收藏達人 | 🥈 銀 | ✅ |
| collect_55.png | 收藏大師 | 🥇 金 | ✅ |
| collect_all.png | 全徽章制霸 | 💎 鑽石 | ✅ |

---

## 4. 統計

### 4.1 稀有度分佈

| 稀有度 | 數量 |
|--------|------|
| 🥉 銅 | 22 |
| 🥈 銀 | 20 |
| 🥇 金 | 11 |
| 💎 鑽石 | 11 |
| **總計** | **64** |

### 4.2 檔案完整性

| 狀態 | 數量 |
|------|------|
| ✅ 已完成 | 64 |
| ❌ 缺失 | 0 |

---

## 5. 存放位置

```
assets/badges/
├── task_10.png
├── task_30.png
├── task_50.png
├── task_100.png
├── task_200.png
├── task_500.png
├── task_1000.png
├── exam_5.png
├── exam_15.png
├── exam_30.png
├── exam_60.png
├── exam_100.png
├── exam_200.png
├── acc_pass_10.png
├── acc_pass_30.png
├── acc_good_10.png
├── acc_good_30.png
├── acc_high_10.png
├── acc_high_30.png
├── perfect_1.png
├── perfect_3.png
├── perfect_10.png
├── perfect_25.png
├── perfect_50.png
├── perfect_100.png
├── honest_5.png
├── honest_15.png
├── honest_30.png
├── honest_60.png
├── honest_100.png
├── honest_200.png
├── highscore_10.png
├── highscore_30.png
├── highscore_60.png
├── highscore_100.png
├── highscore_200.png
├── highscore_500.png
├── path_25.png
├── path_50.png
├── path_75.png
├── path_100.png
├── path_complete_3.png
├── path_complete_5.png
├── early_5.png
├── early_20.png
├── early_50.png
├── early_100.png
├── early_300.png
├── night_5.png
├── night_20.png
├── night_50.png
├── night_100.png
├── night_300.png
├── daily_3.png
├── daily_7.png
├── daily_14.png
├── daily_30.png
├── daily_60.png
├── daily_100.png
├── collect_10.png
├── collect_25.png
├── collect_50.png
├── collect_55.png
└── collect_all.png
```

---

## 6. 相關文件

| 文件 | 說明 |
|------|------|
| [徽章系統](../student-app/01-BADGE_SYSTEM.md) | 徽章定義與解鎖條件 |
| [頭像框資產](./02-FRAME_ASSETS.md) | 頭像框圖片清單 |
